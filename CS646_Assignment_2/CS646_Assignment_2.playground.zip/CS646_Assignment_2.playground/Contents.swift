/*=======================================================================================================
 Thuc Nguyen
 CS646 Fall 2017
 Due September 18, 2017
 
                                             Assignment 2
 
 ======================================================================================================*/

import UIKit

/*=============================================// (1) //==================================================*/
/*
 T = Generic Type
 */
protocol LinkedListProtocol {
    associatedtype T
    var count: Int {get}
    func append(object: T)
    func prepend(object: T)
    func removeLast() -> T?
    func removeFirst() -> T?
}

/*=============================================// (2) //==================================================*/
class Node<T> {
    var element: T
    var next: Node<T>?
    
    init(element: T){
        self.element = element
    }
}

class LinkedList<T>: LinkedListProtocol {
    var head: Node<T>?
    var count = 0
    
    func prepend(object: T) {
        let newNode = Node(element: object)
        newNode.next = head
        head = newNode
        
        count += 1
    }
    func append(object: T) {
        guard (head != nil) else {
            prepend(object: object)
            return
        }
        
        let newNode = Node(element: object)
        var currentNode = head
        
        while (currentNode?.next != nil){
            currentNode = currentNode?.next
        }
        currentNode?.next = newNode
        
        count += 1
    }
    func removeFirst() -> T? {
        if (head == nil){
            return nil
        }
        
        let data: T? = head?.element
        head = head?.next
        
        count -= 1
        return data
    }
    func removeLast() -> T? {
        if (head == nil) {
            return nil
        }
        if (head?.next == nil){
            let data = head?.element
            head = nil
            return data
        }
        
        var currentNode = head
        
        while (currentNode?.next?.next != nil){
            currentNode = currentNode?.next
        }
        let data = currentNode?.next?.element
        currentNode?.next = nil
        
        count -= 1
        return data
    }
    
    subscript(index : Int) -> T? {
        assert((index >= 0 && index < count), "Index out of range")
        var indexNum = index
        var currentNode = head
        while (indexNum > 0){
            currentNode = currentNode?.next
            indexNum -= 1
        }
        return currentNode?.element
    }
    
    fileprivate func elements(separatedBy: String) -> NSString? {
        var stringFromList = ""
        var currentNode = head
        while (currentNode != nil){
            stringFromList += String(describing: currentNode!.element)
            currentNode = currentNode?.next
            if (currentNode != nil){
                stringFromList += separatedBy
            }
        }
        
        return stringFromList as NSString
    }
    
    func description() -> String {
        var contents = "["
        var currentNode = head
        while (currentNode != nil){
            contents += String(describing: currentNode!.element)
            currentNode = currentNode?.next
            if (currentNode != nil){
                contents += ", "
            }
        }
        contents += "]"
        return contents
    }
/*=============================================// (3) //==================================================*/
    init() {
        self.count = 0
    }
    
    init(repeating: T, count: Int) {
        self.count = count
        var index: Int = 0
        while (index < count){
            append(object: repeating)
            index += 1
        }
    }
    
    var isEmpty: Bool {
        get {
            return (head == nil)
        }
    }
    
    func map<T>(function: (T) -> T) -> LinkedList<T> {
        let newLinkedList = LinkedList<T>()
 
        var currentNode = head
        while (currentNode != nil) {
            let data: T = function(currentNode!.element as! T)
            newLinkedList.append(object: data)
            currentNode = currentNode!.next
        }
        
        return newLinkedList
    }
    
    func reduce<Result>(initial: Result, function: (Result, T) -> Result) -> Result{
        var result = initial
        var currentNode = head
        while (currentNode != nil){
            result = function(result, currentNode!.element)
            currentNode = currentNode!.next
        }
        return result
    }
    
}

/*=============================================// (4) //==================================================*/
extension String {
    func integerValues() -> [Int?] {
        let array = self.components(separatedBy: ",")
        let mappedArray = array.map({Int($0)})
        return mappedArray
    }
}

/*=============================================// (5) //==================================================*/
enum Currency {
    case Euro (String, String, Double)
    case Dollar (String, String, Double)
    case Rupee (String, String, Double)
    case Peso (String, String, Double)
}
let EuroCurrency = Currency.Euro("EUR", "\u{20AC}", 0.8904)
let USCurrency = Currency.Dollar("USD", "\u{24}", 1)
let IndCurrency = Currency.Rupee("INR", "\u{20B9}", 66.7)
let MexCurrency = Currency.Peso("MXN", "\u{24}", 18.88)

extension Currency:Equatable {
    static func ==(left: Currency, right: Currency) -> Bool {
        switch (left, right){
        case let (.Euro(code1, _, _), .Euro(code2, _, _)):
            return code1 == code2
        case let (.Dollar(code1, _, _), .Dollar(code2, _, _)):
            return code1 == code2
        case let (.Rupee(code1, _, _), .Rupee(code2, _, _)):
            return code1 == code2
        case let (.Peso(code1, _, _), .Peso(code2, _, _)):
            return code1 == code2
        default:
            return false
        }
    }
}


/*=============================================// (6) //==================================================*/
struct Money {
    let amount: Double
    let currency: Currency
    
    init(amount: Double, currencyType: Currency) {
        self.amount = amount
        currency = currencyType
    }
    
    static func + (left: Money, right: Money) -> Money {
        if (left.currency == right.currency){
            return Money(amount: (left.amount + right.amount), currencyType: left.currency)
        }
        else {
            let newAmount: Double = left.amount + ( (right.amount * getExchangeRate(currency: left.currency)) / (getExchangeRate(currency: right.currency)) )
            return Money(amount: newAmount, currencyType: left.currency)
            
        }
    }
    
    static func - (left : Money, right: Money) -> Money {
        if (left.currency == right.currency) {
            return Money(amount: (left.amount - right.amount), currencyType: left.currency)
        }
        else {
            let newAmount: Double = left.amount - ( (right.amount * getExchangeRate(currency: left.currency)) / (getExchangeRate(currency: right.currency)) )
            return Money(amount: newAmount, currencyType: left.currency)
        }
    }
    
    func description() -> String {
        var stringDesc: String = ""
        switch currency {
            case let .Euro(code, symbol, _):
                stringDesc = "\(symbol)\(amount) \(code)"
            case let .Dollar(code, symbol, _):
                stringDesc = "\(symbol)\(amount) \(code)"
            case let .Rupee(code, symbol, _):
                stringDesc = "\(symbol)\(amount) \(code)"
            case let .Peso(code, symbol, _):
                stringDesc = "\(symbol)\(amount) \(code)"
            }
        return stringDesc
    }
    
    static func getExchangeRate(currency: Currency) -> Double {
        switch (currency){
            case let .Euro(_, _, rate):
                return rate
            case let .Dollar(_, _, rate):
                return rate
            case let .Rupee(_, _, rate):
                return rate
            case let .Peso(_, _, rate):
                return rate
        }
    }
}

/* Test Cases */
// Initialization and description()
let linkedList = LinkedList<Int>(repeating: 3, count: 3)
linkedList.description()

// prepend() and append()
linkedList.prepend(object: 2)
linkedList.description()
linkedList.prepend(object: 1)
linkedList.description()
linkedList.append(object: 4)
linkedList.description()
linkedList.prepend(object: 0)
linkedList.description()
linkedList.append(object: 5)
linkedList.description()

// removeFirst() and removeLast()
linkedList.removeFirst()
linkedList.description()
linkedList.removeFirst()
linkedList.description()
linkedList.removeLast()
linkedList.description()
linkedList.removeLast()
linkedList.description()

// subscript
linkedList[0]
linkedList[1]
linkedList[2]

// elements(separatedBy: _)
linkedList.elements(separatedBy: "-")
linkedList.append(object: 10)
linkedList.elements(separatedBy: ",")

// isEmpty()
linkedList.isEmpty
linkedList.removeLast()
linkedList.description()
linkedList.removeLast()
linkedList.removeLast()
linkedList.removeLast()
linkedList.description()
linkedList.removeFirst()
linkedList.isEmpty

// map()
func add(num : Int) -> Int {
    return num + 2
}
var linkedList2 = LinkedList<Int>(repeating: 3, count: 3)
linkedList2.description()
linkedList2 = linkedList2.map(function: add)
linkedList2.description()

// reduce()
var sum: Int = linkedList2.reduce(initial: 0, function: {$0 + $1})
sum
var difference: Int = linkedList2.reduce(initial: 10, function: {$0 - $1})
difference

// integerValues()
"2,3,6".integerValues()
"2".integerValues()
"cat".integerValues()
"2,foo,6".integerValues()

// Money struct
let dollars1 = Money(amount: 50, currencyType: USCurrency)
dollars1.description()
let pesos1 = Money(amount: 100, currencyType: MexCurrency)
pesos1.description()
let euro1 = Money(amount: 1000, currencyType: EuroCurrency)
euro1.description()
let rupees1 = Money(amount: 20000, currencyType: IndCurrency)
rupees1.description()

// Money Overloaded Operators
let dollars2 = dollars1 + pesos1
dollars2.amount
dollars2.currency
dollars2.description()

let euro2 = euro1 - rupees1
euro2.amount
euro2.currency
euro2.description()

let pesos2 = Money(amount: 50, currencyType: MexCurrency)
let pesos3 = pesos1 - pesos2
pesos3.amount
pesos3.currency
pesos3.description()
