/*----------------------------------------------------------------------
 Thuc Nguyen
 
                        CS 646 Assignment 1 - Improved
 
 ----------------------------------------------------------------------*/

import UIKit


/*------------------------------- (1) ---------------------------------*/
func isPalindrome(_ value: String) -> Bool {
    return value == String(value.reversed())
}
func isPalindrome(_ value: Int) -> Bool {
    return isPalindrome(String(value))
}

func palindromes(from: Int, to: Int) -> Int {
    guard from >= 0 && to >= from else {
        return 0
    }
    return (from...to).filter(isPalindrome).count
}

// Testing
palindromes(from: 0, to: 10) == 10
palindromes(from: 0, to: 22) == 12
palindromes(from: 0, to: 100) == 19

/*------------------------------- (2) ---------------------------------*/
func isMultiple3or5not15(n: Int) -> Bool {
    switch n {
    case let x where (x % 15 == 0):
        return false
    case let x where (x % 3 == 0):
        return true
    case let x where (x % 5 == 0):
        return true
    default:
        return false
    }
}

func sumMultiples3_5(_ n: Int) -> Int {
    guard n > 0 else {
        return 0
    }
    return (3..<n).filter(isMultiple3or5not15).reduce(0, +)
}

// Testing
sumMultiples3_5(6) == 8
sumMultiples3_5(11) == 33
sumMultiples3_5(20) == 63
sumMultiples3_5(-1) == 0

/*------------------------------- (3) ---------------------------------*/
extension String {
    func midfix(start: String.Index, text: String) -> Bool {
        return self.suffix(from: start).hasPrefix(text)
    }
}

func patternCount(text: String, pattern: String) -> Int {
    guard text.count > 0 && pattern.count > 0 && pattern.count <= text.count else {
        return 0
    }
    return text.indices.filter({text.midfix(start: $0, text: pattern)}).count
}

// Testing
patternCount(text: "abababa", pattern: "aba") == 3
patternCount(text: "aaaaa", pattern: "aa") == 4
patternCount(text: "Abcde", pattern: "abc") == 0
patternCount(text: "Abcde", pattern: "Abcde") == 1
patternCount(text: "Abcde", pattern: "Abcdea") == 0
patternCount(text: "Abcde", pattern: "") == 0
patternCount(text: "", pattern: "abc") == 0

/*------------------------------- (4) ---------------------------------*/
func popularClasses(_ students: [Set<String>]) -> Set<String> {
    guard students.count > 0 else {
        return []
    }
    return students.reduce(students[0], {$0.intersection($1)})
}

// Testing
let studentA: Set = ["CS101", "CS237", "CS520"]
let studentB: Set = ["CS101", "Math245", "CS237"]
let studentC: Set = ["CS237", "CS560"]
let studentD: Set<String> = []
let studentE: Set = ["cs646"]

popularClasses([studentA, studentB, studentC]) == ["CS237"]
popularClasses([]) == []
popularClasses([studentA, studentD]) == []
popularClasses([studentA, studentB, studentE]) == []
popularClasses([studentA]) == ["CS101", "CS237", "CS520"]

/*------------------------------- (5) ---------------------------------*/
func average(_ data: [Int]) -> Double? {
    guard data.count > 0 else {
        return nil
    }
    let sum = data.reduce(0, +)
    return Double(sum) / Double(data.count)
}

/*------------------------------- (6) ---------------------------------*/
func average2(_ data: [Int?]) -> Double? {
    guard data.count > 0 && data.contains(where: {$0 == nil}) == false else {
        return nil
    }
    let sum = data.reduce(0, {$0 + $1!})
    return Double(sum) / Double(data.count)
}

/*------------------------------- (7) ---------------------------------*/
func cost(of order: Dictionary<String, String>) -> Double? {
    guard (order.count > 0) else {
        return nil
    }
    guard let quantityString = order["quantity"], let quantity = Double(quantityString),
        let priceString = order["price"], let price = Double(priceString) else {
            return 0.0
    }
    return quantity * price
}

/*------------------------------- (8) ---------------------------------*/
func wordCount(words: String, minimum: Int) -> Dictionary<String, Int> {
    let wordsArray = words.components(separatedBy: " ")
    
    var dictionary = [String: Int]()
    
    for word in wordsArray {
        
        if (dictionary.keys.contains(word)){
            if var number = dictionary[word]{
                number += 1
                dictionary[word] = number
            }
        }
        else {
            dictionary[word] = 1
        }
    }
    for (key, value) in dictionary {
        if (value < minimum){
            dictionary.removeValue(forKey: key)
        }
    }
    return dictionary
}
/* Test Cases */
wordCount(words: "cat bat cat rat mouse bat", minimum: 1) == ["cat": 2, "bat": 2, "rat": 1, "mouse": 1]
wordCount(words: "cat bat cat rat mouse bat", minimum: 2) == ["cat": 2, "bat": 2]
wordCount(words: "cat bat cat rat mouse bat", minimum: 3) == [:]

/*------------------------------- (9) ---------------------------------*/
func wordCount2(words: String, minimum: Int = 2) -> Dictionary<String, Int>{
    let wordsArray = words.components(separatedBy: " ")
    
    var dictionary = [String: Int]()
    
    for word in wordsArray {
        
        if (dictionary.keys.contains(word)){
            if var number = dictionary[word]{
                number += 1
                dictionary[word] = number
            }
        }
        else {
            dictionary[word] = 1
        }
    }
    for (key, value) in dictionary {
        if (value < minimum){
            dictionary.removeValue(forKey: key)
        }
    }
    return dictionary
}
/* Test Cases */
wordCount2(words: "cat bat cat rat mouse bat") == ["cat": 2, "bat": 2]
wordCount2(words: "cat bat cat rat mouse bat", minimum: 3) == [:]

/*------------------------------- (10) ---------------------------------*/
func wordCount3(minimum : Int) -> (String) -> Dictionary<String, Int> {
    
    func wordCountReturn(words: String) -> Dictionary<String, Int> {
        let wordsArray = words.components(separatedBy: " ")
        
        var dictionary = [String: Int]()
        
        for word in wordsArray {
            
            if (dictionary.keys.contains(word)){
                if var number = dictionary[word]{
                    number += 1
                    dictionary[word] = number
                }
            }
            else {
                dictionary[word] = 1
            }
        }
        for (key, value) in dictionary {
            if (value < minimum){
                dictionary.removeValue(forKey: key)
            }
        }
        return dictionary
    }
    
    return wordCountReturn
}
/* Test Cases */
let testA = wordCount3(minimum: 2)
testA("cat bat cat rat mouse bat") == ["cat": 2, "bat": 2]
testA("a a a b c c") == ["a": 3, "c": 2]
let testB = wordCount3(minimum: 3)
testB("a a a b c c") == ["a": 3]



