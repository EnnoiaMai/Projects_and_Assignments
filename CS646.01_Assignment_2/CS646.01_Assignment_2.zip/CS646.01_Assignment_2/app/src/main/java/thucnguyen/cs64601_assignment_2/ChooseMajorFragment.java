package thucnguyen.cs64601_assignment_2;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ListFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class ChooseMajorFragment extends ListFragment implements AdapterView.OnItemClickListener {

    // PROPERTIES
    /**
     * Enum to indicate which list of data is currently being used by the array adapter and
     * displayed by the list view - the list of advanced degrees or the list of majors
     * */
    public enum ListData {
        ADVANCED_DEGREE_LIST,
        MAJOR_LIST
    }
    public ListData currentListData = ListData.ADVANCED_DEGREE_LIST;

    /**
     * Interface for an activity to implement.
     *      fragmentChanged() - updates the activity's currentListData property so that the back
     *                          button will execute the appropriate actions
     *      majorSelected() - sends the value of selectedDegree to the activity so that it can put the
     *                        value as an extra into the intent to send it back to PersonalInformation
     *                        activity.
     * */
    public interface MajorSelectedListener {
        void fragmentChanged(ListData data);
        void majorSelected(String major);
    }

    private String selectedDegree = "";
    private ArrayAdapter<String> listViewAdapter;
    private ArrayList<String> listInListView = new ArrayList<>(40);
    private ArrayList<String> listOfDegrees = new ArrayList<>(10);

    // DEBUG
    private static final String DEBUG_CHOOSE_MAJOR = "DEBUG_CHOOSE_MAJOR";

    // CONSTRUCTOR
    public ChooseMajorFragment() {
        // Required empty public constructor
    }

    // METHODS
    /**
     * readDegreesFile()
     * Opens up advanced_degrees file and adds each line in the file to the ArrayList
     * for the degrees.
     * */
    private void readDegreesFile() {
        Log.d(DEBUG_CHOOSE_MAJOR, "readDegreesFile()");

        BufferedReader in = null;
        try {
            InputStream degreesFile = getActivity().getAssets().open("advanced_degrees");
            in = new BufferedReader(new InputStreamReader(degreesFile));

            String degreesLine;
            while ((degreesLine = in.readLine()) != null ) {
                listOfDegrees.add(degreesLine);
            }
        }
        catch (IOException e) {
            Log.e(DEBUG_CHOOSE_MAJOR, "Couldn't read Advanced Degrees file");
        }
        finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * readMajorsFile()
     * Depending on the advanced degree that the user clicked on, the file matching the degree
     * name is opened. Each line is read and added to the array adapter after the adapter is cleared.
     * notifyDataSetChanged() is called so that the observers know that the underlying data changed.
     * */
    private void readMajorsFile(String fileName) {
        Log.d(DEBUG_CHOOSE_MAJOR, "readMajorsFile()");

        BufferedReader in = null;
        try {
            InputStream majorsFile = getActivity().getAssets().open(fileName);
            in = new BufferedReader(new InputStreamReader(majorsFile));

            ArrayList<String> listOfMajors = new ArrayList<>(40);
            String majorsLine;
            while ((majorsLine = in.readLine()) != null) {
                listOfMajors.add(majorsLine);
            }

            listViewAdapter.clear();
            listViewAdapter.addAll(listOfMajors);
            listViewAdapter.notifyDataSetChanged();
        }
        catch (IOException e) {
            Log.e(DEBUG_CHOOSE_MAJOR, "Couldn't read Majors file");
        }
        finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * returnAbbreviation()
     * The abbreviated form of the degrees is used as part of the string that displays both the
     * degree and the major, so that form is returned.
     * */
    private String returnAbbreviation(String degree) {
        return degree.substring(degree.indexOf("(") + 1, degree.indexOf(")"));
    }

    /**
     * refreshDegreeList()
     * Called when the user taps the back button and the current list being shown is the
     * list of majors. The list is refreshed to show the list of degrees.
     * */
    public void refreshDegreeList() {
        Log.d(DEBUG_CHOOSE_MAJOR, "refreshDegreeList()");

        listViewAdapter.clear();
        listViewAdapter.addAll(listOfDegrees);
        listViewAdapter.notifyDataSetChanged();
    }

    // FRAGMENT LIFECYCLE
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_advanced_degree, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        readDegreesFile();
        listInListView.addAll(listOfDegrees);
        listViewAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, listInListView);
        setListAdapter(listViewAdapter);
        getListView().setOnItemClickListener(this);
    }

    // IMPLEMENTATION METHODS
    /**
     * Either reload the list view and reference new data (the list of majors) or
     * signal ChooseMajorActivity to return the selected major
     * */
    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        Log.d(DEBUG_CHOOSE_MAJOR, "Position of click: " + i);
        Log.d(DEBUG_CHOOSE_MAJOR, "ID of click: " + l);

        MajorSelectedListener listener = (MajorSelectedListener) getActivity();
        switch (currentListData) {
            case ADVANCED_DEGREE_LIST:
                selectedDegree = returnAbbreviation(listOfDegrees.get(i));
                readMajorsFile(listOfDegrees.get(i));
                currentListData = ListData.MAJOR_LIST;
                listener.fragmentChanged(currentListData);
                break;
            case MAJOR_LIST:
                listener.majorSelected(selectedDegree + " " + listViewAdapter.getItem(i));
                break;
        }
    }
}
