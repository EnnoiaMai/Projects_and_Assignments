package thucnguyen.cs64601_assignment_2;

import android.content.Intent;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class ChooseMajorActivity extends AppCompatActivity implements ChooseMajorFragment.MajorSelectedListener {

    // PROPERTIES
    thucnguyen.cs64601_assignment_2.ChooseMajorFragment chooseMajorFragment;
    private ChooseMajorFragment.ListData currentListData;

    // DEBUG
    private static final String DEBUG_CHOOSE_MAJOR = "DEBUG_CHOOSE_MAJOR";

    // CONSTRUCTOR
    public ChooseMajorActivity() {
    }

    // ACTIVITY LIFECYCLE AND OVERRIDE METHODS
    /**
     * onCreate()
     * Programmatically add the fragment to the activity by getting the support fragment manager,
     * starting a transaction, adding the fragment, and committing it. Also initialize the variable
     * holding the ListData enum value, currentListData, to ADVANCED_DEGREE_LIST.
     * */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.choose_activity_major);

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        chooseMajorFragment = new thucnguyen.cs64601_assignment_2.ChooseMajorFragment();
        fragmentTransaction.add(R.id.fragment_holder, chooseMajorFragment);
        fragmentTransaction.commit();

        currentListData = ChooseMajorFragment.ListData.ADVANCED_DEGREE_LIST;

        setTitle(R.string.title_choose_degree);
    }

    /**
     * onBackPressed()
     * If the advanced degree list is currently being shown, then back button should, as by default,
     * destroy the current activity.
     * If the majors list is currently being shown, then the back button should tell the fragment
     * to return to the list of advanced degrees. There isn't navigation back to the list, the list view
     * is only refreshing to show the previous data. currentListData of the fragment should update back
     * to ADVANCED_DEGREE_LIST
     * */
    @Override
    public void onBackPressed() {
        Log.d(DEBUG_CHOOSE_MAJOR, "onBackPressed()");

        switch (currentListData) {
            case ADVANCED_DEGREE_LIST:
                Log.d(DEBUG_CHOOSE_MAJOR, "List showing advanced degrees, back button will call finish()");

                super.onBackPressed();
                break;
            case MAJOR_LIST:
                Log.d(DEBUG_CHOOSE_MAJOR, "List showing majors, back button will refresh list to show degrees");

                currentListData = ChooseMajorFragment.ListData.ADVANCED_DEGREE_LIST;
                chooseMajorFragment.currentListData = ChooseMajorFragment.ListData.ADVANCED_DEGREE_LIST;
                chooseMajorFragment.refreshDegreeList();

                setTitle(R.string.title_choose_degree);
                break;
        }
    }

    // IMPLEMENTATION METHODS
    /**
     * Methods from the interface that gets fired by methods in the fragment
     *
     * fragmentChanged() - updates the currentListData variable and the title
     *
     * majorSelected() - puts data in the intent that was used to get to this activity so that
     *                   it can be sent back to the calling activity. Sends the string specifying
     *                   the degree and major that was built in the fragment
     * */
    @Override
    public void fragmentChanged(ChooseMajorFragment.ListData data) {
        Log.d(DEBUG_CHOOSE_MAJOR, "fragmentChanged()");

        currentListData = data;
        setTitle(R.string.title_choose_major);
    }

    @Override
    public void majorSelected(String major) {
        Log.d(DEBUG_CHOOSE_MAJOR, "majorSelected()");

        Intent returnMajor = getIntent();
        returnMajor.putExtra("major", major);
        setResult(RESULT_OK, returnMajor);
        finish();
    }
}
