package thucnguyen.cs64601_assignment_2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class PersonalInformationActivity extends AppCompatActivity implements View.OnClickListener {

    // PROPERTIES AND WIDGETS
    private EditText mFirstNameEditText, mFamilyNameEditText, mAgeEditText, mEmailEditText, mPhoneEditText;
    private TextView mMajorTextView;

    // DEBUG AND CONSTANTS
    public static final String DEBUG_PERSONAL_INFO = "DEBUG_PERSONAL_INFO";
    private static final String SAVE_INSTANCE_STATE_KEY = "SAVE_INSTANCE_STATE_KEY";
    private static final int INTENT_MAJOR_REQUEST = 1;

    // METHODS
    private void initializeWidgets() {
        mFirstNameEditText = this.findViewById(R.id.firstNameEdit);
        mFamilyNameEditText = this.findViewById(R.id.familyNameEdit);
        mAgeEditText = this.findViewById(R.id.ageEdit);
        mEmailEditText = this.findViewById(R.id.emailEdit);
        mPhoneEditText = this.findViewById(R.id.phoneNumberEdit);
        mMajorTextView = this.findViewById(R.id.majorTextView);

        Button chooseMajorButton = this.findViewById(R.id.chooseMajorButton);
        chooseMajorButton.setOnClickListener(this);

        Button deleteMajorButton = this.findViewById(R.id.deleteMajorButton);
        deleteMajorButton.setOnClickListener(this);

        Button doneButton = this.findViewById(R.id.doneButton);
        doneButton.setOnClickListener(this);
    }

    /**
     * readSavedFile()
     * Attempts to open text file savedPersonalInformation and read the byte data, converting it into a String.
     * Returns the String expected to have been serialized.
     * */
    private String readSavedFile() {
        String fileContents;
        try {
            InputStream file = new BufferedInputStream(openFileInput("savedPersonalInformation.txt"));
            byte[] data = new byte[file.available()];
            file.read(data, 0, file.available());
            fileContents = new String(data);
            file.close();
        }
        catch (Exception noFile) {
            Log.e(DEBUG_PERSONAL_INFO, "readSavedFile() failed to read file");
            fileContents = "";
        }
        return fileContents;
    }

    /**
     * writeSavedFile()
     * Attempts to write to text file savedPersonalInformation if it exists, or creates a new file
     * with that name. Converts the fileContents parameter into bytes.
     * */
    private void writeSavedFile(String fileContents) {
        try {
            OutputStream file = new BufferedOutputStream(openFileOutput("savedPersonalInformation.txt", MODE_PRIVATE));
            file.write(fileContents.getBytes());
            file.close();
        }
        catch (Exception noFile) {
            Log.e(DEBUG_PERSONAL_INFO, "writeSavedFile() failed to write data into the file");
        }
    }

    /**
     * restoreData()
     * De-serializes the String that was built to save the data to the text file. The separator used
     * was "|" and must be escaped. Parallel arrays were built to place each piece of information
     * into the Edit Text Views or Text Views.
     * */
    private void restoreData() {
        String fileContents = readSavedFile();
        String[] restoredData = fileContents.split("\\|");

        TextView[] listOfViews = {mFirstNameEditText, mFamilyNameEditText, mAgeEditText, mEmailEditText, mPhoneEditText, mMajorTextView};
        for (int dataPosition = 0; dataPosition < restoredData.length; dataPosition++) {
            String data = restoredData[dataPosition];
            listOfViews[dataPosition].setText(data);
        }
    }

    /**
     * Manually serializes the data using the separator "|". The data was taken from each edit
     * text view and the text view that displays the selected degree and major.
     * */
    private void saveData() {
        String serializedData = mFirstNameEditText.getText().toString() + "|" + mFamilyNameEditText.getText().toString() +
                "|" + mAgeEditText.getText().toString() + "|" + mEmailEditText.getText().toString() + "|" +
                mPhoneEditText.getText().toString() + "|" + mMajorTextView.getText();

        writeSavedFile(serializedData);
    }

    // ACTIVITY LIFECYCLE
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_information);

        initializeWidgets();
        restoreData();
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        if (savedInstanceState == null) {
            return;
        }

        String[] personalInfoData = savedInstanceState.getStringArray(SAVE_INSTANCE_STATE_KEY);
        TextView[] listOfViews = {mFirstNameEditText, mFamilyNameEditText, mAgeEditText, mEmailEditText, mPhoneEditText, mMajorTextView};

        if (personalInfoData == null) {
            return;
        }

        for (int dataIndex = 0; dataIndex < personalInfoData.length; dataIndex++) {
            listOfViews[dataIndex].setText(personalInfoData[dataIndex]);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        String[] personalInfoData = { mFirstNameEditText.getText().toString(),
                mFamilyNameEditText.getText().toString(), mAgeEditText.getText().toString(),
                mEmailEditText.getText().toString(), mPhoneEditText.getText().toString(),
                mMajorTextView.getText().toString() };
        outState.putStringArray(SAVE_INSTANCE_STATE_KEY, personalInfoData);
    }

    // IMPLEMENTATION METHODS
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.chooseMajorButton:
                Log.d(DEBUG_PERSONAL_INFO, "Choose Major Button Clicked");

                // Navigate to the Major Selection Activity
                Intent toChooseMajorIntent = new Intent(this, ChooseMajorActivity.class);
                startActivityForResult(toChooseMajorIntent, INTENT_MAJOR_REQUEST);
                break;
            case R.id.deleteMajorButton:
                Log.d(DEBUG_PERSONAL_INFO, "Delete Major Button Clicked");

                // Clear the text view displaying the major
                mMajorTextView.setText("");
                break;
            case R.id.doneButton:
                Log.d(DEBUG_PERSONAL_INFO, "Done Button Clicked");

                saveData();
                break;
            default:
                break;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != INTENT_MAJOR_REQUEST) {
            return;
        }
        switch (resultCode) {
            case RESULT_OK:
                // Returning to this activity will populate the major text view only if a
                // major was selected.
                mMajorTextView.setText(data.getStringExtra("major"));
                break;
            case RESULT_CANCELED:
                break;
        }
    }
}
