package thucnguyen.cs64601_assignment_3;

import android.graphics.Canvas;
import android.graphics.Paint;

/**
 * The object representing the filled circle that will be drawn on the canvas.
 * Contains properties for its position (positionX, positionY) and velocity (velocityX, velocityY)
 * as well as a radius and mass and the paint property for the color.
 * */
public class GrowingCircle {

    // PROPERTIES //
    private float mass = 10f;
    private float positionX;
    private float positionY;
    private float velocityX;
    private float velocityY;
    private float radius;
    private Paint paint;

    // CONSTRUCTOR //
    public GrowingCircle(float x, float y, float radius, Paint paint) {
        this.positionX = x;
        this.positionY = y;
        this.radius = radius;
        this.paint = paint;
        this.velocityX = 0f;
        this.velocityY = 0f;
    }

    public void drawOn(Canvas canvas) {
        canvas.drawCircle(positionX, positionY, radius, paint);
    }


    public float getMass() {
        return mass;
    }

    public void setMass(float mass) {
        this.mass = mass;
    }

    public void setRadius(float radius) {
        this.radius = radius;
    }

    public float getRadius() {
        return radius;
    }

    public float getPositionX() {
        return positionX;
    }

    public float getPositionY() {
        return positionY;
    }

    public void setPositionX(float positionX) {
        this.positionX = positionX;
    }

    public void setPositionY(float positionY) {
        this.positionY = positionY;
    }

    public float getVelocityX() {
        return velocityX;
    }

    public void setVelocityX(float velocityX) {
        this.velocityX = velocityX;
    }

    public float getVelocityY() {
        return velocityY;
    }

    public void setVelocityY(float velocityY) {
        this.velocityY = velocityY;
    }
}
