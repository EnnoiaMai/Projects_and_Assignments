package thucnguyen.cs64601_assignment_3;

import android.content.Context;
import android.graphics.Canvas;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

import java.util.ArrayList;

/**
 * The Canvas that is in charge of drawing circles on its own view.
 * addCircle()              - adds a circle to the list and thus the canvas
 * returnCircleTouched()    - returns the circle in which the coordinates are contained in
 *
 * // CIRCLE COLLISION //
 * handleCollisions()       - iterates through list to check if any 2 pair of circles collided
 * detectCircleCollision()  - uses distance between centers of circles to detect collision
 * setVelocitiesAfterCollision - sets new velocities of respective circles after collision
 *
 * // WALL COLLISION //
 * didHitWallX()            - checks if a circle went beyond boundaries of canvas in x direction
 * didHitWallY()            - checks if a circle went beyond boundaries of canvas in y direction
 * didVelocityTerminate()   - checks if a circle's velocity changed signs (reached zero)
 *
 * updateCirclePositions() - updates each circle's position by adding to their velocities over time.
 *                         Also calls or delegates to circle and wall collision methods on each update.
 * */
public class CircleCanvasView extends View {

    // WIDGETS AND PROPERTIES //
    private ArrayList<GrowingCircle> listOfCircles = new ArrayList<>(15);
    private int canvasWidth;
    private int canvasHeight;

    // DEBUG AND CONSTANTS //
    public static final String DEBUG_CANVAS = "DEBUG_CANVAS";
    private static final float WALL_COLLISION_SPEED_LOSS = 8f;

    // METHODS //
    /**
     * addCircle()
     * Adds the circle to the current list of circles
     * */
    public void addCircle(GrowingCircle circle) {
        Log.d(DEBUG_CANVAS, "addCircle()");

        listOfCircles.add(circle);
    }

    /**
     * returnCircleTouched()
     * Goes through the list of circles and returns a reference to the GrowingCircle object
     * that was "touched" by checking to see if the x and y coordinate making up the point
     * of touch were contained in the circle's boundaries.
     * */
    public GrowingCircle returnCircleTouched(float x, float y) {
        GrowingCircle circleTouched = null;
        for (GrowingCircle circle : listOfCircles) {
            if (Math.pow(x - circle.getPositionX(), 2) + Math.pow(y - circle.getPositionY(), 2) < Math.pow(circle.getRadius(), 2)) {
                circleTouched = circle;
                break;
            }
        }
        return circleTouched;
    }

    /*==================================== CIRCLE COLLISION ======================================*/
    /**
     * handleCollisions()
     * Iterates through the list of circles and compares each unique pair of circles
     * to check if any pair has collided. Delegates to detectCircleCollision() to
     * determine this and calls setVelocitiesAfterCollision() on the pair of circle objects
     * if a collision has occurred. O(n^2) efficiency.
     * */
    private void handleCollisions() {
        // Collision with other circles
        for (int circle1Index = 0; circle1Index < listOfCircles.size(); circle1Index++) {
            GrowingCircle circle1 = listOfCircles.get(circle1Index);

            for (int circle2Index = circle1Index + 1; circle2Index < listOfCircles.size(); circle2Index++) {
                GrowingCircle circle2 = listOfCircles.get(circle2Index);

                // If circles collide, change direction of their velocities
                if (detectCircleCollision(circle1.getPositionX(), circle1.getPositionY(),
                        circle2.getPositionX(), circle2.getPositionY(),
                        circle1.getRadius(), circle2.getRadius())) {
                    setVelocitiesAfterCollision(circle1, circle2);
                }
            }
        }
    }

    /**
     * detectCircleCollision()
     * Uses distance formula to determine if two circles are touching or intersecting.
     * If they do then a collision has occurred.
     * Returns true if they are, false otherwise.
     * */
    private boolean detectCircleCollision(float circle1PositionX, float circle1PositionY,
                                          float circle2PositionX, float circle2PositionY,
                                          float circle1Radius, float circle2Radius) {
        float deltaX = circle2PositionX - circle1PositionX;
        float deltaY = circle2PositionY - circle1PositionY;
        float combinedRadii = circle1Radius + circle2Radius;

        return (((deltaX * deltaX) + (deltaY * deltaY)) < (combinedRadii * combinedRadii));
    }

    /**
     * setVelocitiesAfterCollision()
     * Fired after a collision occurs between two circles. The new velocities for each
     * circle in the x and y direction are set.
     * */
    private void setVelocitiesAfterCollision(GrowingCircle circle1, GrowingCircle circle2) {
        float circle1NewVelocityX = (circle1.getVelocityX() * (circle1.getMass() - circle2.getMass()) +
                (2 * circle2.getMass() * circle2.getVelocityX())) / (circle1.getMass() + circle2.getMass());
        float circle1NewVelocityY = (circle1.getVelocityY() * (circle1.getMass() - circle2.getMass()) +
                (2 * circle2.getMass() * circle2.getVelocityY())) / (circle1.getMass() + circle2.getMass());
        float circle2NewVelocityX = (circle2.getVelocityX() * (circle2.getMass() - circle1.getMass()) +
                (2 * circle1.getMass() * circle1.getVelocityX())) / (circle1.getMass() + circle2.getMass());
        float circle2NewVelocityY = (circle2.getVelocityY() * (circle2.getMass() - circle1.getMass()) +
                (2 * circle1.getMass() * circle1.getVelocityY())) / (circle1.getMass() + circle2.getMass());

        circle1.setVelocityX(circle1NewVelocityX);
        circle1.setVelocityY(circle1NewVelocityY);
        circle2.setVelocityX(circle2NewVelocityX);
        circle2.setVelocityY(circle2NewVelocityY);
    }

    /*==================================== WALL COLLISION ========================================*/
    /**
     * didHitWallX() and didHitWallY()
     * Returns true if the position of the circle has either extended the boundary in the x direction
     * or in the y direction (the boundary being the canvas width and height).
     * */
    private boolean didHitWallX(GrowingCircle circle) {
        if (circle.getPositionX() - circle.getRadius() < 0) {
            circle.setPositionX(0 + circle.getRadius());
            return true;
        }
        else if (circle.getPositionX() + circle.getRadius() > canvasWidth) {
            circle.setPositionX(canvasWidth - circle.getRadius());
            return true;
        }
        return false;
    }
    private boolean didHitWallY(GrowingCircle circle) {
        if (circle.getPositionY() - circle.getRadius() < 0) {
            circle.setPositionY(0 + circle.getRadius());
            return true;
        }
        else if (circle.getPositionY() + circle.getRadius() > canvasHeight) {
            circle.setPositionY(canvasHeight - circle.getRadius());
            return true;
        }
        return false;
    }

    /**
     * didVelocityTerminate()
     * Returns true if the velocity changed signs after either subtracting or adding it
     * from or to the constant defined by WALL_COLLISION_SPEED_LOSS.
     * */
    private boolean didVelocityTerminate(float velocity) {
        return (velocity > 0) && (velocity - WALL_COLLISION_SPEED_LOSS <= 0) ||
                (velocity < 0) && (velocity + WALL_COLLISION_SPEED_LOSS >= 0);
    }
    /*============================================================================================*/

    /**
     * updateCirclePositions()
     * Expected to be called repeatedly by postDelayed() and handler in CircleMainActivity.
     * Handles wall and circle collisions for each circle in the list, and updates their
     * velocities and their positions.
     * */
    public void updateCirclePositions() {
        for (GrowingCircle circle : listOfCircles) {
            float circleVelocityX = circle.getVelocityX();
            float circleVelocityY = circle.getVelocityY();

            // Wall Collisions
            if (didHitWallX(circle) && (!isZero(circleVelocityX)) ) {
                if (didVelocityTerminate(circleVelocityX)) {
                    circle.setVelocityX(0);
                } else {
                    float velocityXAfterCollision = (circleVelocityX > 0) ? circleVelocityX - WALL_COLLISION_SPEED_LOSS :
                            circleVelocityX + WALL_COLLISION_SPEED_LOSS;
                    circle.setVelocityX((-1) * velocityXAfterCollision);
                }
            }
            if (didHitWallY(circle) && (!isZero(circleVelocityY)) ) {
                if (didVelocityTerminate(circleVelocityY)) {
                    circle.setVelocityY(0);
                } else {
                    float velocityYAfterCollision = (circleVelocityY > 0) ? circleVelocityY - WALL_COLLISION_SPEED_LOSS :
                            circleVelocityY + WALL_COLLISION_SPEED_LOSS;
                    circle.setVelocityY((-1) * velocityYAfterCollision);
                }
            }

            // Circle Collisions
            handleCollisions();

            // Set new positions of circles in the list
            circle.setPositionX(circle.getPositionX() + circle.getVelocityX());
            circle.setPositionY(circle.getPositionY() + circle.getVelocityY());
        }
        this.invalidate();
    }

    private boolean isZero(float value) {
        return Math.abs(value) < 0.05;
    }

    // ACTIVITY LIFECYCLE //
    public CircleCanvasView(Context context, int canvasWidth, int canvasHeight) {
        super(context);

        Log.d(DEBUG_CANVAS, "canvas width = " + canvasWidth + " canvas height = " + canvasHeight);

        this.canvasWidth = canvasWidth;
        this.canvasHeight = canvasHeight;
    }

    public CircleCanvasView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }

    /**
     * onDraw()
     * Draws each circle on the canvas. Canvas must be invalidated when there is a change to
     * any of the circles' position. Expected to be called repeatedly using postDelayed() in
     * CircleMainActivity.
     * */
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        Log.d(DEBUG_CANVAS, "onDraw()");

        for (GrowingCircle circle : listOfCircles) {
            circle.drawOn(canvas);
        }
    }
}
