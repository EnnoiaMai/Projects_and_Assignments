package thucnguyen.cs64601_assignment_3;

import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Display;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;


public class CircleMainActivity extends AppCompatActivity implements View.OnTouchListener , GestureDetector.OnGestureListener {

    // WIDGETS AND PROPERTIES //
    private GestureDetector gestureDetector;
    private CircleCanvasView canvasView;
    private GrowingCircle newGrowingCircle;
    private GrowingCircle focusedGrowingCircle;
    private Handler circleGrowthHandler, circlePositionHandler;

    private Runnable growthRunnable = new Runnable() {
        @Override
        public void run() {
            grow();
            circleGrowthHandler.postDelayed(this, GROWTH_HANDLER_DELAY);
        }
    };
    private Runnable positionRunnable = new Runnable() {
        @Override
        public void run() {
            canvasView.updateCirclePositions();
            circlePositionHandler.postDelayed(this, POSITION_HANDLER_DELAY);
        }
    };

    // DEBUG AND CONSTANTS //
    public static final String DEBUG_CIRCLE_ACTIVITY = "DEBUG_CIRCLE_ACTIVITY";
    private static final float CIRCLE_RADIUS = 20f;
    private static Paint CIRCLE_COLOR;
    private static final long POSITION_HANDLER_DELAY = 100;
    private static final long GROWTH_HANDLER_DELAY = 100;
    private static final float GROWTH_RATE = 2f;
    private static final float MASS_CHANGE_RATE = 10f;

    // METHODS //
    static {
        CIRCLE_COLOR = new Paint();
        CIRCLE_COLOR.setColor(0xff336699);
    }

    /**
     * grow()
     * Increments the mass and radius of the new circle with every call by the
     * constant declared.
     * */
    private void grow() {
        Log.d(DEBUG_CIRCLE_ACTIVITY, "grow()");
        newGrowingCircle.setMass(newGrowingCircle.getMass() + MASS_CHANGE_RATE);
        newGrowingCircle.setRadius(newGrowingCircle.getRadius() + GROWTH_RATE);
        canvasView.invalidate();
    }

    // ACTIVITY LIFECYCLE //
    /**
     * onCreate()
     * First gets the screen size and stores it in the appropriate fields.
     * An instance of CircleCanvasView is created and allocated and the listeners are
     * set up for touch and gesture handling on the view.
     * Instantiate the Handlers and call postDelayed() on positionRunnable to
     * repeatedly update the positions of the circles on the canvas.
     * */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Display display = getWindowManager().getDefaultDisplay();
        Point screenSize = new Point();
        display.getSize(screenSize);
        int screenHeight = screenSize.y;
        int screenWidth = screenSize.x;

        canvasView = new CircleCanvasView(this, screenWidth, screenHeight);
        canvasView.setOnTouchListener(this);
        setContentView(canvasView);
        gestureDetector = new GestureDetector(this, this);

        circleGrowthHandler = new Handler();
        circlePositionHandler = new Handler();
        circlePositionHandler.postDelayed(positionRunnable, POSITION_HANDLER_DELAY);
    }

    /**
     * onTouch()
     * Passes any touch events to the gesture detector first before handling the motion event
     * in this method. Note that onDown() of the gesture listener is similar to MotionEvent.ACTION_DOWN
     * of the motion event object, so it will be handled in the gesture listener. onLongPress() is
     * also a method of the gesture listener, but "tap up" must be observed to stop the circle from
     * growing. ACTION_UP covers this necessity.
     * */
    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        Log.d(DEBUG_CIRCLE_ACTIVITY, "onTouch()");
        Log.d(DEBUG_CIRCLE_ACTIVITY, "Event is " + motionEvent.toString());
        Log.d(DEBUG_CIRCLE_ACTIVITY, "Number of touches: " + motionEvent.getPointerCount());
        Log.d(DEBUG_CIRCLE_ACTIVITY, "x: " + motionEvent.getX() + " y: " + motionEvent.getY());

        boolean didUseEvent = gestureDetector.onTouchEvent(motionEvent);
        Log.d(DEBUG_CIRCLE_ACTIVITY, "Gesture did consume " + didUseEvent);

        switch (motionEvent.getAction()) {
            case MotionEvent.ACTION_DOWN:
                break;
            case MotionEvent.ACTION_MOVE:
                break;
            case MotionEvent.ACTION_UP:
                Log.d(DEBUG_CIRCLE_ACTIVITY, "Touch Up");
                circleGrowthHandler.removeCallbacks(growthRunnable);
                break;
            default:
                Log.d(DEBUG_CIRCLE_ACTIVITY, "Other action: " + motionEvent.getAction());
                break;
        }
        return true;
    }

    /**
     * onDown()
     * Creates a new circle with the default radius and color.
     * Adds the circle to the list of circles field of the canvas view.
     * */
    @Override
    public boolean onDown(MotionEvent motionEvent) {
        Log.d(DEBUG_CIRCLE_ACTIVITY, "onDown()");

        GrowingCircle circleTouched = canvasView.returnCircleTouched(motionEvent.getX(), motionEvent.getY());
        if (circleTouched == null) {
            Log.d(DEBUG_CIRCLE_ACTIVITY, "No circles touched, a new one was created");
            newGrowingCircle = new GrowingCircle(motionEvent.getX(), motionEvent.getY(), CIRCLE_RADIUS, CIRCLE_COLOR);
            canvasView.addCircle(newGrowingCircle);
            canvasView.invalidate();
        }
        else {
            Log.d(DEBUG_CIRCLE_ACTIVITY, "A circle was touched and is now focused");
            focusedGrowingCircle = circleTouched;
        }

        return true;
    }

    @Override
    public void onShowPress(MotionEvent motionEvent) {
        Log.d(DEBUG_CIRCLE_ACTIVITY, "onShowPress()");
    }

    @Override
    public boolean onSingleTapUp(MotionEvent motionEvent) {
        Log.d(DEBUG_CIRCLE_ACTIVITY, "onSingleTapUp()");
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {
        Log.d(DEBUG_CIRCLE_ACTIVITY, "onScroll()");
        return false;
    }

    /**
     * onLongPress()
     * Starts up the growthRunnable using postDelayed. The runnable stops being called
     * when the user lets go of his/her finger in ACTION_DOWN of the Motion Event.
     * */
    @Override
    public void onLongPress(MotionEvent motionEvent) {
        Log.d(DEBUG_CIRCLE_ACTIVITY, "onLongPress()");
        circleGrowthHandler.postDelayed(growthRunnable, GROWTH_HANDLER_DELAY);
    }

    /**
     * Whichever circle is focused, determined by the CircleCanvasView object's returnCircleTouched()
     * method on every tap down on the canvas, will be observed to see if a fling occurs.
     * If it does, the circle's velocities in the x and y direction are set (divide by 100 to
     * reduce the magnitude of the fling).
     * */
    @Override
    public boolean onFling(MotionEvent motionEvent1, MotionEvent motionEvent2, float velocityX, float velocityY) {
        Log.d(DEBUG_CIRCLE_ACTIVITY, "onFling() velocity x: " + velocityX + " and velocity y: " + velocityY);
        focusedGrowingCircle.setVelocityX(velocityX / 100f);
        focusedGrowingCircle.setVelocityY(velocityY / 100f);
        return true;
    }
}
