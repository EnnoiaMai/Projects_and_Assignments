//
//  ViewController.swift
//  Assignment_3
//
//  Created by Thuc Nguyen on 10/6/17.
//  Copyright © 2017 cs646. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    // PROPERTIES //
    var storedColors:[Int] = [0, 0, 0]
    
    // OUTLETS //
    @IBOutlet weak var redLabel: UILabel!
    @IBOutlet weak var greenLabel: UILabel!
    @IBOutlet weak var blueLabel: UILabel!
    
    @IBOutlet weak var redTextField: UITextField!
    @IBOutlet weak var greenTextField: UITextField!
    @IBOutlet weak var blueTextField: UITextField!
    
    @IBOutlet weak var redSlider: UISlider!
    @IBOutlet weak var greenSlider: UISlider!
    @IBOutlet weak var blueSlider: UISlider!
    
    @IBOutlet weak var colorView: UIView!
    
    // ACTIONS //
    @IBAction func colorButtonPressed(_ sender: UIButton) {
        // Hide the Keyboard
        hideKeyboard()
        
        // Check if textfields' text is nil and optional bind, then check if empty and cast to Int
        guard let redValue = redTextField.text, let greenValue = greenTextField.text, let blueValue = blueTextField.text else {
            return
        }
        guard !redValue.isEmpty, !greenValue.isEmpty, !blueValue.isEmpty else {
            return
        }
        guard let redNum = Int(redValue), let greenNum = Int(greenValue), let blueNum = Int(blueValue) else {
            return
        }
        
        /* Check range of textfield values and assign it back as a tuple, then assign to sliders, textfields, and color view */
        let tuple = checkNumberRange(red: redNum, green: greenNum, blue: blueNum)
        setSliderValues(red: tuple.red, green: tuple.green, blue: tuple.blue)
        setTextAndColor(red: tuple.red, green: tuple.green, blue: tuple.blue)
    }
    
    @IBAction func sliderValueChanged(_ sender: UISlider){
        setTextAndColor(red: Int(redSlider.value), green: Int(greenSlider.value), blue: Int(blueSlider.value))
    }
    
    // FUNCTIONS //
    func checkNumberRange(red: Int, green: Int, blue: Int) -> (red: Int, green: Int, blue: Int) {
        var shouldAlert: Bool = false                   // alert if one or more values out of range
        var arrayColors: [Int] = [red, green, blue]     // store in array to iterate
        
        // Enumerate, set 0 for color values < 0 and 100 for those > 100, set new value to appropriate index
        for (index, color) in arrayColors.enumerated() {
            var newColor = color
            if (color < 0) {
                newColor = 0
                shouldAlert = true;
            }
            else if (color > 100) {
                newColor = 100
                shouldAlert = true
            }
            arrayColors[index] = newColor
        }
        
        // Display Alert to warn users
        if (shouldAlert){
            let alertController = UIAlertController(title: "Warning", message: "Input is out of range", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "Close", style: .default, handler: nil))
            self.present(alertController, animated: true, completion: nil)
        }
        return (arrayColors[0], arrayColors[1], arrayColors[2])
    }
    
    func setTextAndColor(red: Int, green: Int, blue: Int){
        // Set textfield text to rgb parameters
        redTextField.text = "\(red)"
        greenTextField.text = "\(green)"
        blueTextField.text = "\(blue)"
        
        // Set storedColors property to rgb parameters
        storedColors = [red, green, blue]
        print(storedColors)
        
        // Cast Int values to Float, then to CGFloat to set color to UIView
        colorView.backgroundColor = UIColor.init(red: CGFloat(Float(red) / 100), green: CGFloat(Float(green) / 100), blue: CGFloat(Float(blue) / 100), alpha: 1);
    }
    
    func setSliderValues(red: Int, green: Int, blue: Int) {
        redSlider.setValue(Float(red), animated: true)
        greenSlider.setValue(Float(green), animated: true)
        blueSlider.setValue(Float(blue), animated: true)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        hideKeyboard()
    }
    
    func hideKeyboard(){
        // Hide the Keyboard
        view.endEditing(false)
    }
    
    // APP LIFECYCLE //
    override func viewDidLoad() {
        super.viewDidLoad()
        // Set Keyboard Types
        redTextField.keyboardType = UIKeyboardType.numberPad
        blueTextField.keyboardType = UIKeyboardType.numberPad
        greenTextField.keyboardType = UIKeyboardType.numberPad
        redTextField.keyboardAppearance = .dark
        blueTextField.keyboardAppearance = .dark
        greenTextField.keyboardAppearance = .dark
        
        // Set Slider min and max values
        redSlider.minimumValue = 0
        redSlider.maximumValue = 100
        greenSlider.minimumValue = 0
        greenSlider.maximumValue = 100
        blueSlider.minimumValue = 0
        blueSlider.maximumValue = 100
        
        let userDefaults = UserDefaults.standard        // Grab shared defaults object
        
        if let textValuesArray = userDefaults.array(forKey: "TextValues") as? [String] {
            // Set TextFields to previously stored values
            redTextField.text = textValuesArray[0]
            greenTextField.text = textValuesArray[1]
            blueTextField.text = textValuesArray[2]
        } else {
            // Set Textfields initially to 0
            redTextField.text = "\(0)"
            greenTextField.text = "\(0)"
            blueTextField.text = "\(0)"
        }

        if let sliderValuesArray = userDefaults.array(forKey: "SliderValues") as? [Float] {
            // Set Sliders to previously stored values
            redSlider.setValue(sliderValuesArray[0], animated: true)
            greenSlider.setValue(sliderValuesArray[1], animated: true)
            blueSlider.setValue(sliderValuesArray[2], animated: true)
        } else {
            // Set Sliders initially to 0
            redSlider.setValue(0.0, animated: true)
            greenSlider.setValue(0.0, animated: true)
            blueSlider.setValue(0.0, animated: true)
        }
        
        if let colorValuesArray = userDefaults.array(forKey: "ColorValues") as? [Int] {
            // Set storedColors to previously stored values and set colorView to that rgb
            storedColors = colorValuesArray
            colorView.backgroundColor = UIColor.init(red: CGFloat(Float(storedColors[0]) / 100), green: CGFloat(Float(storedColors[1]) / 100), blue: CGFloat(Float(storedColors[2]) / 100), alpha: 1.0)
        } else {
            // Set colorView to black or rgb of 0, 0, 0
            colorView.backgroundColor = UIColor.black
        }
        
        // Register controller for notifications for app entering background
        NotificationCenter.default.addObserver(self, selector: #selector(self.applicationDidEnterBackground(_:)), name: NSNotification.Name.UIApplicationDidEnterBackground, object: nil)
    }
    
    @objc func applicationDidEnterBackground(_ notification: NSNotification){
        print("applicationDidEnterBackground")
        
        var textValuesArray: [String] = ["", "", ""]            // empty array of string
        if let redUnwrap = redTextField.text, let greenUnwrap = greenTextField.text, let blueUnwrap = blueTextField.text {
            // Optional bind to get unwrap textfields' text and set to array
            textValuesArray = [redUnwrap, greenUnwrap, blueUnwrap]
        }
        
        let sliderValuesArray = [redSlider.value, greenSlider.value, blueSlider.value]
        
        let userDefaults = UserDefaults.standard
        userDefaults.set(textValuesArray, forKey: "TextValues")
        userDefaults.set(sliderValuesArray, forKey: "SliderValues")
        userDefaults.set(storedColors, forKey: "ColorValues")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    deinit {
        // Remove observer for app entering background
        NotificationCenter.default.removeObserver(self)
    }
}

