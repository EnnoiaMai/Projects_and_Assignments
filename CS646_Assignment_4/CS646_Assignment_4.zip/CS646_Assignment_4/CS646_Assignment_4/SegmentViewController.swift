//
//  ViewController.swift
//  CS646_Assignment_4
//
//  Created by Thuc Nguyen on 10/16/17.
//  Copyright © 2017 cs646. All rights reserved.
//

import UIKit

class SegmentViewController: UIViewController {
    
    // PROPERTIES //
    lazy var progressViewController: ProgressChildViewController = {
        // Instantiate progressViewController, add as child vc, return the ProgressVC
        var viewController = self.storyboard?.instantiateViewController(withIdentifier: "ProgressChildViewController") as! ProgressChildViewController
        self.addChildVC(childViewController: viewController)
        return viewController
    }()
    
    lazy var textViewController: TextChildViewController = {
        // Instantiate textViewController, add as child vc, return the TextVC
        var viewController = self.storyboard?.instantiateViewController(withIdentifier: "TextChildViewController") as! TextChildViewController
        self.addChildVC(childViewController: viewController)
        return viewController
    }()
    
    lazy var alertViewController: AlertChildViewController = {
        // Instantiate textViewController, add as child vc, return the TextVC
        var viewController = self.storyboard?.instantiateViewController(withIdentifier: "AlertChildViewController") as! AlertChildViewController
        self.addChildVC(childViewController: viewController)
        return viewController
    }()
    
    // OUTLET AND ACTIONS //
    @IBOutlet weak var segmentControl: UISegmentedControl!
    
    @IBAction func changeChildVC(_ sender: UISegmentedControl) {
        updateChildVC()
    }
    
    // FUNCTIONS //
    func addChildVC(childViewController: UIViewController) {
        /* Add child vc, add its view as subview, set its frame to match this view's bounds. Call didMove on
         child so that child vc gets notified of lifecycle events.
         */
        addChildViewController(childViewController)
        view.addSubview(childViewController.view)
        childViewController.view.frame = view.bounds
        childViewController.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        childViewController.didMove(toParentViewController: self)
    }
    
    func updateChildVC() {
        switch segmentControl.selectedSegmentIndex {
        case 0:
            // Unhide progressViewController, hide others
            progressViewController.view.isHidden = false
            textViewController.hideKeyboard()
            textViewController.view.isHidden = true
            alertViewController.view.isHidden = true
        case 1:
            // Unhide textViewController, hide others
            progressViewController.view.isHidden = true
            textViewController.view.isHidden = false
            alertViewController.view.isHidden = true
        case 2:
            // Unhide alertViewController, hide others
            progressViewController.view.isHidden = true
            textViewController.hideKeyboard()
            textViewController.view.isHidden = true
            alertViewController.view.isHidden = false
        default:
            return
        }
    }
    
    // LIFECYCLE //
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set default segment control to first index and call updateChildVC
        segmentControl.selectedSegmentIndex = 0
        updateChildVC()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

