//
//  ProgressViewController.swift
//  CS646_Assignment_4
//
//  Created by Thuc Nguyen on 10/17/17.
//  Copyright © 2017 cs646. All rights reserved.
//

import UIKit

class ProgressChildViewController: UIViewController {
    
    // OUTLETS AND ACTIONS //
    @IBOutlet weak var switchControl: UISwitch!
    @IBOutlet weak var activityView: UIActivityIndicatorView!
    
    @IBAction func switchValueChanged(_ sender: UISwitch) {
        // If switch on, start animating, else stop
        (switchControl.isOn) ? activityView.startAnimating() : activityView.stopAnimating()
    }
    
    // LIFECYCLE //
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Style switch control and set default to off
        switchControl.onTintColor = UIColor.orange
        switchControl.tintColor = UIColor.orange
        switchControl.setOn(false, animated: false)
        
        // Style activity indicator and set animating to off
        activityView.activityIndicatorViewStyle = .whiteLarge
        activityView.color = UIColor.red
        activityView.stopAnimating()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
