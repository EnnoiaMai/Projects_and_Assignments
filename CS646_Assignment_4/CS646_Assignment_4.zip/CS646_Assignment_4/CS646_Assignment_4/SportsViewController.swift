//
//  SportsViewController.swift
//  CS646_Assignment_4
//
//  Created by Thuc Nguyen on 10/16/17.
//  Copyright © 2017 cs646. All rights reserved.
//

import UIKit

class SportsViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    // PROPERTIES //
    var sportsDictionary: [String: [String]]?
    var sportsTuple: [(country: String, sports: [String]?)] = []
    var selectedCountry: Int = 0
    
    // Keys from Sports.plist
    let keyIndia = "India", keyUSA = "USA", keyTaiwan = "Taiwan"
    
    
    // OUTLETS AND ACTIONS //
    @IBOutlet weak var pickerView: UIPickerView!
    @IBOutlet weak var sportsSlider: UISlider!
    
    @IBAction func sportsChanged(_ sender: UISlider) {
        let divisor = sportsTuple[selectedCountry].sports!.count - 1
        let threshold = 100 / Float(divisor)
        let flooredSliderValue = Int(floor(sportsSlider.value / threshold))
        if ( flooredSliderValue != pickerView.selectedRow(inComponent: 1)) {
            pickerView.selectRow(flooredSliderValue, inComponent: 1, animated: true)
        }
    }
    
    // FUNCTIONS //
    // Columns of data
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    
    // Rows of data for each component
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        guard sportsDictionary != nil else {
            return 0
        }
        
        switch component {
        case 0:
            return sportsTuple.count
        case 1:
            return sportsTuple[selectedCountry].sports!.count
        default:
            return 0
        }
    }
    
    // Data to return for each row in each component
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        guard sportsDictionary != nil else {
            return "None"
        }
        
        switch component {
        case 0:
            return sportsTuple[row].country
        case 1:
                return sportsTuple[selectedCountry].sports![row]
        default:
            return "None"
        }
    }
    
    // Fired after a row was selected
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        guard sportsDictionary != nil else {
            return
        }
        
        if (component == 0) {
            selectedCountry = row
            pickerView.reloadComponent(1)
        }
        // Update slider thumb position
        let divisor = sportsTuple[selectedCountry].sports!.count - 1
        sportsSlider.setValue(Float(pickerView.selectedRow(inComponent: 1)) * (sportsSlider.maximumValue / Float(divisor)), animated: true)
    }
    
    // LIFECYCLE //
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set this class as the delegate for pickerView
        self.pickerView.delegate = self
        self.pickerView.dataSource = self
        
        // Load data from Sports.plist
        let data: Bundle = Bundle.main
        let sportsPList: String? = data.path(forResource: "Sports", ofType: "plist")
        if sportsPList != nil {
            sportsDictionary = (NSDictionary.init(contentsOfFile: sportsPList!) as! Dictionary)
            
            // Set up sportsTuple
            sportsTuple = [(keyIndia, sportsDictionary?[keyIndia]),
                (keyUSA, sportsDictionary?[keyUSA]),
                (keyTaiwan, sportsDictionary?[keyTaiwan]) ]
            
            // Select default row
            selectedCountry = 0
            pickerView.selectRow(selectedCountry, inComponent: 0, animated: true)
        }
        
        // Set initial values for slider
        sportsSlider.minimumValue = 0.0
        sportsSlider.maximumValue = 100.0
        sportsSlider.setValue(0, animated: true)
        sportsSlider.minimumTrackTintColor = UIColor.init(red: 0.56, green: 0.16, blue: 0.16, alpha: 1.0)
        sportsSlider.maximumTrackTintColor = UIColor.black
        sportsSlider.thumbTintColor = UIColor.red
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
