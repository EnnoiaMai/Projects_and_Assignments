//
//  TextViewController.swift
//  CS646_Assignment_4
//
//  Created by Thuc Nguyen on 10/17/17.
//  Copyright © 2017 cs646. All rights reserved.
//

import UIKit

class TextChildViewController: UIViewController {
    
    // PROPERTIES AND CONSTANTS //
    let textViewPlaceholder = "Enter text here..."

    // OUTLETS AND ACTIONS //
    @IBOutlet weak var textView: UITextView!
    
    // FUNCTIONS //
    func hideKeyboard() {
        view.endEditing(false)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        hideKeyboard()
    }
    
    // Find the change in height of keyboard
    func keyboardChangeInHeight(notification: NSNotification) -> CGFloat {
        if let userInfo = notification.userInfo, let startingSize = (userInfo[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.height, let endingSize = (userInfo[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue.height {
            
            if (startingSize == endingSize) {
                return startingSize
            }
            return endingSize - startingSize
        }
        return 0
    }
    
    func deviceRotated(sizeChange: CGFloat) -> Bool {
        return (40 < abs(sizeChange)) && (abs(sizeChange) < 80)
    }
    
    @objc func keyboardWillShow(notification: NSNotification) {
        let sizeChange = keyboardChangeInHeight(notification: notification)
        if (deviceRotated(sizeChange: sizeChange)) {
            return
        }
        moveView(-1 * sizeChange)
    }
    @objc func keyboardWillHide(notification: NSNotification) {
        let sizeChange = keyboardChangeInHeight(notification: notification)
        if (deviceRotated(sizeChange: sizeChange)) {
            return
        }
        moveView(sizeChange)
    }
    func moveView(_ amount: CGFloat) {
        UIView.animate(withDuration: 0.2, animations: {
            self.textView.frame.size.height += amount
        })
    }
    // LIFECYCLE //
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Style keyboard and set default text
        textView.keyboardAppearance = .dark
        textView.autocorrectionType = .no
        textView.text = textViewPlaceholder
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        // Register view controller for keyboard notifications
        let notifications = NotificationCenter.default
        notifications.addObserver(self, selector: #selector(self.keyboardWillShow(notification:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        notifications.addObserver(self, selector: #selector(self.keyboardWillHide(notification:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        NotificationCenter.default.removeObserver(self)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
}
