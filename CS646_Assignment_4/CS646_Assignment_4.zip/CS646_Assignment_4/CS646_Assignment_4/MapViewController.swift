//
//  MapViewController.swift
//  CS646_Assignment_4
//
//  Created by Thuc Nguyen on 10/16/17.
//  Copyright © 2017 cs646. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class MapViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate, UITextFieldDelegate {
    
    // PROPERTIES //
    let region: CLLocationDistance = 10000      // distance in meters for zoom level
    let locationManager = CLLocationManager()
    var currentLocation: CLLocation?
    
    var constantsDictionary: [String: Double]?
    
    // Keys from NumericConstants.plist
    let keySanDiegoLat = "San Diego Latitude", keySanDiegoLong = "San Diego Longitude",
        keyElCajonLat = "El Cajon Latitude", keyElCajonLong = "El Cajon Longitude",
        keyEscondidoLat = "Escondido Latitude", keyEscondidoLong = "Escondido Longitude"
    
    // OUTLETS AND ACTIONS //
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var startLabel: UILabel!
    @IBOutlet weak var destinationLabel: UILabel!
    
    @IBOutlet weak var startLatitude: UITextField!
    @IBOutlet weak var startLongitude: UITextField!
    
    @IBOutlet weak var destinationLatitude: UITextField!
    @IBOutlet weak var destinationLongitude: UITextField!
    
    @IBAction func getUserLocation(_ sender: UIButton) {
        hideKeyboard()
        updateCurrentLocation()
    }
    
    @IBAction func getDirections(_ sender: UIButton) {
        hideKeyboard()
        
        guard let startLat = Double(startLatitude.text!),
            let startLong = Double(startLongitude.text!),
            let destinationLat = Double(destinationLatitude.text!),
            let destinationLong = Double(destinationLongitude.text!) else {
            return
        }
        // Make the coordinate from the values in textfields
        let startCoordinate = CLLocationCoordinate2DMake(startLat, startLong)
        let destinationCoordinate = CLLocationCoordinate2DMake(destinationLat, destinationLong)
        
        // Description of the locations
        let startPlacemark = MKPlacemark(coordinate: startCoordinate)
        let destinationPlacemark = MKPlacemark(coordinate: destinationCoordinate)
        
        // Points of interest on the map with geographic location
        let startItem = MKMapItem(placemark: startPlacemark)
        let destinationItem = MKMapItem(placemark: destinationPlacemark)
        
        let directionRequest = MKDirectionsRequest()
        directionRequest.source = startItem
        directionRequest.destination = destinationItem
        directionRequest.transportType = .automobile
        
        let directions = MKDirections(request: directionRequest)
        directions.calculate(completionHandler: {response, error in
            guard let results = response?.routes.first else {
                if let errorMade = error {
                    print(errorMade)
                    // Alert user that there was an error
                    let alertController = UIAlertController(title: "An error occurred", message: "The previous direction request is still being processed.", preferredStyle: .alert)
                    alertController.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
                    self.present(alertController, animated: true, completion: nil)
                }
                return
            }
            
            self.mapView.removeOverlays(self.mapView.overlays)
            self.mapView.add(results.polyline, level: .aboveRoads)
            
            let polylineRect = results.polyline.boundingMapRect
            self.mapView.setRegion(MKCoordinateRegionForMapRect(polylineRect), animated: true)
        })
    }
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let renderer = MKPolylineRenderer(overlay: overlay)
        renderer.strokeColor = UIColor.blue
        renderer.lineWidth = 5.0
        return renderer
    }
    
    // FUNCTIONS //
    // Centers the map using the location
    func centerMap(location: CLLocation) {
        let locationRegion = MKCoordinateRegionMakeWithDistance(location.coordinate, region, region)
        mapView.setRegion(locationRegion, animated: true)
    }
    // Setup for MKAnnotationView
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        let reuseId = "annotations"
        
        if annotation is MapAnnotations {
            var view = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId)
            
            if view == nil {
                view = MKPinAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
                view!.canShowCallout = true
            }
            else {
                view!.annotation = annotation
            }
            return view
        }
        return nil
    }

    func updateCurrentLocation() {
        if (CLLocationManager.locationServicesEnabled()){
            mapView.showsUserLocation = true
            locationManager.startUpdatingLocation()
        }
    }
    func stopUpdatingCurrentLocation() {
        if (CLLocationManager.locationServicesEnabled()){
            mapView.showsUserLocation = false
            locationManager.stopUpdatingLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        currentLocation = locations[0]
        let currentCLLocation = CLLocation(latitude: currentLocation!.coordinate.latitude, longitude: currentLocation!.coordinate.longitude)
        centerMap(location: currentCLLocation)
        
        startLatitude.text = String(currentLocation!.coordinate.latitude)
        startLongitude.text = String(currentLocation!.coordinate.longitude)
    }
    
    // Keyboard Functions
    // Hides the keyboard
    func hideKeyboard() {
        view.endEditing(false)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        hideKeyboard()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        hideKeyboard()
        return true
    }
    
    // Find the change in height of keyboard
    func keyboardChangeInHeight(notification: NSNotification) -> CGFloat {
        if let userInfo = notification.userInfo, let startingSize = (userInfo[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.height, let endingSize = (userInfo[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue.height {
            
            if (startingSize == endingSize) {
                return startingSize
            }
            return endingSize - startingSize
        }
        return 0
    }
    
    func deviceRotated(sizeChange: CGFloat) -> Bool {
        return (40 < abs(sizeChange)) && (abs(sizeChange) < 80)
    }
    
    @objc func keyboardWillShow(notification: NSNotification) {
        let sizeChange = keyboardChangeInHeight(notification: notification)
        if (deviceRotated(sizeChange: sizeChange)) {
            return
        }
        moveView(-1 * sizeChange)
    }
    @objc func keyboardWillHide(notification: NSNotification) {
        let sizeChange = keyboardChangeInHeight(notification: notification)
        if (deviceRotated(sizeChange: sizeChange)) {
            return
        }
        moveView(sizeChange)
    }
    func moveView(_ amount: CGFloat) {
        UIView.animate(withDuration: 0.2, animations: {
            self.view.frame = self.view.frame.offsetBy(dx: 0, dy: amount)
        })
    }
    
    // LIFECYCLE //
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set placeholders for textfields
        startLatitude.placeholder = "Latitude"
        startLongitude.placeholder = "Longitude"
        destinationLatitude.placeholder = "Latitude"
        destinationLongitude.placeholder = "Longitude"
        
        // Set up Keyboard
        startLatitude.keyboardType = .numbersAndPunctuation
        startLongitude.keyboardType = .numbersAndPunctuation
        destinationLatitude.keyboardType = .numbersAndPunctuation
        destinationLongitude.keyboardType = .numbersAndPunctuation
        startLatitude.keyboardAppearance = .dark
        startLongitude.keyboardAppearance = .dark
        destinationLatitude.keyboardAppearance = .dark
        destinationLongitude.keyboardAppearance = .dark
        startLatitude.delegate = self
        startLongitude.delegate = self
        destinationLatitude.delegate = self
        destinationLongitude.delegate = self
        
        // Load data from NumericConstants.plist
        let data: Bundle = Bundle.main
        let constantsPList: String? = data.path(forResource: "NumericConstants", ofType: "plist")
        if constantsPList != nil {
            constantsDictionary = (NSDictionary.init(contentsOfFile: constantsPList!) as! Dictionary)
            
            // Set starting location to San Diego, and center around El Cajon and Escondido
            if let sanDiegoLat = constantsDictionary?[keySanDiegoLat], let sanDiegoLong = constantsDictionary?[keySanDiegoLong] {
                let startingLocation = CLLocation(latitude: sanDiegoLat, longitude: sanDiegoLong)
                centerMap(location: startingLocation)
            }
            
            if let elCajonLat = constantsDictionary?[keyElCajonLat], let elCajonLong = constantsDictionary?[keyElCajonLong] {
                let elCajonLocation = MapAnnotations(title: "El Cajon", coordinate: CLLocationCoordinate2D(latitude: elCajonLat, longitude: elCajonLong), info: "City of El Cajon")
                mapView.addAnnotation(elCajonLocation)
            }
            
            if let escondidoLat = constantsDictionary?[keyEscondidoLat], let escondidoLong = constantsDictionary?[keyEscondidoLong] {
                let escondidoLocation = MapAnnotations(title: "Escondido", coordinate: CLLocationCoordinate2D(latitude: escondidoLat, longitude: escondidoLong), info: "City of Escondido")
                mapView.addAnnotation(escondidoLocation)
            }
            
            mapView.showAnnotations(mapView.annotations, animated: true)
        }
        
        locationManager.requestWhenInUseAuthorization()

        if (CLLocationManager.locationServicesEnabled()) {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(false)
        
        // Register view controller for keyboard notifications
        let notifications = NotificationCenter.default
        notifications.addObserver(self, selector: #selector(self.keyboardWillShow(notification:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        notifications.addObserver(self, selector: #selector(self.keyboardWillHide(notification:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(false)
        stopUpdatingCurrentLocation()
        NotificationCenter.default.removeObserver(self)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
}
