//
//  TabBarController.swift
//  CS646_Assignment_4
//
//  Created by Thuc Nguyen on 10/16/17.
//  Copyright © 2017 cs646. All rights reserved.
//

import UIKit

class TabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set default view controller as first tab
        selectedViewController = viewControllers?[0]
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
