//
//  AlertVC.swift
//  CS646_Assignment_4
//
//  Created by Thuc Nguyen on 10/17/17.
//  Copyright © 2017 cs646. All rights reserved.
//

import UIKit

class AlertChildViewController: UIViewController {
    
    // PROPERTIES AND CONSTANTS //
    let alertTitle: String = "Do you like the iphone?"
    let alertMessage: String = "Please answer by tapping the options below."
    let actionNo: String = "No", actionYes: String = "Yes"

    // OUTLETS AND ACTIONS //
    @IBAction func triggerAlert(_ sender: UIButton) {
        // Present alert controller with the question and add actions for yes and no
        let alertController = UIAlertController(title: alertTitle, message: alertMessage, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: actionNo, style: .default, handler: nil))
        alertController.addAction(UIAlertAction(title: actionYes, style: .default, handler: nil))
        self.present(alertController, animated: true, completion: nil)
    }
    
    // LIFECYCLE //
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
