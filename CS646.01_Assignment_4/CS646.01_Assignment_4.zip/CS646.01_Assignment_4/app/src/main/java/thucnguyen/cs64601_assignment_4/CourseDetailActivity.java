package thucnguyen.cs64601_assignment_4;

import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import thucnguyen.cs64601_assignment_4.model.StudentModel;

public class CourseDetailActivity extends AppCompatActivity {

    // ACTIVITY LIFECYCLE //
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_detail);

        Bundle bundle = getIntent().getExtras();
        int classID = bundle.getInt("classID");
        StudentModel currentStudent = bundle.getParcelable("student");

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        CourseDetailFragment courseDetailFragment = new CourseDetailFragment();
        Bundle args = new Bundle();
        args.putString("fragmentParent", "courses");
        args.putInt("classID", classID);
        args.putParcelable("student", currentStudent);
        courseDetailFragment.setArguments(args);

        fragmentTransaction.add(R.id.fragmentContainer, courseDetailFragment);
        fragmentTransaction.commit();
    }
}
