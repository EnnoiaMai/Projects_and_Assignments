package thucnguyen.cs64601_assignment_4.model;

/**
 * Model used to hold the data associated with the subject. This is used by the
 * SubjectAdapter to populate the list view with information about the subject in
 * FilterOptionsFragment.
 * */
public class SubjectModel {
    private String title;
    private int id;
    private String college;
    private int classes;

    public SubjectModel(String title, int id, String college, int classes) {
        this.title = title;
        this.id = id;
        this.college = college;
        this.classes = classes;
    }

    // GETTERS AND SETTERS //
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCollege() {
        return college;
    }

    public void setCollege(String college) {
        this.college = college;
    }

    public int getClasses() {
        return classes;
    }

    public void setClasses(int classes) {
        this.classes = classes;
    }

}
