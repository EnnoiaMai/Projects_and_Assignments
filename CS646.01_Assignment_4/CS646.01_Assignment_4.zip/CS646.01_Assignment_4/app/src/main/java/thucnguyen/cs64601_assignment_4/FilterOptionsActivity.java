package thucnguyen.cs64601_assignment_4;

import android.content.Intent;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class FilterOptionsActivity extends AppCompatActivity implements FilterOptionsFragment.FilterOptionsListener {

    // WIDGETS AND PROPERTIES //
    FilterOptionsFragment filterOptionsFragment;
    FilterOptionsFragment.FilterListViewData currentFilter;

    private int chosenSubjectID;
    private String chosenLevel = "";
    private String chosenStartTime = "";
    private String chosenEndTime = "";

    // DEBUG AND CONSTANTS //
    private static final String LOGCAT_FILTER_OPTIONS = "LOGCAT_FILTER_OPTIONS";

    // METHODS //

    // ACTIVITY LIFECYCLE //
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filter_options);

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        filterOptionsFragment = new FilterOptionsFragment();
        fragmentTransaction.add(R.id.fragmentContainer, filterOptionsFragment);
        fragmentTransaction.commit();
    }

    @Override
    public void onBackPressed() {

        switch (currentFilter) {
            case ALL_OPTIONS:
                Log.d(LOGCAT_FILTER_OPTIONS, "onBackPressed() - finishing activity");
                super.onBackPressed();
                break;
            case SUBJECTS:
                Log.d(LOGCAT_FILTER_OPTIONS, "onBackPressed() - refreshing list back to show all options");
                filterOptionsFragment.refreshList(FilterOptionsFragment.FilterListViewData.ALL_OPTIONS);
                break;
            case LEVEL:
                Log.d(LOGCAT_FILTER_OPTIONS, "onBackPressed() - refreshing list back to show all options");
                filterOptionsFragment.refreshList(FilterOptionsFragment.FilterListViewData.ALL_OPTIONS);
            default:
                break;
        }
    }

    // IMPLEMENTATION METHODS //
    @Override
    public void filterListViewDataChanged(FilterOptionsFragment.FilterListViewData filter) {
        currentFilter = filter;
    }

    @Override
    public void subjectChosen(int subjectID) {
        chosenSubjectID = subjectID;
    }

    @Override
    public void levelChosen(String level) {
        chosenLevel = level;
    }

    @Override
    public void timesChosen(String startTime, String endTime) {
        chosenStartTime = startTime;
        chosenEndTime = endTime;
    }

    @Override
    public void confirm() {
        // Put data in activity to pass back to activity that started this (RegistrationTabActivity)
        Intent backToCoursesFragment= getIntent();
        backToCoursesFragment.putExtra("subjectID", chosenSubjectID);
        backToCoursesFragment.putExtra("level", chosenLevel);
        backToCoursesFragment.putExtra("startTime", chosenStartTime);
        backToCoursesFragment.putExtra("endTime", chosenEndTime);
        setResult(RESULT_OK, backToCoursesFragment);
        finish();
    }
}
