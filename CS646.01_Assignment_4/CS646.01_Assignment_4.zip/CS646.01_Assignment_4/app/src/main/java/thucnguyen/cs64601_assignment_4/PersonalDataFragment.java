package thucnguyen.cs64601_assignment_4;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedOutputStream;
import java.io.OutputStream;
import java.util.regex.Pattern;


/**
 * A simple {@link Fragment} subclass.
 */
public class PersonalDataFragment extends Fragment implements View.OnClickListener {

    // WIDGETS AND PROPERTIES //
    private EditText firstNameEdit, lastNameEdit, sdsuIDEdit, emailEdit, passwordEdit;
    private TextView firstNameError, lastNameError, sdsuIDError, emailError, passwordError;
    private Button submitButton;

    // DEBUG AND CONSTANTS //
    private static final String LOGCAT_PERSONAL_FRAG = "LOGCAT_PERSONAL_FRAG";
    private static final String SAVE_INSTANCE_STATE_KEY = "personalInfoData";

    // METHODS //
    /**
     * writeSavedFile()
     * Attempts to write to text file savedPersonalInformation if it exists, or creates a new file
     * with that name. Converts the fileContents parameter into bytes.
     * */
    private void writeSavedFile(String fileContents) {
        Log.d(LOGCAT_PERSONAL_FRAG, "writeSavedFile()");

        try {
            OutputStream file = new BufferedOutputStream(getActivity().openFileOutput("savedPersonalInformation.txt", Activity.MODE_PRIVATE));
            file.write(fileContents.getBytes());
            file.close();
        }
        catch (Exception noFile) {
            Log.e(LOGCAT_PERSONAL_FRAG, "writeSavedFile() failed to write data into the file.");
        }
    }

    /**
     * saveData()
     * Manually serializes the data using the separator "|". The data was taken from each edit
     * text view.
     * */
    private void saveData() {
        Log.d(LOGCAT_PERSONAL_FRAG, "saveData()");

        String serializedData = firstNameEdit.getText().toString() + "|" + lastNameEdit.getText().toString() +
                "|" + sdsuIDEdit.getText().toString() + "|" + passwordEdit.getText().toString() + "|" +
                emailEdit.getText().toString();
        writeSavedFile(serializedData);
    }

    private boolean validateStudent() {
        Log.d(LOGCAT_PERSONAL_FRAG, "validateStudent()");

        boolean success = true;

        // Validate first name
        if (firstNameEdit.getText().toString().trim().length() == 0) {
            displayErrorAndMessage(firstNameError, getActivity().getString(R.string.sign_in_first_name_error));
            success = false;
        } else {
            firstNameError.setVisibility(View.INVISIBLE);
        }

        // Validate last name
        if (lastNameEdit.getText().toString().trim().length() == 0) {
            displayErrorAndMessage(lastNameError, getActivity().getString(R.string.sign_in_last_name_error));
            success = false;
        } else {
            lastNameError.setVisibility(View.INVISIBLE);
        }

        // Roughly Validate SDSU Red ID
        String sdsuIDRegex = "^\\d{9}$";
        boolean sdsuIDRegexResult = Pattern.matches(sdsuIDRegex,  sdsuIDEdit.getText().toString());
        if (!sdsuIDRegexResult) {
            displayErrorAndMessage(sdsuIDError, getActivity().getString(R.string.sign_in_id_error));
            success = false;
        } else {
            sdsuIDError.setVisibility(View.INVISIBLE);
        }

        // Roughly Validate Password
        String passwordRegex = "^.{8,}$";
        boolean passwordRegexResult = Pattern.matches(passwordRegex, passwordEdit.getText().toString());
        if (!passwordRegexResult) {
            displayErrorAndMessage(passwordError, getActivity().getString(R.string.sign_in_password_error));
            success = false;
        } else {
            passwordError.setVisibility(View.INVISIBLE);
        }

        if (emailEdit.getText().toString().trim().length() == 0) {
            displayErrorAndMessage(emailError, getActivity().getString(R.string.sign_in_email_error));
            success = false;
        } else {
            emailError.setVisibility(View.INVISIBLE);
        }

        return success;
    }

    private void postRequestStudent() {
        Log.d(LOGCAT_PERSONAL_FRAG, "validateID()");

        JSONObject data = new JSONObject();
        try {
            data.put("firstname", firstNameEdit.getText().toString());
            data.put("lastname", lastNameEdit.getText().toString());
            data.put("redid", sdsuIDEdit.getText().toString());
            data.put("password", passwordEdit.getText().toString());
            data.put("email", emailEdit.getText().toString());
        }
        catch (JSONException error) {
            Log.d(LOGCAT_PERSONAL_FRAG, error.toString());
            return;
        }

        Response.Listener<JSONObject> success = new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                Log.d(LOGCAT_PERSONAL_FRAG, response.toString());

                try {
                    String errorValue = response.getString("error");

                    // For invalid red id, error value is "Invalid Red Id"
                    String redIdRegex = "(.*)Red Id(.*)";
                    if (Pattern.matches(redIdRegex, errorValue)) {
                        Log.d(LOGCAT_PERSONAL_FRAG, "Red Id found in error value");
                        displayErrorAndMessage(sdsuIDError, getActivity().getString(R.string.sign_in_id_invalid));
                    } else {
                        Log.d(LOGCAT_PERSONAL_FRAG, "Red Id regex doesn't match");
                        sdsuIDError.setVisibility(View.INVISIBLE);
                    }

                    /* For invalid password, error value is "Password too short"
                       Or "Password has to few characters" */
                    String passwordRegex = "Password(.*)";
                    if (Pattern.matches(passwordRegex, errorValue)) {
                        Log.d(LOGCAT_PERSONAL_FRAG, "Password found in error value");
                        displayErrorAndMessage(passwordError, getActivity().getString(R.string.sign_in_password_error));
                    } else {
                        Log.d(LOGCAT_PERSONAL_FRAG, "Password regex doesn't match");
                        passwordError.setVisibility(View.INVISIBLE);
                    }

                    // For invalid email, error value is "Invalid email no @"
                    String emailRegex = "(.*)email(.*)";
                    if (Pattern.matches(emailRegex, errorValue)) {
                        Log.d(LOGCAT_PERSONAL_FRAG, "email found in error value");
                        displayErrorAndMessage(emailError, getActivity().getString(R.string.sign_in_email_invalid));
                    } else {
                        Log.d(LOGCAT_PERSONAL_FRAG, "Email regex doesn't match");
                        emailError.setVisibility(View.INVISIBLE);
                    }
                    return;
                }
                catch (JSONException error) {
                    error.printStackTrace();
                }

                if (response.has("ok")) {
                    Log.d(LOGCAT_PERSONAL_FRAG, "Calling saveDataAndNavigate()");
                    saveDataAndNavigate();
                }
            }
        };
        Response.ErrorListener failure = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d(LOGCAT_PERSONAL_FRAG, error.toString());
            }
        };

        String url = "https://bismarck.sdsu.edu/registration/addstudent";
        JsonObjectRequest postRequest = new JsonObjectRequest(url, data, success, failure);
        RequestQueue queue = Volley.newRequestQueue(this.getActivity());
        queue.add(postRequest);
    }

    private void displayErrorAndMessage(TextView view, String errorMessage) {
        view.setText(errorMessage);
        view.setVisibility(View.VISIBLE);
    }

    private void saveDataAndNavigate() {
        Log.d(LOGCAT_PERSONAL_FRAG, "saveDataAndNavigate()");

        // If successful write to saved file
        saveData();

        // Navigate to RegistrationTab with the data
        String[] studentData = { firstNameEdit.getText().toString(), lastNameEdit.getText().toString(),
                                sdsuIDEdit.getText().toString(), passwordEdit.getText().toString(),
                                emailEdit.getText().toString() };
        Intent toRegistrationTab = new Intent(this.getActivity(), RegistrationTabActivity.class);
        toRegistrationTab.putExtra("studentData", studentData);
        startActivity(toRegistrationTab);
    }

    // CONSTRUCTOR //
    public PersonalDataFragment() {
        // Required empty public constructor
    }

    // ACTIVITY LIFECYCLE //
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_personal_data, container, false);
        firstNameEdit = view.findViewById(R.id.firstNameEdit);
        lastNameEdit = view.findViewById(R.id.lastNameEdit);
        sdsuIDEdit = view.findViewById(R.id.sdsuIDEdit);
        passwordEdit = view.findViewById(R.id.passwordEdit);
        emailEdit = view.findViewById(R.id.emailEdit);

        firstNameError = view.findViewById(R.id.firstNameError);
        lastNameError = view.findViewById(R.id.lastNameError);
        sdsuIDError = view.findViewById(R.id.sdsuIDError);
        passwordError = view.findViewById(R.id.passwordError);
        emailError = view.findViewById(R.id.emailError);

        submitButton = view.findViewById(R.id.submitButton);
        submitButton.setOnClickListener(this);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        // If saveInstanceState is not null, then repopulate the edit texts
        if (savedInstanceState != null) {
            String[] personalInfoData = savedInstanceState.getStringArray(SAVE_INSTANCE_STATE_KEY);
            if (personalInfoData == null) {
                return;
            }
            EditText[] listOfEditText = { firstNameEdit, lastNameEdit, sdsuIDEdit, passwordEdit, emailEdit };
            for (int dataIndex = 0; dataIndex < listOfEditText.length; dataIndex++) {
                listOfEditText[dataIndex].setText(personalInfoData[dataIndex]);
            }
        }

    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        String[] personalInfoData = { firstNameEdit.getText().toString(), lastNameEdit.getText().toString(),
                                    sdsuIDEdit.getText().toString(), passwordEdit.getText().toString(),
                                    emailEdit.getText().toString() };
        outState.putStringArray(SAVE_INSTANCE_STATE_KEY, personalInfoData);
    }

    // ValidateStudent() -> validateID() -> validatePassword() -> validateEmail() -> saveData() and intent to navigate
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.submitButton:
                Log.d(LOGCAT_PERSONAL_FRAG, "Submit button clicked");

                // Should authorize before proceeding through app
                if (!validateStudent()) {
                    Log.d(LOGCAT_PERSONAL_FRAG, "validation of student failed");
                    return;
                }

                postRequestStudent();
                break;
            default:
                break;
        }
    }
}
