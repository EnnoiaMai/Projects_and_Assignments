package thucnguyen.cs64601_assignment_4;

import android.content.Intent;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import java.io.BufferedInputStream;
import java.io.InputStream;

public class PersonalDataActivity extends AppCompatActivity {

    // DEBUG AND CONSTANTS //
    private static final String LOGCAT_PERSONAL_DATA = "PERSONAL_DATA_ACTIVITY";

    // METHODS //
    /**
     * readSavedFile()
     * Attempts to open text file savedPersonalInformation and read the byte data, converting it
     * into a String.
     * De-serializes the String that was built to save the data to the text file. The separator used
     * was "|" and must be escaped.
     * */
    private String readSavedFile() {
        String fileContents;
        try {
            InputStream file = new BufferedInputStream(openFileInput("savedPersonalInformation.txt"));
            byte[] data = new byte[file.available()];
            file.read(data, 0, file.available());
            fileContents = new String(data);
            file.close();

            Log.d(LOGCAT_PERSONAL_DATA, "readySavedFile() able to read file. Navigate to RegistrationTab");
            String[] studentData = fileContents.split("\\|");
            Intent toRegistrationTab = new Intent(this, RegistrationTabActivity.class);
            toRegistrationTab.putExtra("studentData", studentData);
            startActivity(toRegistrationTab);
        }
        catch (Exception noFile) {
            Log.e(LOGCAT_PERSONAL_DATA, "readSavedFile() failed to read file. Navigating to Personal Data Fragment");
            fileContents = "";

            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            PersonalDataFragment personalDataFragment = new PersonalDataFragment();
            fragmentTransaction.add(R.id.fragmentContainer, personalDataFragment);
            fragmentTransaction.commit();
        }
        return fileContents;
    }


    // ACTIVITY LIFECYCLE //
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_data);

        readSavedFile();
    }

}
