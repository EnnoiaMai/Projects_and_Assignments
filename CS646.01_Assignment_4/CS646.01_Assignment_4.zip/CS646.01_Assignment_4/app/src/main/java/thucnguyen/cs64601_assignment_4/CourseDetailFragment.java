package thucnguyen.cs64601_assignment_4;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import thucnguyen.cs64601_assignment_4.model.CourseModel;
import thucnguyen.cs64601_assignment_4.networking.JsonArrayRequestWithJsonObject;
import thucnguyen.cs64601_assignment_4.model.StudentModel;


/**
 * A simple {@link Fragment} subclass.
 */
public class CourseDetailFragment extends Fragment implements View.OnClickListener {

    // WIDGETS AND PROPERTIES //
    private TextView courseUnits, courseNumber, courseTitle, courseDepartment, courseInstructor,
                    courseDays, courseTime, courseMeetingType, courseSectionNumber,
                    courseLocation, coursePrerequisite, courseDescription,
                    courseSeats, courseEnrolled, courseWaitlist;
    private Button courseActionButton;
    private TextView actionStatus;

    /**
     * Keep track of which parent the fragment was added to
     * (EnrolledDetailActivity or CourseDetailActivity)
     * */
    private CourseDetailFragmentParent currentFragmentParent;
    public enum CourseDetailFragmentParent {
        ENROLLED,
        COURSES
    }

    /**
     * Keep track of which state the action button should be in.
     * The state will determine the post method call via Volley.
     * */
    private CourseActionButtonState actionButtonState;
    private enum CourseActionButtonState {
        DROP_FROM_CLASS,
        DROP_FROM_WAITLIST,
        ENROLL_IN_CLASS,
        WAITLIST_IN_CLASS
    }

    private CertificateApplication certificateApplication;
    private CourseModel currentCourseModel;
    private StudentModel currentStudent;
    private String dropType;

    // DEBUG AND CONSTANTS //
    private static final String LOGCAT_COURSE_DETAIL = "LOGCAT_COURSE_DETAIL";

    // CONSTRUCTOR //
    public CourseDetailFragment() {
        // Required empty public constructor
    }

    // METHODS //
    private void getRequestClassDetails(int classID) {
        Log.d(LOGCAT_COURSE_DETAIL, "getRequestClassDetails()");

        Response.Listener<JSONObject> success = new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                Log.d(LOGCAT_COURSE_DETAIL, response.toString());

                try {

                    String[] keysString = { "units", "course#", "title", "department", "instructor", "days",
                            "startTime", "endTime", "meetingType", "section", "building", "room",
                            "prerequisite", "description"};
                    String[] keysInt = { "seats", "enrolled", "waitlist" };

                    // Consider null values for the keys used
                    String[] stringValues = new String[keysString.length];
                    int[] intValues = new int[keysInt.length];

                    for (int keyIndex = 0; keyIndex < keysString.length; keyIndex++) {
                        if (response.isNull(keysString[keyIndex])) {
                            stringValues[keyIndex] = "";
                        }
                        else {
                            stringValues[keyIndex] = response.getString(keysString[keyIndex]);
                        }
                    }
                    for (int keyIndex = 0; keyIndex < keysInt.length; keyIndex++) {
                        if (response.isNull(keysInt[keyIndex])) {
                            intValues[keyIndex] = 0;
                        }
                        else {
                            intValues[keyIndex] = response.getInt(keysInt[keyIndex]);
                        }
                    }

                    currentCourseModel = new CourseModel(response.getInt("id"),
                            stringValues[0], stringValues[1], stringValues[2], stringValues[3],
                            stringValues[4], stringValues[5], stringValues[6], stringValues[7],
                            stringValues[8], stringValues[9], stringValues[10], stringValues[11],
                            stringValues[12], stringValues[13], intValues[0], intValues[1],
                            intValues[2]);

                    populateData();
                    determineCourseActionButton();
                }
                catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };
        Response.ErrorListener failure = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d(LOGCAT_COURSE_DETAIL, "onErrorResponse - " + error.toString());
            }
        };

        certificateApplication.trustBismarckCertificate();
        String url = "https://bismarck.sdsu.edu/registration/classdetails?classid=" + String.valueOf(classID);
        JsonObjectRequest getRequest = new JsonObjectRequest(Request.Method.GET, url, null, success, failure);
        RequestQueue queue = Volley.newRequestQueue(this.getActivity());
        queue.add(getRequest);
    }

    private void populateData() {
        String unitsText = currentCourseModel.getCourseUnits() + getString(R.string.course_detail_units);
        courseUnits.setText(unitsText);
        courseNumber.setText(currentCourseModel.getCourseNumber());
        courseTitle.setText(currentCourseModel.getCourseTitle());
        courseDepartment.setText(currentCourseModel.getCourseDepartment());
        courseInstructor.setText(currentCourseModel.getCourseInstructor());

        String daysText = getString(R.string.course_detail_days) + currentCourseModel.getCourseDays();
        courseDays.setText(daysText);

        String timeText = getString(R.string.course_detail_time) + "(" + currentCourseModel.getCourseStartTime() + ") - (" +
                currentCourseModel.getCourseEndTime() + ")";
        courseTime.setText(timeText);

        String meetingText = getString(R.string.course_detail_meeting_type) + currentCourseModel.getCourseMeetingType();
        courseMeetingType.setText(meetingText);

        String sectionText = getString(R.string.course_detail_section_number) + currentCourseModel.getCourseSectionNumber();
        courseSectionNumber.setText(sectionText);

        String locationText = currentCourseModel.getCourseBuilding() + " " + currentCourseModel.getCourseRoom();
        courseLocation.setText(locationText);

        coursePrerequisite.setText(currentCourseModel.getCoursePrerequisite());
        courseDescription.setText(currentCourseModel.getCourseDescription());

        String seatsText = getString(R.string.course_detail_seats) + String.valueOf(currentCourseModel.getCourseSeats());
        courseSeats.setText(seatsText);
        String enrolledText = getString(R.string.course_detail_enrolled) + String.valueOf(currentCourseModel.getCourseEnrolled());
        courseEnrolled.setText(enrolledText);
        String waitlistText = getString(R.string.course_detail_waitlist) + String.valueOf(currentCourseModel.getCourseWaitlist());
        courseWaitlist.setText(waitlistText);
    }

    private void determineCourseActionButton() {
        switch (currentFragmentParent) {
            case ENROLLED:
                // Student can drop the course
                courseActionButton.setBackgroundResource(R.drawable.button_course_action_drop);
                courseActionButton.setText(R.string.course_detail_action_drop);

                // Depending on current status of enrollment, drop student from class or from waitlist
                if (dropType.equals("Enrolled")) {
                    Log.d(LOGCAT_COURSE_DETAIL, "actionButtonState is now DROP_FROM_CLASS");

                    actionButtonState = CourseActionButtonState.DROP_FROM_CLASS;
                }
                else if (dropType.equals("Waitlisted")) {
                    Log.d(LOGCAT_COURSE_DETAIL, "actionButtonState is now DROP_FROM_WAITLIST");

                    actionButtonState = CourseActionButtonState.DROP_FROM_WAITLIST;
                }
                break;
            case COURSES:
                // Else allow student to enroll or waitlist
                courseActionButton.setBackgroundResource(R.drawable.button_course_action);
                if (currentCourseModel.getCourseEnrolled() < currentCourseModel.getCourseSeats()) {
                    courseActionButton.setText(R.string.course_detail_action_register);

                    Log.d(LOGCAT_COURSE_DETAIL, "actionButtonState is now ENROLL_IN_CLASS");

                    actionButtonState = CourseActionButtonState.ENROLL_IN_CLASS;
                }
                else if (currentCourseModel.getCourseEnrolled() >= currentCourseModel.getCourseSeats() ||
                        currentCourseModel.getCourseSeats() == 0) {
                    courseActionButton.setText(R.string.course_detail_action_waitlist);

                    Log.d(LOGCAT_COURSE_DETAIL, "actionButtonState is now WAITLIST_IN_CLASS");

                    actionButtonState = CourseActionButtonState.WAITLIST_IN_CLASS;
                }
                break;
            default:
                break;
        }
    }

    // GET OR POST METHODS TO REGISTER, WAITLIST, OR DROP A STUDENT FROM A CLASS
    private void getRequestClassAction(String url) {
        Log.d(LOGCAT_COURSE_DETAIL, "getRequestClassAction()");

        Response.Listener<JSONObject> success = new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                Log.d(LOGCAT_COURSE_DETAIL, response.toString());

                // If error key found, then notify user of the error
                if (response.has("error")) {
                    switch (actionButtonState) {
                        case DROP_FROM_CLASS:
                            displayActionStatus(false, getActivity().getString(R.string.course_action_status_drop_class_error));
                            break;
                        case DROP_FROM_WAITLIST:
                            displayActionStatus(false, getActivity().getString(R.string.course_action_status_drop_waitlist_error));
                            break;
                        case ENROLL_IN_CLASS:
                            displayActionStatus(false, getActivity().getString(R.string.course_action_status_registered_error));
                            break;
                        case WAITLIST_IN_CLASS:
                            displayActionStatus(false, getActivity().getString(R.string.course_action_status_waitlisted_error));
                            break;
                        default:
                            break;
                    }
                }
                else if (response.has("ok")) {
                    switch (actionButtonState) {
                        case DROP_FROM_CLASS:
                            displayActionStatus(true, getActivity().getString(R.string.course_action_status_drop_class));
                            break;
                        case DROP_FROM_WAITLIST:
                            displayActionStatus(true, getActivity().getString(R.string.course_action_status_drop_waitlist));
                            break;
                        case ENROLL_IN_CLASS:
                            displayActionStatus(true, getActivity().getString(R.string.course_action_status_registered));
                            break;
                        case WAITLIST_IN_CLASS:
                            displayActionStatus(true, getActivity().getString(R.string.course_action_status_waitlisted));
                            break;
                        default:
                            break;
                    }
                }

            }
        };
        Response.ErrorListener failure = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d(LOGCAT_COURSE_DETAIL, error.toString());
            }
        };

        certificateApplication.trustBismarckCertificate();
        JsonObjectRequest getRequest = new JsonObjectRequest(Request.Method.GET, url, null, success, failure);
        RequestQueue queue = Volley.newRequestQueue(this.getActivity());
        queue.add(getRequest);
    }

    private void displayActionStatus(boolean success, String message) {
        Log.d(LOGCAT_COURSE_DETAIL, "displayActionStatus()");
        actionStatus.setText(message);
        if (success) {
            actionStatus.setTextColor(getActivity().getResources().getColor(R.color.greenPressed));
        } else {
            actionStatus.setTextColor(getActivity().getResources().getColor(R.color.dropCoursePressed));
        }
        actionStatus.setVisibility(View.VISIBLE);
    }

    private void updateStudentClasses() {
        Log.d(LOGCAT_COURSE_DETAIL, "updateCurrentStudent()");

        // Update the coursesEnrolled and coursesWaitlisted property of the student before
        // registering or waitlisting the course.

        Response.Listener<JSONObject> success = new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                Log.d(LOGCAT_COURSE_DETAIL, response.toString());

                try {
                    JSONArray enrolledClasses = response.getJSONArray("classes");
                    JSONArray waitlistedClasses = response.getJSONArray("waitlist");

                    // Convert JSONArrays to array of ints
                    int[] enrolledClassesArray = new int[enrolledClasses.length()];
                    int[] waitlistedClassesArray = new int[waitlistedClasses.length()];
                    for (int index = 0; index < enrolledClassesArray.length; index++) {
                        enrolledClassesArray[index] = enrolledClasses.getInt(index);
                    }
                    for (int index = 0; index < waitlistedClassesArray.length; index++) {
                        waitlistedClassesArray[index] = waitlistedClasses.getInt(index);
                    }

                    // Set array of ints to the student model for enrolled and waitlisted classes
                    currentStudent.setCoursesEnrolled(enrolledClassesArray);
                    currentStudent.setCoursesWaitlisted(waitlistedClassesArray);

                    validateConflicts();
                }
                catch (JSONException error) {
                    error.printStackTrace();
                }
            }
        };
        Response.ErrorListener failure = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d(LOGCAT_COURSE_DETAIL, error.toString());
            }
        };

        certificateApplication.trustBismarckCertificate();
        String url = "https://bismarck.sdsu.edu/registration/studentclasses?redid=" + currentStudent.getRedID()
                + "&password=" + currentStudent.getPassword();
        JsonObjectRequest getRequest = new JsonObjectRequest(Request.Method.GET , url, null, success, failure);
        RequestQueue queue = Volley.newRequestQueue(this.getActivity());
        queue.add(getRequest);
    }

    // VALIDATION METHODS //
    private void validateConflicts() {
        Log.d(LOGCAT_COURSE_DETAIL, "validateConflicts()");

        if (checkMaxNumberOfCourses()) {
            displayActionStatus(false, getActivity().getString(R.string.course_action_status_max_classes));
            return;
        }

        if (checkCourseAlreadyAdded()) {
            displayActionStatus(false, getActivity().getString(R.string.course_action_status_already_registered));
            return;
        }

        postRequestTimeConflict();
    }

    private boolean checkMaxNumberOfCourses() {
        Log.d(LOGCAT_COURSE_DETAIL, "checkMaxNumberOfCourses()");

        int totalNumberOfCourses = currentStudent.getCoursesEnrolled().length + currentStudent.getCoursesWaitlisted().length;
        return (totalNumberOfCourses >= 3);
    }

    private boolean checkCourseAlreadyAdded() {
        Log.d(LOGCAT_COURSE_DETAIL, "checkCourseAlreadyAdded()");

        int[] coursesEnrolled = currentStudent.getCoursesEnrolled();
        int[] coursesWaitlisted = currentStudent.getCoursesWaitlisted();

        for (int id : coursesEnrolled) {
            if (currentCourseModel.getCourseID() == id) {
                return true;
            }
        }
        for (int id : coursesWaitlisted) {
            if (currentCourseModel.getCourseID() == id) {
                return true;
            }
        }

        return false;
    }

    private void postRequestTimeConflict() {
        Log.d(LOGCAT_COURSE_DETAIL, "getRequestTimeConflict()");

        JSONArray classIDs = new JSONArray();
        for (int id : currentStudent.getCoursesEnrolled()) {
            classIDs.put(id);
        }
        for (int id : currentStudent.getCoursesWaitlisted()) {
            classIDs.put(id);
        }

        final JSONObject data = new JSONObject();
        try {
            data.put("classids", classIDs);
        }
        catch (JSONException error) {
            Log.d(LOGCAT_COURSE_DETAIL, "JSON error", error);
            return;
        }

        Response.Listener<JSONArray> success = new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                Log.d(LOGCAT_COURSE_DETAIL, response.toString());

                String[] listOfStartTimes = new String[response.length()];
                String[] listOfEndTimes = new String[response.length()];

                try {
                    for (int i = 0; i < response.length(); i++) {
                        JSONObject jsonObject = response.getJSONObject(i);
                        listOfStartTimes[i] = jsonObject.getString("startTime");
                        listOfEndTimes[i] = jsonObject.getString("endTime");
                    }
                }
                catch (JSONException error) {
                    error.printStackTrace();
                }
                checkCourseTimeConflict(listOfStartTimes, listOfEndTimes);
            }
        };
        Response.ErrorListener failure = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d(LOGCAT_COURSE_DETAIL, "onErrorResponse - " + error.toString());
            }
        };

        certificateApplication.trustBismarckCertificate();
        String url = "https://bismarck.sdsu.edu/registration/classdetails";
        JsonArrayRequestWithJsonObject postRequest = new JsonArrayRequestWithJsonObject(Request.Method.POST,
                url, data, success, failure);
        RequestQueue queue = Volley.newRequestQueue(this.getActivity());
        queue.add(postRequest);
    }

    private void checkCourseTimeConflict(String[] startTimes, String[] endTimes) {
        Log.d(LOGCAT_COURSE_DETAIL, "checkCourseTimeConflict()");

        // Check that current course time doesn't conflict with any times for classes enrolled/waitlisted

        int currentCourseStartTime = Integer.parseInt(currentCourseModel.getCourseStartTime());
        int currentCourseEndTime = Integer.parseInt(currentCourseModel.getCourseEndTime());

        for (int index = 0; index < startTimes.length; index++) {
            int startTime = Integer.parseInt(startTimes[index]);
            int endTime = Integer.parseInt(endTimes[index]);

            if ( (currentCourseStartTime >= startTime && currentCourseStartTime <= endTime) ||
                    (currentCourseEndTime >= startTime && currentCourseEndTime <= endTime) ) {

                // A time conflict was found
                displayActionStatus(false, getActivity().getString(R.string.course_action_status_time_conflict));
                return;
            }
        }

        // If validate succeeds, call getRequestClassAction() to proceed with adding/waitlisting the student
        if (actionButtonState == CourseActionButtonState.ENROLL_IN_CLASS) {
            String url = "https://bismarck.sdsu.edu/registration/registerclass?redid=" +
                    currentStudent.getRedID() + "&password=" + currentStudent.getPassword() +
                    "&courseid=" + currentCourseModel.getCourseID();
            getRequestClassAction(url);
        }
        else if (actionButtonState == CourseActionButtonState.WAITLIST_IN_CLASS) {
            String url = "https://bismarck.sdsu.edu/registration/waitlistclass?redid=" +
                    currentStudent.getRedID() + "&password=" + currentStudent.getPassword() +
                    "&courseid=" + currentCourseModel.getCourseID();
            getRequestClassAction(url);
        }
    }

    // FRAGMENT LIFECYCLE //
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View courseDetailView = inflater.inflate(R.layout.fragment_course_detail, container, false);
        courseUnits = courseDetailView.findViewById(R.id.courseUnits);
        courseNumber = courseDetailView.findViewById(R.id.courseNumber);
        courseTitle = courseDetailView.findViewById(R.id.courseTitle);
        courseDepartment = courseDetailView.findViewById(R.id.courseDepartment);
        courseInstructor = courseDetailView.findViewById(R.id.courseInstructor);
        courseDays = courseDetailView.findViewById(R.id.courseDays);
        courseTime = courseDetailView.findViewById(R.id.courseTime);
        courseMeetingType = courseDetailView.findViewById(R.id.courseMeetingType);
        courseSectionNumber = courseDetailView.findViewById(R.id.courseSectionNumber);
        courseLocation = courseDetailView.findViewById(R.id.courseLocation);
        coursePrerequisite = courseDetailView.findViewById(R.id.coursePrerequisite);
        courseDescription = courseDetailView.findViewById(R.id.courseDescription);
        courseSeats = courseDetailView.findViewById(R.id.courseSeats);
        courseEnrolled = courseDetailView.findViewById(R.id.courseEnrolled);
        courseWaitlist = courseDetailView.findViewById(R.id.courseWaitlist);

        courseActionButton = courseDetailView.findViewById(R.id.courseActionButton);
        courseActionButton.setOnClickListener(this);

        actionStatus = courseDetailView.findViewById(R.id.courseActionStatus);
        return courseDetailView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        if (getArguments() == null) {
            return;
        }

        // Depending on the activity that called the fragment, set up the button color and text
        String fragmentParent = getArguments().getString("fragmentParent");
        int classID = getArguments().getInt("classID");
        currentStudent = getArguments().getParcelable("student");

        // TODO REMOVE AFTER
        Log.d(LOGCAT_COURSE_DETAIL, "Student details:\nFirst name: " + currentStudent.getFirstName() +
            "\nLast Name: " + currentStudent.getLastName() + "\nRed id: " + currentStudent.getRedID() +
            "\nEmail: " + currentStudent.getEmail() + "\nPassword: " + currentStudent.getPassword());

        if (fragmentParent == null) {
            return;
        }
        switch (fragmentParent) {
            case "enrolled":
                currentFragmentParent = CourseDetailFragmentParent.ENROLLED;
                dropType = getArguments().getString("dropType");
                break;
            case "courses":
                currentFragmentParent = CourseDetailFragmentParent.COURSES;
                break;
            default:
                break;
        }

        certificateApplication = new CertificateApplication();
        getRequestClassDetails(classID);
    }

    // IMPLEMENTATION METHODS //
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.courseActionButton:
                String url = "";
                switch (actionButtonState) {
                    case DROP_FROM_CLASS:
                        Log.d(LOGCAT_COURSE_DETAIL, "onClick - drop from class");

                        url = "https://bismarck.sdsu.edu/registration/unregisterclass?redid=" +
                                currentStudent.getRedID() + "&password=" + currentStudent.getPassword() +
                                "&courseid=" + currentCourseModel.getCourseID();
                        getRequestClassAction(url);
                        break;
                    case DROP_FROM_WAITLIST:
                        Log.d(LOGCAT_COURSE_DETAIL, "onClick - drop from waitlist");

                        url = "https://bismarck.sdsu.edu/registration/unwaitlistclass?redid=" +
                                currentStudent.getRedID() + "&password=" + currentStudent.getPassword() +
                                "&courseid=" + currentCourseModel.getCourseID();
                        getRequestClassAction(url);
                        break;
                    case ENROLL_IN_CLASS:
                        Log.d(LOGCAT_COURSE_DETAIL, "onClick - enroll in class");

                        updateStudentClasses();
                        break;
                    case WAITLIST_IN_CLASS:
                        Log.d(LOGCAT_COURSE_DETAIL, "onClick - waitlist in class");

                        updateStudentClasses();
                        break;
                }
                break;
            default:
                break;
        }
    }

}
