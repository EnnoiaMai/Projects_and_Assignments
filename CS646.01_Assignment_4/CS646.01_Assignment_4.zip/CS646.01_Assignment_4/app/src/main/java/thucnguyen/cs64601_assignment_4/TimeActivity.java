package thucnguyen.cs64601_assignment_4;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.regex.Pattern;

public class TimeActivity extends AppCompatActivity implements View.OnClickListener {

    // WIDGETS AND PROPERTIES //
    private Button timeConfirmButton;
    private EditText startTimeEdit, endTimeEdit;
    private TextView timeError;

    // DEBUG AND CONSTANTS //
    private static final String LOGCAT_TIME_ACTIVITY = "LOGCAT_TIME_ACTIVITY";

    // METHODS //
    private void initializeWidgets() {
        startTimeEdit = findViewById(R.id.startTimeEdit);
        endTimeEdit = findViewById(R.id.endTimeEdit);
        timeConfirmButton = findViewById(R.id.timeConfirmButton);
        timeConfirmButton.setOnClickListener(this);
        timeError = findViewById(R.id.timeError);
    }

    private void validateTime() {
        Log.d(LOGCAT_TIME_ACTIVITY, "validateTime()");

        boolean success = true;

        String timeRegex = "^(([0-1][0-9])|([2][0-4]))[0-5][0-9]$";
        if (startTimeEdit.getText().toString().trim().length() > 0) {
            if (!Pattern.matches(timeRegex, startTimeEdit.getText().toString())) {
                timeError.setVisibility(View.VISIBLE);
                success = false;
            }
        }
        if (endTimeEdit.getText().toString().trim().length() > 0) {
            if (!Pattern.matches(timeRegex, endTimeEdit.getText().toString())) {
                timeError.setVisibility(View.VISIBLE);
                success = false;
            }
        }

        // Check if end time is greater than start time if something was entered
        if (startTimeEdit.getText().toString().trim().length() > 0 &&
                endTimeEdit.getText().toString().trim().length() > 0) {
            int parsedStartTime = Integer.parseInt(startTimeEdit.getText().toString());
            int parsedEndTime = Integer.parseInt(endTimeEdit.getText().toString());

            Log.d(LOGCAT_TIME_ACTIVITY, "start time parsed is " + String.valueOf(parsedStartTime) +
                "\nend time parsed is " + String.valueOf(parsedEndTime));

            if (parsedStartTime > parsedEndTime) {
                Log.d(LOGCAT_TIME_ACTIVITY, "start time is greater than end time");

                timeError.setVisibility(View.VISIBLE);
                success = false;
            }
        }

        // If successful, send information of times back to FilterOptionsFragment
        if (success) {
            Intent returnToFilterOptions = getIntent();
            returnToFilterOptions.putExtra("startTime", startTimeEdit.getText().toString());
            returnToFilterOptions.putExtra("endTime", endTimeEdit.getText().toString());
            setResult(RESULT_OK, returnToFilterOptions);
            finish();
        }
    }

    // ACTIVITY LIFECYCLE //
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time);

        initializeWidgets();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.timeConfirmButton:
                Log.d(LOGCAT_TIME_ACTIVITY, "onClick - confirm button for time activity pressed");

                validateTime();
                break;
            default:
                break;
        }
    }
}
