package thucnguyen.cs64601_assignment_4;

import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTabHost;
import android.os.Bundle;

import thucnguyen.cs64601_assignment_4.model.StudentModel;

public class RegistrationTabActivity extends FragmentActivity {

    // WIDGETS AND PROPERTIES //
    private FragmentTabHost mTabHost;
    private StudentModel currentStudent;


    // DEBUG AND CONSTANTS //
    public static final String LOGCAT_REGISTRATION_TAB = "Registration Tab";

    // ACTIVITY LIFECYCLE //
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_tab);

        mTabHost = this.findViewById(android.R.id.tabhost);
        mTabHost.setup(this, getSupportFragmentManager(), R.id.realtabcontent);

        mTabHost.addTab(mTabHost.newTabSpec("enrolled").setIndicator("Enrolled"),
                EnrolledFragment.class, null);
        mTabHost.addTab(mTabHost.newTabSpec("course").setIndicator("Courses"),
                CoursesFragment.class, null);

        // Get student data from the intent
        if (getIntent().getExtras() != null && getIntent().hasExtra("studentData")) {
            String[] studentData = getIntent().getStringArrayExtra("studentData");
            currentStudent = new StudentModel(studentData[0], studentData[1],
                    studentData[2], studentData[3], studentData[4]);
        }
    }

    public StudentModel getCurrentStudent() {
        return currentStudent;
    }

}
