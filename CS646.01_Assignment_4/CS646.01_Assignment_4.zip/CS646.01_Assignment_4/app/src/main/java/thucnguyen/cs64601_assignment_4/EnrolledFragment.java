package thucnguyen.cs64601_assignment_4;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ListFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import thucnguyen.cs64601_assignment_4.adapters.CourseAdapter;
import thucnguyen.cs64601_assignment_4.model.CourseModel;
import thucnguyen.cs64601_assignment_4.networking.JsonArrayRequestWithJsonObject;
import thucnguyen.cs64601_assignment_4.model.StudentModel;



public class EnrolledFragment extends ListFragment implements AdapterView.OnItemClickListener,
    View.OnClickListener {

    // WIDGETS AND PROPERTIES //
    private Button resetButton;
    private TextView resetStatusText;
    private CourseAdapter enrolledListViewAdapter;

    private CertificateApplication certificateApplication;
    private StudentModel currentStudent;
    private ArrayList<CourseModel> listOfClasses;

    // DEBUG AND CONSTANTS //
    private static final String LOGCAT_ENROLLED_FRAG = "LOGCAT_ENROLLED_FRAG";

    // METHODS //
    private void getRequestStudentClasses() {
        Log.d(LOGCAT_ENROLLED_FRAG, "getRequestStudentClasses()");

        Response.Listener<JSONObject> success = new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                Log.d(LOGCAT_ENROLLED_FRAG, response.toString());

                try {
                    JSONArray enrolledClasses = response.getJSONArray("classes");
                    JSONArray waitlistedClasses = response.getJSONArray("waitlist");

                    // Convert JSONArrays to array of ints
                    int[] enrolledClassesArray = new int[enrolledClasses.length()];
                    int[] waitlistedClassesArray = new int[waitlistedClasses.length()];
                    for (int index = 0; index < enrolledClassesArray.length; index++) {
                        enrolledClassesArray[index] = enrolledClasses.getInt(index);
                    }
                    for (int index = 0; index < waitlistedClassesArray.length; index++) {
                        waitlistedClassesArray[index] = waitlistedClasses.getInt(index);
                    }

                    // Set array of ints to the student model for enrolled and waitlisted classes
                    currentStudent.setCoursesEnrolled(enrolledClassesArray);
                    currentStudent.setCoursesWaitlisted(waitlistedClassesArray);

                    // Create a new JSONArray that concatenates class ids from both classes
                    JSONArray classIDsForPost = new JSONArray();
                    for (int index = 0; index < enrolledClasses.length(); index++) {
                        classIDsForPost.put(enrolledClasses.get(index));
                    }
                    for (int index = 0; index < waitlistedClasses.length(); index++) {
                        classIDsForPost.put(waitlistedClasses.get(index));
                    }

                    postRequestClassDetails(classIDsForPost);
                }
                catch (JSONException error) {
                    error.printStackTrace();
                }
            }
        };
        Response.ErrorListener failure = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d(LOGCAT_ENROLLED_FRAG, error.toString());
            }
        };

        certificateApplication.trustBismarckCertificate();
        String url = "https://bismarck.sdsu.edu/registration/studentclasses?redid=" + currentStudent.getRedID()
                + "&password=" + currentStudent.getPassword();
        JsonObjectRequest getRequest = new JsonObjectRequest(Request.Method.GET , url, null, success, failure);
        RequestQueue queue = Volley.newRequestQueue(this.getActivity());
        queue.add(getRequest);
    }

    private void postRequestClassDetails(JSONArray classIDs) {
        Log.d(LOGCAT_ENROLLED_FRAG, "postRequestClassDetails()");

        final JSONObject data = new JSONObject();
        try {
            data.put("classids", classIDs);
        }
        catch (JSONException error) {
            Log.d(LOGCAT_ENROLLED_FRAG, "JSON error", error);
            return;
        }

        Response.Listener<JSONArray> success = new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                Log.d(LOGCAT_ENROLLED_FRAG, response.toString());

                listOfClasses.clear();
                try {
                    String[] keysString = { "units", "course#", "title", "instructor", "days",
                            "startTime", "endTime" };
                    String[] keysInt = { "seats", "enrolled", "waitlist" };

                    for (int i = 0; i < response.length(); i++) {
                        JSONObject jsonObject = response.getJSONObject(i);

                        // Get course id first
                        int courseID = jsonObject.getInt("id");

                        // Prepare enrollmentStatus as either "Enrolled" or "Waitlisted" by comparing course ids
                        String enrollmentStatus = "";
                        int[] coursesEnrolled = currentStudent.getCoursesEnrolled();
                        int[] coursesWaitlisted = currentStudent.getCoursesWaitlisted();
                        for (int index = 0; index < coursesEnrolled.length; index++) {
                            Log.d(LOGCAT_ENROLLED_FRAG, "enrolled class id is: " + coursesEnrolled[index]);

                            if (courseID == coursesEnrolled[index]) {
                                enrollmentStatus = "Enrolled";
                                break;
                            }
                        }
                        for (int index = 0; index < coursesWaitlisted.length; index++) {
                            Log.d(LOGCAT_ENROLLED_FRAG, "waitlisted class id is: " + coursesWaitlisted[index]);

                            if (courseID == coursesWaitlisted[index]) {
                                enrollmentStatus = "Waitlisted";
                                break;
                            }
                        }

                        // Consider null values for the keys used
                        String[] stringValues = new String[keysString.length];
                        int[] intValues = new int[keysInt.length];

                        for (int keyIndex = 0; keyIndex < keysString.length; keyIndex++) {
                            if (jsonObject.isNull(keysString[keyIndex])) {
                                stringValues[keyIndex] = "";
                            }
                            else {
                                stringValues[keyIndex] = jsonObject.getString(keysString[keyIndex]);
                            }
                        }
                        for (int keyIndex = 0; keyIndex < keysInt.length; keyIndex++) {
                            if (jsonObject.isNull(keysInt[keyIndex])) {
                                intValues[keyIndex] = 0;
                            }
                            else {
                                intValues[keyIndex] = jsonObject.getInt(keysInt[keyIndex]);
                            }
                        }

                        CourseModel courseModel = new CourseModel(courseID,
                                stringValues[0], stringValues[1],
                                stringValues[2], stringValues[3],
                                stringValues[4], stringValues[5],
                                stringValues[6], intValues[0],
                                intValues[1], intValues[2], enrollmentStatus);
                        listOfClasses.add(courseModel);
                    }
                    refreshCourseList();
                }
                catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };
        Response.ErrorListener failure = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d(LOGCAT_ENROLLED_FRAG, "onErrorResponse - " + error.toString());
            }
        };

        certificateApplication.trustBismarckCertificate();
        String url = "https://bismarck.sdsu.edu/registration/classdetails";
        JsonArrayRequestWithJsonObject postRequest = new JsonArrayRequestWithJsonObject(Request.Method.POST,
                url, data, success, failure);

        RequestQueue queue = Volley.newRequestQueue(this.getActivity());
        queue.add(postRequest);
    }

    private void getRequestResetStudent() {
        Log.d(LOGCAT_ENROLLED_FRAG, "getRequestResetStudent()");

        Response.Listener<JSONObject> success = new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                Log.d(LOGCAT_ENROLLED_FRAG, response.toString());

                if (response.has("ok")) {
                    resetStatusText.setText(getActivity().getString(R.string.reset_status_success));
                    resetStatusText.setTextColor(getActivity().getResources().getColor(R.color.greenPressed));
                } else {
                    resetStatusText.setText(getActivity().getString(R.string.reset_status_error));
                    resetStatusText.setTextColor(getActivity().getResources().getColor(R.color.dropCoursePressed));
                }
                resetStatusText.setVisibility(View.VISIBLE);
                resetStatusText.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        resetStatusText.setVisibility(View.INVISIBLE);
                    }
                }, 3000);

                // Call getRequestStudentClasses() to refresh the list with the new student data
                getRequestStudentClasses();
            }
        };
        Response.ErrorListener failure = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d(LOGCAT_ENROLLED_FRAG, error.toString());

            }
        };

        certificateApplication.trustBismarckCertificate();
        String url = "https://bismarck.sdsu.edu/registration/resetstudent?redid=" + currentStudent.getRedID()
                + "&password=" + currentStudent.getPassword();
        JsonObjectRequest getRequest = new JsonObjectRequest(Request.Method.GET , url, null, success, failure);
        RequestQueue queue = Volley.newRequestQueue(this.getActivity());
        queue.add(getRequest);
    }

    private void refreshCourseList() {
        Log.d(LOGCAT_ENROLLED_FRAG, "refreshCourseList()");

        enrolledListViewAdapter.notifyDataSetChanged();
    }

    // CONSTRUCTOR //
    public EnrolledFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_enrolled, container, false);
        resetButton = view.findViewById(R.id.resetButton);
        resetButton.setOnClickListener(this);
        resetStatusText = view.findViewById(R.id.resetStatusText);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        listOfClasses = new ArrayList<>(5);
        enrolledListViewAdapter = new CourseAdapter(getActivity(), listOfClasses, CourseAdapter.CourseAdapterParent.ENROLLED);
        setListAdapter(enrolledListViewAdapter);
        getListView().setOnItemClickListener(this);

        certificateApplication = new CertificateApplication();

        // Get the student from RegistrationTabActivity
        RegistrationTabActivity activity = (RegistrationTabActivity) getActivity();
        currentStudent = activity.getCurrentStudent();
    }

    @Override
    public void onResume() {
        super.onResume();

        getRequestStudentClasses();
    }

    /**
     * For clicking the items in the list view.
     * On item click, navigate to CourseDetailActivity
     * */
    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        Log.d(RegistrationTabActivity.LOGCAT_REGISTRATION_TAB, "EnrolledFragment - Position of click: " + i);
        Log.d(RegistrationTabActivity.LOGCAT_REGISTRATION_TAB, "EnrolledFragment - ID of click: " + l);

        Intent toEnrolledDetailActivity = new Intent(this.getActivity(), EnrolledDetailActivity.class);
        toEnrolledDetailActivity.putExtra("classID", listOfClasses.get(i).getCourseID());
        toEnrolledDetailActivity.putExtra("student", currentStudent);
        toEnrolledDetailActivity.putExtra("dropType", listOfClasses.get(i).getEnrollmentStatus());
        startActivity(toEnrolledDetailActivity);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.resetButton:
                Log.d(LOGCAT_ENROLLED_FRAG, "onClick - reset button was clicked");

                getRequestResetStudent();
                break;
            default:
                break;
        }
    }
}
