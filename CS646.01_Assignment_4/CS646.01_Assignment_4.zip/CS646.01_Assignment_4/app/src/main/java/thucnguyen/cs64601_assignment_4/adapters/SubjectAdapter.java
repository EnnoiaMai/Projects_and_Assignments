package thucnguyen.cs64601_assignment_4.adapters;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Locale;

import thucnguyen.cs64601_assignment_4.R;
import thucnguyen.cs64601_assignment_4.model.SubjectModel;

public class SubjectAdapter extends BaseAdapter implements View.OnClickListener {

    private Activity activity;
    private ArrayList<SubjectModel> data;

    public SubjectAdapter(Activity activity, ArrayList<SubjectModel> data) {
        this.activity = activity;
        this.data = data;
    }


    public static class SubjectViewHolder {
        public TextView subjectTitle;
        public TextView subjectCollege;
        public TextView subjectClasses;
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View rowView = view;

        // If can't reuse the row view, then create references to the the views in the layout
        if (rowView == null) {
            LayoutInflater inflater = activity.getLayoutInflater();
            rowView = inflater.inflate(R.layout.subject_adapter_layout, null);
            SubjectViewHolder viewHolder = new SubjectViewHolder();
            viewHolder.subjectTitle = rowView.findViewById(R.id.subjectTitle);
            viewHolder.subjectCollege = rowView.findViewById(R.id.subjectCollege);
            viewHolder.subjectClasses = rowView.findViewById(R.id.subjectClasses);

            rowView.setTag(viewHolder);
        }

        // Populate the data for each row using position of row and index in data
        SubjectViewHolder viewHolder = (SubjectViewHolder) rowView.getTag();
        viewHolder.subjectTitle.setText(data.get(i).getTitle());
        viewHolder.subjectCollege.setText(data.get(i).getCollege());
        viewHolder.subjectClasses.setText(String.format(Locale.US, "%d", data.get(i).getClasses()));

        return rowView;
    }

    @Override
    public void onClick(View view) {

    }
}
