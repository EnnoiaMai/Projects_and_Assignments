package thucnguyen.cs64601_assignment_4.model;

public class FilterModel {

    // PROPERTIES //
    private String filterTitle;
    private String filterMethod;

    // CONSTRUCOTR //
    public FilterModel(String filterTitle, String filterMethod) {
        this.filterTitle = filterTitle;
        this.filterMethod = filterMethod;
    }

    // GETTERS AND SETTERS //
    public String getFilterTitle() {
        return filterTitle;
    }

    public void setFilterTitle(String filterTitle) {
        this.filterTitle = filterTitle;
    }

    public String getFilterMethod() {
        return filterMethod;
    }

    public void setFilterMethod(String filterMethod) {
        this.filterMethod = filterMethod;
    }
}
