package thucnguyen.cs64601_assignment_4.model;

import android.os.Parcel;
import android.os.Parcelable;

public class StudentModel implements Parcelable {
    // PROPERTIES //
    private String firstName;
    private String lastName;
    private String redID;
    private String password;
    private String email;

    private int[] coursesEnrolled;
    private int[] coursesWaitlisted;

    // CONSTRUCTOR //
    public StudentModel(String firstName, String lastName, String redID, String password, String email) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.redID = redID;
        this.password = password;
        this.email = email;

        this.coursesEnrolled = null;
        this.coursesWaitlisted = null;
    }

    // PARCEL CONSTRUCTOR //
    public StudentModel(Parcel parcel) {
        this.firstName = parcel.readString();
        this.lastName = parcel.readString();
        this.redID = parcel.readString();
        this.password = parcel.readString();
        this.email = parcel.readString();

        this.coursesEnrolled = parcel.createIntArray();
        this.coursesWaitlisted = parcel.createIntArray();
    }

    // IMPLEMENTATION METHODS - PARCELABLE //
    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(firstName);
        parcel.writeString(lastName);
        parcel.writeString(redID);
        parcel.writeString(password);
        parcel.writeString(email);

        parcel.writeIntArray(coursesEnrolled);
        parcel.writeIntArray(coursesWaitlisted);
    }

    public static final Parcelable.Creator<StudentModel> CREATOR = new Parcelable.Creator<StudentModel>() {

        @Override
        public StudentModel createFromParcel(Parcel parcel) {
            return new StudentModel(parcel);
        }

        @Override
        public StudentModel[] newArray(int i) {
            return new StudentModel[i];
        }
    };

    // GETTERS AND SETTERS //
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getRedID() {
        return redID;
    }

    public void setRedID(String redID) {
        this.redID = redID;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int[] getCoursesEnrolled() {
        return coursesEnrolled;
    }

    public void setCoursesEnrolled(int[] coursesEnrolled) {
        this.coursesEnrolled = coursesEnrolled;
    }

    public int[] getCoursesWaitlisted() {
        return coursesWaitlisted;
    }

    public void setCoursesWaitlisted(int[] coursesWaitlisted) {
        this.coursesWaitlisted = coursesWaitlisted;
    }

}
