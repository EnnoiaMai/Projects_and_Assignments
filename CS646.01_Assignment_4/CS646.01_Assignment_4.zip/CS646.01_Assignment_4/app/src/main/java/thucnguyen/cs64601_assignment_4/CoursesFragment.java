package thucnguyen.cs64601_assignment_4;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ListFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import thucnguyen.cs64601_assignment_4.adapters.CourseAdapter;
import thucnguyen.cs64601_assignment_4.model.CourseModel;
import thucnguyen.cs64601_assignment_4.networking.JsonArrayRequestWithJsonObject;
import thucnguyen.cs64601_assignment_4.model.StudentModel;


public class CoursesFragment extends ListFragment implements AdapterView.OnItemClickListener, View.OnClickListener {

    // WIDGETS AND PROPERTIES //
    private Button courseFilterButton;

    private CourseAdapter courseListViewAdapter;
    private ArrayList<CourseModel> listOfClasses;

    private CertificateApplication certificateApplication;
    private StudentModel currentStudent;
    private int currentSubjectID;

    // DEBUG AND CONSTANTS //
    private static final String LOGCAT_COURSES_FRAGMENT = "LOGCAT_COURSES_FRAGMENT";
    public static final int INTENT_TO_FILTER_ACTIVITY = 10;

    // CONSTRUCTOR //
    public CoursesFragment() {
        // Required empty public constructor
    }

    // METHODS //
    public void getRequestClassIds(String level, String startTime, String endTime) {
        Log.d(LOGCAT_COURSES_FRAGMENT, "getRequestClassIds()");

        Response.Listener<JSONArray> success = new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                Log.d(LOGCAT_COURSES_FRAGMENT, response.toString());

                postRequestClassDetails(response);
            }
        };
        Response.ErrorListener failure = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d(LOGCAT_COURSES_FRAGMENT, error.toString());

            }
        };
        certificateApplication.trustBismarckCertificate();
        String url = "https://bismarck.sdsu.edu/registration/classidslist?subjectid=" + String.valueOf(currentSubjectID) +
                "&level=" + level + "&starttime=" + startTime + "&endtime=" + endTime;
        JsonArrayRequest getRequest = new JsonArrayRequest(url, success, failure);
        RequestQueue queue = Volley.newRequestQueue(this.getActivity());
        queue.add(getRequest);
    }

    public void postRequestClassDetails(JSONArray classIDs) {
        Log.d(LOGCAT_COURSES_FRAGMENT, "getRequestClassDetails()");

        final JSONObject data = new JSONObject();
        try {
            data.put("classids", classIDs);
        }
        catch (JSONException error) {
            Log.d(LOGCAT_COURSES_FRAGMENT, "JSON error", error);
            return;
        }

        Response.Listener<JSONArray> success = new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                Log.d(LOGCAT_COURSES_FRAGMENT, response.toString());

                listOfClasses.clear();
                try {
                    String[] keysString = { "units", "course#", "title", "instructor", "days",
                                    "startTime", "endTime" };
                    String[] keysInt = { "seats", "enrolled", "waitlist" };

                    for (int i = 0; i < response.length(); i++) {
                        JSONObject jsonObject = response.getJSONObject(i);

                        // Consider null values for the keys used
                        String[] stringValues = new String[keysString.length];
                        int[] intValues = new int[keysInt.length];

                        for (int keyIndex = 0; keyIndex < keysString.length; keyIndex++) {
                            if (jsonObject.isNull(keysString[keyIndex])) {
                                stringValues[keyIndex] = "";
                            }
                            else {
                                stringValues[keyIndex] = jsonObject.getString(keysString[keyIndex]);
                            }
                        }
                        for (int keyIndex = 0; keyIndex < keysInt.length; keyIndex++) {
                            if (jsonObject.isNull(keysInt[keyIndex])) {
                                intValues[keyIndex] = 0;
                            }
                            else {
                                intValues[keyIndex] = jsonObject.getInt(keysInt[keyIndex]);
                            }
                        }

                        CourseModel courseModel = new CourseModel(jsonObject.getInt("id"),
                                stringValues[0], stringValues[1],
                                stringValues[2], stringValues[3],
                                stringValues[4], stringValues[5],
                                stringValues[6], intValues[0],
                                intValues[1], intValues[2]);
                        listOfClasses.add(courseModel);
                    }
                    refreshCourseList();
                }
                catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };
        Response.ErrorListener failure = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d(LOGCAT_COURSES_FRAGMENT, "onErrorResponse - " + error.toString());
            }
        };

        certificateApplication.trustBismarckCertificate();
        String url = "https://bismarck.sdsu.edu/registration/classdetails";

        // CUSTOM JSONARRAYREQUEST CLASS
        JsonArrayRequestWithJsonObject postRequest = new JsonArrayRequestWithJsonObject(Request.Method.POST,
                url, data, success, failure);

        RequestQueue queue = Volley.newRequestQueue(this.getActivity());
        queue.add(postRequest);
    }

    public void refreshCourseList() {
        Log.d(LOGCAT_COURSES_FRAGMENT, "CoursesFragment - refreshCourseList()");

        courseListViewAdapter.notifyDataSetChanged();
    }

    // ACTIVITY LIFECYCLE //
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_courses, container, false);
        courseFilterButton = view.findViewById(R.id.courseFilterButton);
        courseFilterButton.setOnClickListener(this);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        listOfClasses = new ArrayList<>(50);
        courseListViewAdapter = new CourseAdapter(getActivity(), listOfClasses, CourseAdapter.CourseAdapterParent.COURSE);
        setListAdapter(courseListViewAdapter);
        getListView().setOnItemClickListener(this);

        certificateApplication = new CertificateApplication();

        // Get the student from RegistrationTabActivity
        RegistrationTabActivity activity = (RegistrationTabActivity) getActivity();
        currentStudent = activity.getCurrentStudent();
    }


    // IMPLEMENTATION METHODS //
    /**
     * For clicking the Filter button.
     * On click, navigate to FilterOptionsActivity
     * */
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.courseFilterButton:
                Log.d(LOGCAT_COURSES_FRAGMENT, "Filter Button clicked");
                Intent toFilterOptionsActivity = new Intent(this.getActivity(), FilterOptionsActivity.class);
                startActivityForResult(toFilterOptionsActivity, INTENT_TO_FILTER_ACTIVITY);
                break;
            default:
                break;
        }
    }

    /**
     * For clicking the items in the list view.
     * On item click, navigate to CourseDetailActivity
     * */
    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        Log.d(LOGCAT_COURSES_FRAGMENT, "CoursesFragment - Position of click: " + i);
        Log.d(LOGCAT_COURSES_FRAGMENT, "CoursesFragment - ID of click: " + l);

        Intent toCourseDetailActivity = new Intent(this.getActivity(), CourseDetailActivity.class);
        toCourseDetailActivity.putExtra("classID", listOfClasses.get(i).getCourseID());
        toCourseDetailActivity.putExtra("student", currentStudent);
        startActivity(toCourseDetailActivity);
    }

    /**
     * When the user successfully chooses a filter option (subject), a subject id will
     * be returned and sent to this fragment. The list will be used to populate the
     * list view with the appropriate classes.
     * */

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != CoursesFragment.INTENT_TO_FILTER_ACTIVITY) {
            return;
        }
        switch (resultCode) {
            case Activity.RESULT_OK:
                currentSubjectID = data.getIntExtra("subjectID", -1);
                String level = data.getStringExtra("level");
                String startTime = data.getStringExtra("startTime");
                String endTime = data.getStringExtra("endTime");
                if (currentSubjectID != -1) {
                    getRequestClassIds(level, startTime, endTime);
                } else {
                    Log.d(LOGCAT_COURSES_FRAGMENT, "ERROR - subjectID doesn't exists");
                }
                break;
            case Activity.RESULT_CANCELED:

                break;
        }
    }

}
