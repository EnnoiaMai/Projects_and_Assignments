package thucnguyen.cs64601_assignment_4;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.ListFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import thucnguyen.cs64601_assignment_4.adapters.FilterAdapter;
import thucnguyen.cs64601_assignment_4.adapters.SubjectAdapter;
import thucnguyen.cs64601_assignment_4.model.FilterModel;
import thucnguyen.cs64601_assignment_4.model.SubjectModel;


/**
 * A simple {@link Fragment} subclass.
 */
public class FilterOptionsFragment extends ListFragment implements AdapterView.OnItemClickListener,
        View.OnClickListener {

    // WIDGETS AND PROPERTIES //
    private Button filterConfirmButton;

    private CertificateApplication certificateApplication;
    private FilterAdapter filterAdapter;
    private SubjectAdapter subjectAdapter;
    private ArrayAdapter<String> levelAdapter;

    private ArrayList<FilterModel> listOfOptions;
    private ArrayList<SubjectModel> listOfSubjects;
    private ArrayList<String> listOfLevels;

    private FilterListViewData currentFilter;

    public enum FilterListViewData {
        ALL_OPTIONS,
        SUBJECTS,
        LEVEL
    }

    public interface FilterOptionsListener {
        void filterListViewDataChanged(FilterListViewData filter);
        void subjectChosen(int subjectID);
        void levelChosen(String level);
        void timesChosen(String startTime, String endTime);
        void confirm();
    }

    // DEBUG AND CONSTANTS //
    private static final String LOGCAT_FILTER_FRAGMENT = "LOGCAT_FILTER_FRAGMENT";
    private static final int INTENT_TIME_REQUEST_CODE = 6;

    // METHODS //
    private void getRequestForSubjects() {
        Log.d(LOGCAT_FILTER_FRAGMENT, "getRequestForSubjects()");

        Response.Listener<JSONArray> success = new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                Log.d(LOGCAT_FILTER_FRAGMENT, response.toString());

                try {
                    for (int i = 0; i < response.length(); i++) {
                        JSONObject jsonObject = response.getJSONObject(i);
                        SubjectModel subjectModel = new SubjectModel(jsonObject.getString("title"),
                                jsonObject.getInt("id"), jsonObject.getString("college"),
                                jsonObject.getInt("classes"));

                        listOfSubjects.add(subjectModel);
                    }
                    refreshList(FilterListViewData.SUBJECTS);
                }
                catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };
        Response.ErrorListener failure = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d(LOGCAT_FILTER_FRAGMENT, error.toString());

            }
        };
        certificateApplication.trustBismarckCertificate();
        String url = "https://bismarck.sdsu.edu/registration/subjectlist";
        JsonArrayRequest getRequest = new JsonArrayRequest(url, success, failure);
        RequestQueue queue = Volley.newRequestQueue(this.getActivity());
        queue.add(getRequest);
    }

    public void refreshList(FilterListViewData filterToSet) {
        Log.d(LOGCAT_FILTER_FRAGMENT, "refreshList");

        currentFilter = filterToSet;
        FilterOptionsListener listener = (FilterOptionsListener) getActivity();
        listener.filterListViewDataChanged(currentFilter);

        switch (currentFilter) {
            case ALL_OPTIONS:
                setListAdapter(filterAdapter);
                filterAdapter.notifyDataSetChanged();
                break;
            case SUBJECTS:
                setListAdapter(subjectAdapter);
                subjectAdapter.notifyDataSetChanged();
                break;
            case LEVEL:
                setListAdapter(levelAdapter);
                levelAdapter.notifyDataSetChanged();
        }
    }

    // CONSTRUCTOR //
    public FilterOptionsFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_filter_options, container, false);
        filterConfirmButton = view.findViewById(R.id.filterConfirmButton);
        filterConfirmButton.setOnClickListener(this);
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        certificateApplication = new CertificateApplication();

        listOfOptions = new ArrayList<>(3);
        FilterModel subjectFilterOption = new FilterModel(getActivity().getString(R.string.filter_adapter_subject_title), "");
        FilterModel levelFilterOption = new FilterModel(getActivity().getString(R.string.filter_adapter_level_title), "");
        FilterModel timeFilterOption = new FilterModel(getActivity().getString(R.string.filter_adapter_time_title), "");
        listOfOptions.add(subjectFilterOption);
        listOfOptions.add(levelFilterOption);
        listOfOptions.add(timeFilterOption);

        listOfSubjects = new ArrayList<>(50);

        listOfLevels = new ArrayList<>(3);
        listOfLevels.add(getActivity().getString(R.string.filter_level_lower));
        listOfLevels.add(getActivity().getString(R.string.filter_level_upper));
        listOfLevels.add(getActivity().getString(R.string.filter_level_graduate));

        filterAdapter = new FilterAdapter(getActivity(), listOfOptions);
        subjectAdapter = new SubjectAdapter(getActivity(), listOfSubjects);
        levelAdapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, listOfLevels);

        refreshList(FilterListViewData.ALL_OPTIONS);
        getListView().setOnItemClickListener(this);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode != INTENT_TIME_REQUEST_CODE) {
            return;
        }
        switch (resultCode) {
            case Activity.RESULT_OK:
                String startTime = data.getStringExtra("startTime");
                String endTime = data.getStringExtra("endTime");
                FilterOptionsListener listener = (FilterOptionsListener) getActivity();
                listener.timesChosen(startTime, endTime);

                String filterMethod = "";
                if (!startTime.equals("")) {
                    filterMethod += "Start Time: (" + startTime + ")\n";
                }
                if (!endTime.equals("")) {
                    filterMethod += "End Time: (" + endTime + ")";
                }

                listOfOptions.get(2).setFilterMethod(filterMethod);
                refreshList(FilterListViewData.ALL_OPTIONS);
                break;
            case Activity.RESULT_CANCELED:
                break;
        }
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

        FilterOptionsListener listener;

        switch (currentFilter) {
            case ALL_OPTIONS:
                if (position == 0) {
                    Log.d(LOGCAT_FILTER_FRAGMENT, "Clicked Item: Subject, refreshing list to show subjects");
                    getRequestForSubjects();
                }
                else if (position == 1) {
                    Log.d(LOGCAT_FILTER_FRAGMENT, "Clicked Item: Course Level");
                    refreshList(FilterListViewData.LEVEL);
                }
                else if (position == 2) {
                    Log.d(LOGCAT_FILTER_FRAGMENT, "Clicked Item: Time");
                    Intent toTimeActivity = new Intent(this.getActivity(), TimeActivity.class);
                    startActivityForResult(toTimeActivity, INTENT_TIME_REQUEST_CODE);
                }
                break;
            case SUBJECTS:
                Log.d(LOGCAT_FILTER_FRAGMENT, "Clicked on a subject, finishing activity");

                listener = (FilterOptionsListener) getActivity();
                listener.subjectChosen(listOfSubjects.get(position).getId());

                listOfOptions.get(0).setFilterMethod(listOfSubjects.get(position).getTitle());
                refreshList(FilterListViewData.ALL_OPTIONS);

                // Re-enable button and set appropriate drawable
                filterConfirmButton.setEnabled(true);
                filterConfirmButton.setBackgroundResource(R.drawable.button_course_action);
                break;
            case LEVEL:
                listener = (FilterOptionsListener) getActivity();
                if (position == 0) {
                    listener.levelChosen("lower");
                }
                else if (position == 1) {
                    listener.levelChosen("upper");
                }
                else if (position == 2) {
                    listener.levelChosen("graduate");
                }

                listOfOptions.get(1).setFilterMethod(listOfLevels.get(position));
                refreshList(FilterListViewData.ALL_OPTIONS);
                break;
            default:
                break;
        }

    }

    @Override
    public void onClick(View view) {
        Log.d(LOGCAT_FILTER_FRAGMENT, "onClick - confirmed button clicked");

        switch (view.getId()) {
            case R.id.filterConfirmButton:
                FilterOptionsListener listener = (FilterOptionsListener) getActivity();
                listener.confirm();
                break;
            default:
                break;
        }
    }

}
