package thucnguyen.cs64601_assignment_4.adapters;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import thucnguyen.cs64601_assignment_4.R;
import thucnguyen.cs64601_assignment_4.model.FilterModel;

public class FilterAdapter extends BaseAdapter implements View.OnClickListener {

    private Activity activity;
    ArrayList<FilterModel> data;

    public FilterAdapter(Activity activity, ArrayList<FilterModel> data) {
        this.activity = activity;
        this.data = data;
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public static class FilterViewHolder {
        TextView filterTitle;
        TextView filterMethod;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        View rowView = view;

        if (rowView == null) {
            LayoutInflater inflater = activity.getLayoutInflater();
            rowView = inflater.inflate(R.layout.filter_adapter_layout, null);
            FilterViewHolder filterViewHolder = new FilterViewHolder();
            filterViewHolder.filterTitle = rowView.findViewById(R.id.filterTitleText);
            filterViewHolder.filterMethod = rowView.findViewById(R.id.filterMethodText);

            rowView.setTag(filterViewHolder);
        }

        FilterViewHolder filterViewHolder = (FilterViewHolder) rowView.getTag();

        filterViewHolder.filterTitle.setText(data.get(position).getFilterTitle());
        filterViewHolder.filterMethod.setText(data.get(position).getFilterMethod());

        return rowView;
    }

    @Override
    public void onClick(View view) {

    }
}
