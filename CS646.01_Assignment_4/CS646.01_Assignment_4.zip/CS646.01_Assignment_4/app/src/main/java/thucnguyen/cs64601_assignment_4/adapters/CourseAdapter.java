package thucnguyen.cs64601_assignment_4.adapters;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Locale;

import thucnguyen.cs64601_assignment_4.R;
import thucnguyen.cs64601_assignment_4.model.CourseModel;

public class CourseAdapter extends BaseAdapter implements View.OnClickListener {

    private Activity activity;
    private ArrayList<CourseModel> data;

    private CourseAdapterParent adapterParent;
    public enum CourseAdapterParent {
        ENROLLED,
        COURSE
    }

    public CourseAdapter(Activity activity, ArrayList<CourseModel> data, CourseAdapterParent parent) {
        this.activity = activity;
        this.data = data;
        this.adapterParent = parent;
    }

    // OVERRIDE METHODS - BASE ADAPTER //
    /* Size of the ArrayList */
    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    /* View Holder Class for inflated XML file  */
    public static class ViewHolder {
        public TextView listCourseUnits;
        public TextView listCourseNumber;
        public TextView listCourseTitle;
        public TextView listCourseInstructor;
        public TextView listCourseDays;
        public TextView listCourseTime;
        public TextView listCourseSeats;
        public TextView listCourseEnrolled;
        public TextView listCourseWaitlist;
        public TextView listCourseStatus;
    }

    /* Create each row for the list view */
    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        View rowView = view;
        // If can't reuse the row view, then create references to the the views in the layout
        if (rowView == null) {
            LayoutInflater inflater = activity.getLayoutInflater();
            rowView = inflater.inflate(R.layout.course_adapter_layout, null);
            ViewHolder viewHolder = new ViewHolder();
            viewHolder.listCourseUnits = rowView.findViewById(R.id.adapterCourseUnits);
            viewHolder.listCourseNumber = rowView.findViewById(R.id.adapterCourseNumber);
            viewHolder.listCourseTitle = rowView.findViewById(R.id.adapterCourseTitle);
            viewHolder.listCourseInstructor = rowView.findViewById(R.id.adapterCourseInstructor);
            viewHolder.listCourseDays = rowView.findViewById(R.id.adapterCourseDays);
            viewHolder.listCourseTime = rowView.findViewById(R.id.adapterCourseTime);
            viewHolder.listCourseSeats = rowView.findViewById(R.id.adapterCourseSeats);
            viewHolder.listCourseEnrolled = rowView.findViewById(R.id.adapterCourseEnrolled);
            viewHolder.listCourseWaitlist = rowView.findViewById(R.id.adapterCourseWaitlist);
            viewHolder.listCourseStatus = rowView.findViewById(R.id.adapterCourseStatus);

            rowView.setTag(viewHolder);
        }

        // Populate the data for each row using position of row and index in data
        ViewHolder viewHolder = (ViewHolder) rowView.getTag();

        String unitsText = data.get(position).getCourseUnits() + activity.getString(R.string.course_detail_units);
        viewHolder.listCourseUnits.setText(unitsText);

        viewHolder.listCourseNumber.setText(data.get(position).getCourseNumber());
        viewHolder.listCourseTitle.setText(data.get(position).getCourseTitle());
        viewHolder.listCourseInstructor.setText(data.get(position).getCourseInstructor());

        String daysText = activity.getString(R.string.course_detail_days) + data.get(position).getCourseDays();
        viewHolder.listCourseDays.setText(daysText);

        String timeText = activity.getString(R.string.course_detail_time) + "(" +
                data.get(position).getCourseStartTime() + ") - (" + data.get(position).getCourseEndTime() + ")";
        viewHolder.listCourseTime.setText(timeText);

        viewHolder.listCourseSeats.setText(String.format(Locale.US ,"%d", data.get(position).getCourseSeats()));
        viewHolder.listCourseEnrolled.setText(String.format(Locale.US ,"%d", data.get(position).getCourseEnrolled()));
        viewHolder.listCourseWaitlist.setText(String.format(Locale.US ,"%d", data.get(position).getCourseWaitlist()));

        // Depending on adapterParent, set the status of the course
        switch (adapterParent) {
            case ENROLLED:
                // If parent is EnrolledFragment, status is either "Enrolled" or "Waitlisted"
                viewHolder.listCourseStatus.setText(data.get(position).getEnrollmentStatus());
                break;
            case COURSE:
                // If parent is CourseFragment, status is either "Available", or "Full"
                // Set the color of the status text appropriately
                if (data.get(position).getCourseEnrolled() < data.get(position).getCourseSeats()) {
                    viewHolder.listCourseStatus.setText(activity.getString(R.string.course_adapter_available));
                    viewHolder.listCourseStatus.setTextColor(activity.getResources().getColor(R.color.greenPressed));
                }
                else if (data.get(position).getCourseEnrolled() >= data.get(position).getCourseSeats() ||
                        data.get(position).getCourseSeats() == 0) {
                    viewHolder.listCourseStatus.setText(activity.getString(R.string.course_adapter_full));
                    viewHolder.listCourseStatus.setTextColor(activity.getResources().getColor(R.color.dropCoursePressed));
                }
                break;
        }

        return rowView;
    }

    // IMPLEMENTATION METHODS - ON CLICK //
    @Override
    public void onClick(View view) {

    }
}
