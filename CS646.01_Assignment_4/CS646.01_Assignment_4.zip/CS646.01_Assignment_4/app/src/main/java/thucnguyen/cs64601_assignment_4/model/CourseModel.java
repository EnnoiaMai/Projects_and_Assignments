package thucnguyen.cs64601_assignment_4.model;

/**
 * Model used to hold the data used to populate the list view in CoursesFragment
 * as well as the details displayed by TextViews in CourseDetailFragment
 * */
public class CourseModel {
    private int courseID;
    private String courseUnits;
    private String courseNumber;
    private String courseTitle;
    private String courseDepartment;
    private String courseInstructor;
    private String courseDays;
    private String courseStartTime;
    private String courseEndTime;
    private String courseMeetingType;
    private String courseSectionNumber;
    private String courseBuilding;
    private String courseRoom;
    private String coursePrerequisite;
    private String courseDescription;

    private int courseSeats;
    private int courseEnrolled;
    private int courseWaitlist;

    // List of enrolled and waitlisted classes are used in EnrolledFragment to set the status.
    private String enrollmentStatus;

    /**
     * Constructor used by CoursesFragment to show some details for the list
     * */
    public CourseModel(int courseID, String courseUnits, String courseNumber, String courseTitle,
                       String courseInstructor, String courseDays, String courseStartTime, String courseEndTime,
                       int courseSeats, int courseEnrolled, int courseWaitlist) {
        this.courseID = courseID;
        this.courseUnits = courseUnits;
        this.courseNumber = courseNumber;
        this.courseTitle = courseTitle;
        this.courseDepartment = "";
        this.courseInstructor = courseInstructor;
        this.courseDays = courseDays;
        this.courseStartTime = courseStartTime;
        this.courseEndTime = courseEndTime;
        this.courseMeetingType = "";
        this.courseSectionNumber = "";
        this.courseBuilding = "";
        this.courseRoom = "";
        this.coursePrerequisite = "";
        this.courseDescription = "";
        this.courseSeats = courseSeats;
        this.courseEnrolled = courseEnrolled;
        this.courseWaitlist = courseWaitlist;

        this.enrollmentStatus = "";
    }

    /**
     * Constructor used by EnrolledFragment to show some details for the list and the status
     * */
    public CourseModel(int courseID, String courseUnits, String courseNumber, String courseTitle,
                       String courseInstructor, String courseDays, String courseStartTime, String courseEndTime,
                       int courseSeats, int courseEnrolled, int courseWaitlist, String enrollmentStatus) {
        this.courseID = courseID;
        this.courseUnits = courseUnits;
        this.courseNumber = courseNumber;
        this.courseTitle = courseTitle;
        this.courseDepartment = "";
        this.courseInstructor = courseInstructor;
        this.courseDays = courseDays;
        this.courseStartTime = courseStartTime;
        this.courseEndTime = courseEndTime;
        this.courseMeetingType = "";
        this.courseSectionNumber = "";
        this.courseBuilding = "";
        this.courseRoom = "";
        this.coursePrerequisite = "";
        this.courseDescription = "";
        this.courseSeats = courseSeats;
        this.courseEnrolled = courseEnrolled;
        this.courseWaitlist = courseWaitlist;

        this.enrollmentStatus = enrollmentStatus;
    }

    /**
     * Constructor used for CourseDetailFragment to show full details of a specific class
     * */
    public CourseModel(int courseID, String courseUnits, String courseNumber, String courseTitle,
                       String courseDepartment, String courseInstructor, String courseDays,
                       String courseStartTime, String courseEndTime, String courseMeetingType, String courseSectionNumber,
                       String courseBuilding, String courseRoom, String coursePrerequisite, String courseDescription,
                       int courseSeats, int courseEnrolled, int courseWaitlist) {
        this.courseID = courseID;
        this.courseUnits = courseUnits;
        this.courseNumber = courseNumber;
        this.courseTitle = courseTitle;
        this.courseDepartment = courseDepartment;
        this.courseInstructor = courseInstructor;
        this.courseDays = courseDays;
        this.courseStartTime = courseStartTime;
        this.courseEndTime = courseEndTime;
        this.courseMeetingType = courseMeetingType;
        this.courseSectionNumber = courseSectionNumber;
        this.courseBuilding = courseBuilding;
        this.courseRoom = courseRoom;
        this.coursePrerequisite = coursePrerequisite;
        this.courseDescription = courseDescription;
        this.courseSeats = courseSeats;
        this.courseEnrolled = courseEnrolled;
        this.courseWaitlist = courseWaitlist;

        this.enrollmentStatus = "";
    }


    public int getCourseID() {
        return courseID;
    }

    public void setCourseID(int courseID) {
        this.courseID = courseID;
    }

    public String getCourseUnits() {
        return courseUnits;
    }

    public void setCourseUnits(String courseUnits) {
        this.courseUnits = courseUnits;
    }

    public String getCourseNumber() {
        return courseNumber;
    }

    public void setCourseNumber(String courseNumber) {
        this.courseNumber = courseNumber;
    }

    public String getCourseTitle() {
        return courseTitle;
    }

    public void setCourseTitle(String courseTitle) {
        this.courseTitle = courseTitle;
    }

    public String getCourseDepartment() {
        return courseDepartment;
    }

    public void setCourseDepartment(String courseDepartment) {
        this.courseDepartment = courseDepartment;
    }

    public String getCourseInstructor() {
        return courseInstructor;
    }

    public void setCourseInstructor(String courseInstructor) {
        this.courseInstructor = courseInstructor;
    }

    public String getCourseDays() {
        return courseDays;
    }

    public void setCourseDays(String courseDays) {
        this.courseDays = courseDays;
    }

    public String getCourseStartTime() {
        return courseStartTime;
    }

    public void setCourseStartTime(String courseStartTime) {
        this.courseStartTime = courseStartTime;
    }

    public String getCourseEndTime() {
        return courseEndTime;
    }

    public void setCourseEndTime(String courseEndTime) {
        this.courseEndTime = courseEndTime;
    }

    public String getCourseMeetingType() {
        return courseMeetingType;
    }

    public void setCourseMeetingType(String courseMeetingType) {
        this.courseMeetingType = courseMeetingType;
    }

    public String getCourseSectionNumber() {
        return courseSectionNumber;
    }

    public void setCourseSectionNumber(String courseSectionNumber) {
        this.courseSectionNumber = courseSectionNumber;
    }

    public String getCourseBuilding() {
        return courseBuilding;
    }

    public void setCourseBuilding(String courseBuilding) {
        this.courseBuilding = courseBuilding;
    }

    public String getCourseRoom() {
        return courseRoom;
    }

    public void setCourseRoom(String courseRoom) {
        this.courseRoom = courseRoom;
    }

    public String getCoursePrerequisite() {
        return coursePrerequisite;
    }

    public void setCoursePrerequisite(String coursePrerequisite) {
        this.coursePrerequisite = coursePrerequisite;
    }

    public String getCourseDescription() {
        return courseDescription;
    }

    public void setCourseDescription(String courseDescription) {
        this.courseDescription = courseDescription;
    }

    public int getCourseSeats() {
        return courseSeats;
    }

    public void setCourseSeats(int courseSeats) {
        this.courseSeats = courseSeats;
    }

    public int getCourseEnrolled() {
        return courseEnrolled;
    }

    public void setCourseEnrolled(int courseEnrolled) {
        this.courseEnrolled = courseEnrolled;
    }

    public int getCourseWaitlist() {
        return courseWaitlist;
    }

    public void setCourseWaitlist(int courseWaitlist) {
        this.courseWaitlist = courseWaitlist;
    }

    public String getEnrollmentStatus() {
        return enrollmentStatus;
    }

}
