package thuc_nguyen.cs64601assignment1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.Locale;

public class ConvertActivity extends AppCompatActivity implements View.OnClickListener, View.OnFocusChangeListener {

    // WIDGETS AND PROPERTIES
    private EditText usdEditText, inrEditText;
    private Button convertButton;

    private FocusedEditText currentFocusedEditText = FocusedEditText.NONE;

    private enum FocusedEditText {
        USD,
        INR,
        NONE
    }

    // DEBUG
    public static String LOG_CONVERT = "LOG_CONVERT";

    // TEMPORARY DATA
    public static final String USD_KEY = "USD Edit Text Key";
    public static final String INR_KEY = "INR Edit Text Key";

    // FUNCTIONS
    /**
     * Initializes all the widgets that the activity uses. Finds the view by ID in red
     * */
    private void initializeWidgets() {
        Log.d(LOG_CONVERT, "initializeWidgets()");

        usdEditText = this.findViewById(R.id.usdAmount);
        inrEditText = this.findViewById(R.id.inrAmount);
        convertButton = this.findViewById(R.id.convertButton);

        usdEditText.setOnFocusChangeListener(this);
        inrEditText.setOnFocusChangeListener(this);
        convertButton.setOnClickListener(this);
    }

    /**
     * Converts either USD to INR or INR to USD and populates the edit text input fields
     * with the converted value.
     * */
    private void convertInputValue() {
        Log.d(LOG_CONVERT, "convertInputValue()");

        // Depending on value of currentFocusedEditText, calculate the new value in USD or INR
        // and set the text in the corresponding edit text fields.
        // 1 INR = 0.016 USD and 1 USD = 63.89 INR
        float inrRate = 0.016f;
        float usdRate = 63.89f;

        switch (currentFocusedEditText) {
            case INR:
                float inrInputValue = Float.parseFloat(inrEditText.getText().toString());
                usdEditText.setText(String.format(Locale.US, "%.2f", (inrInputValue * inrRate)));
                inrEditText.setText(String.format(Locale.US, "%.2f", Float.parseFloat(inrEditText.getText().toString())));
                break;
            case USD:
                float usdInputValue = Float.parseFloat(usdEditText.getText().toString());
                inrEditText.setText(String.format(Locale.US, "%.2f", (usdInputValue * usdRate)));
                usdEditText.setText(String.format(Locale.US, "%.2f", Float.parseFloat(usdEditText.getText().toString())));
                break;
            case NONE:
                break;
            default:
                break;
        }
    }

    // ACTIVITY LIFECYCLE
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_convert);

        initializeWidgets();
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        // Retrieve the values of the edit text fields
        usdEditText.setText(savedInstanceState.getString(USD_KEY));
        inrEditText.setText(savedInstanceState.getString(INR_KEY));
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        // Save the values of the edit text fields
        outState.putString(USD_KEY, usdEditText.getText().toString());
        outState.putString(INR_KEY, inrEditText.getText().toString());
    }


    /**
     * Implementation of View.OnClickListener and View.OnFocusChangeListener
     * When the user changes focus on an edit text field, the currentFocusedEditText
     * property is updated. Whatever text is in the edit text that isn't focused is cleared.
     * */
    @Override
    public void onClick(View view) {
        Log.d(LOG_CONVERT, "onClick()");

        // If the convert button is clicked, call convertInputValue()
        switch (view.getId()) {
            case R.id.convertButton:
                Log.d(LOG_CONVERT, "convert button clicked");
                convertInputValue();
                break;
            default:
                break;
        }
    }

    @Override
    public void onFocusChange(View view, boolean b) {
        Log.d(LOG_CONVERT, "onFocusChange()");

        // Update currentFocusedEditText depending on which edit text the user clicked on.
        // Clear the edit text that isn't focused.
        switch (view.getId()) {
            case R.id.usdAmount:
                Log.d(LOG_CONVERT, "USD Edit Text focused");

                currentFocusedEditText = FocusedEditText.USD;
                inrEditText.setText("");
                break;
            case R.id.inrAmount:
                Log.d(LOG_CONVERT, "INR Edit Text focused");

                currentFocusedEditText = FocusedEditText.INR;
                usdEditText.setText("");
                break;
            default:
                Log.d(LOG_CONVERT, "Other Edit Text focused");

                currentFocusedEditText = FocusedEditText.NONE;
                break;
        }
    }
}
