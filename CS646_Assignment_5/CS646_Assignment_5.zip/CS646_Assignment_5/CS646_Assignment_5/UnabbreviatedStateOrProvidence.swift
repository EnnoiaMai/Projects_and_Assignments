//
//  UnabbreviatedStateOrProvidence.swift
//  CS646_Assignment_5
//
//  Created by Thuc Nguyen on 11/13/17.
//  Copyright © 2017 cs646. All rights reserved.
//

import Foundation

class UnabbreviatedStateOrProvidence {
    
//    static let canadaDictionary: [String: String] = [
//        "": "Ontario",
//        "": "Quebec",
//        "": "Nova Scotia",
//        "": "New Brunswick",
//        "": "Manitoba",
//        "": "British Columbia",
//        "": "Prince Edward Island",
//        "": "Saskatchewan",
//        "": "Alberta",
//        "": "Newfoundland and Labrador",
//        "": "St. John's"]
//    static let chinaDictionary: [String: String] = [
//        "": "Beijing Municipality",
//        "": "Tianjin Municipality",
//        "": "Hebei",
//        "": "Shanxi",
//        "": "Inner Mongolia",
//        "": "Liaoning",
//        "": "Jilin",
//        "": "Heilongjiang",
//        "": "Shanghai Municipality",
//        "": "Jiangsu",
//        "": "Zhejiang",
//        "": "Anhui",
//        "": "Fujian",
//        "": "Jiangxi",
//        "": "Shandong",
//        "": "Henan",
//        "": "Hubei",
//        "": "Hunan",
//        "": "Guangdong",
//        "": "Guangxi Zhuang",
//        "": "Hainan",
//        "": "Chongqing Municipality",
//        "": "Sichuan",
//        "": "Guizhou",
//        "": "Yunnan",
//        "": "Tibet Autonomous Region",
//        "": "Shaanxi",
//        "": "Gansu",
//        "": "Qinghai",
//        "": "Ningxia Hui",
//        "": "Xinjiang Uyghur",
//        "": "Hong Kong",
//        "": "Macau",
//        "": "Taiwan",]
//    static let franceDictionary: [String: String] = [
//        "": "Grand-Est",
//        "": "New Aquitaine",
//        "": "Auvergne-Rhone-Alpes",
//        "": "Burgundy-Franche-Comte",
//        "": "Brittany",
//        "": "Centre-Val de Loir",
//        "": "Ile-de-France",
//        "": "Occitania",
//        "": "Hauts-de-France",
//        "": "Normandy",
//        "": "Pays de la Loire",
//        "": "Provence-Alpes-Cote d'Azur",
//        "": "Corsica"]
//    static let germanyDictionary: [String: String] = [
//        "": "Baden-Wurttemberg",
//        "": "Bavaria",
//        "": "Berlin",
//        "": "Brandenburg",
//        "": "Bremen",
//        "": "Hamburg",
//        "": "Hesse",
//        "": "Lower Saxony",
//        "": "Mecklenburg-Vorpommern",
//        "": "North Rhine-Westphalia",
//        "": "Rhineland-Palatinate",
//        "": "Saarland",
//        "": "Saxony",
//        "": "Saxony-Anhalt",
//        "": "Schleswig-Holstein",
//        "": "Thuringia"]
//    static let indiaDictionary: [String: String] = [
//        "": "Andhra Pradesh",
//        "": "Arunachal Pradesh",
//        "": "Assam",
//        "": "Bihar",
//        "": "Chhattisgarh",
//        "": "Goa",
//        "": "Gujarat",
//        "": "Haryana",
//        "": "Himachal Pradesh",
//        "": "Jammu and Kashmir",
//        "": "Jharkhand",
//        "": "Karnataka",
//        "": "Kerala",
//        "": "Madhya Pradesh",
//        "": "Maharashtra",
//        "": "Manipur",
//        "": "Meghalaya",
//        "": "Mizoram",
//        "": "Nagaland",
//        "": "Odisha",
//        "": "Punjab",
//        "": "Rajasthan",
//        "": "Sikkim",
//        "": "Tamil Nadu",
//        "": "Telangana",
//        "": "Tripura",
//        "": "Uttar Pradesh",
//        "": "Uttarakhand",
//        "": "West Bengal"]
//    static let japanDictionary: [String: String] = [
//        "": "Aichi",
//        "": "Akita",
//        "": "Aomori",
//        "": "Chiba",
//        "": "Ehime",
//        "": "Fukui",
//        "": "Fukuoka",
//        "": "Fukushima",
//        "": "Gifu",
//        "": "Gunma",
//        "": "Hiroshima",
//        "": "Hokkaido",
//        "": "Hy\u{014D}go",
//        "": "Ibaraki",
//        "": "Ishikawa",
//        "": "Iwate",
//        "": "Kagawa",
//        "": "Kagoshima",
//        "": "Kanagawa",
//        "": "K\u{014D}chi",
//        "": "Kumamoto",
//        "": "Kyoto",
//        "": "Mie",
//        "": "Miyagi",
//        "": "Miyazaki",
//        "": "Nagano",
//        "": "Nagasaki",
//        "": "Nara",
//        "": "Niigata",
//        "": "\u{014C}ita",
//        "": "Okayama",
//        "": "Okinawa",
//        "": "Osaka",
//        "": "Saga",
//        "": "Saitama",
//        "": "Shiga",
//        "": "Shimane",
//        "": "Shizuoka",
//        "": "Tochigi",
//        "": "Tokushima",
//        "": "Tokyo",
//        "": "Tottori",
//        "": "Toyama",
//        "": "Wakayama",
//        "": "Yamagata",
//        "": "Yamaguchi",
//        "": "Yamanashi"]
    static let mexicoDictionary: [String: String] = [
        "AGU": "Aguascalientes",
        "BCN": "Baja California",
        "BCS": "Baja California Sur",
        "CAM": "Campeche",
        "CHP": "Chiapas",
        "CHH": "Chihuahua",
        "COA": "Coahuil",
        "COL": "Colim",
        "DUR": "Durango",
        "GUA": "Guanajuato",
        "GRO": "Guerrero",
        "HID": "Hidalgo",
        "JAL": "Jalisco",
        "MEX": "Me\u{301}xico",
        "MIC": "Michoacan",
        "MOR": "Morelos",
        "NAY": "Nayarit",
        "NLE": "Nuevo Leo",
        "OAX": "Oaxaca",
        "PUE": "Puebla",
        "QUE": "Queretaro",
        "ROO": "Quintana Roo",
        "SLP": "San Luis Potos\u{00ED}",
        "SIN": "Sinaloa",
        "SON": "Sonor",
        "TAB": "Tabasc",
        "TAM": "Tamaulipa",
        "TLA": "Tlaxcala",
        "VER": "Veracruz",
        "YUC": "Yucata",
        "ZAC": "Zacatecas"]
    static let usaDictionary: [String: String] = [
        "AL": "Alabama",
        "AK": "Alaska",
        "AZ": "Arizona",
        "AR": "Arkansas",
        "CA": "California",
        "CO": "Colorado",
        "CT": "Connecticut",
        "DE": "Delaware",
        "FL": "Florida",
        "GA": "Georgia",
        "HI": "Hawaii",
        "ID": "Idaho",
        "IL": "Illinois",
        "IN": "Indiana",
        "IA": "Iowa",
        "KS": "Kansas",
        "KY": "Kentucky",
        "LA": "Louisiana",
        "ME": "Maine",
        "MD": "Maryland",
        "MA": "Massachusetts",
        "MI": "Michigan",
        "MN": "Minnesota",
        "MS": "Mississippi",
        "MO": "Missouri",
        "MT": "Montana",
        "NE": "Nebraska",
        "NV": "Nevada",
        "NH": "New Hampshire",
        "NJ": "New Jersey",
        "NM": "New Mexico",
        "NY": "New York",
        "NC": "North Carolina",
        "ND": "North Dakota",
        "OH": "Ohio",
        "OK": "Oklahoma",
        "OR": "Oregon",
        "PA": "Pennsylvania",
        "RI": "Rhode Island",
        "SC": "South Carolina",
        "SD": "South Dakota",
        "TN": "Tennessee",
        "TX": "Texas",
        "UT": "Utah",
        "VT": "Vermont",
        "VA": "Virginia",
        "WA": "Washington",
        "WV": "West Virginia",
        "WI": "Wisconsin",
        "WY": "Wyoming"]
    
    static func returnUnabbreviated(country: String, administrativeArea: String?) -> String? {
        guard let administrativeArea = administrativeArea else {
            return nil
        }
        
        switch country {
        case "Canada":
            return administrativeArea
//            return canadaDictionary[administrativeArea]
        case "China":
            return administrativeArea
//            return chinaDictionary[administrativeArea]
        case "France":
            return administrativeArea
//            return franceDictionary[administrativeArea]
        case "Germany":
            return administrativeArea
//            return germanyDictionary[administrativeArea]
        case "India":
            return administrativeArea
//            return indiaDictionary[administrativeArea]
        case "Japan":
            return administrativeArea
//            return japanDictionary[administrativeArea]
        case "Mexico":
            return mexicoDictionary[administrativeArea]
        case "United States":
            return usaDictionary[administrativeArea]
        default:
            return nil
        }
    }
    
    init() {
    }
}
