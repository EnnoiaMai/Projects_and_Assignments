//
//  UserTableViewCell.swift
//  CS646_Assignment_5
//
//  Created by Thuc Nguyen on 11/10/17.
//  Copyright © 2017 cs646. All rights reserved.
//

import UIKit

class UserTableViewCell: UITableViewCell {
    
    // MARK: OULETS AND ACTIONS
    
    @IBOutlet weak var nicknameLabel: UILabel!
    @IBOutlet weak var cityAndStateLabel: UILabel!
    @IBOutlet weak var countryLabel: UILabel!
    @IBOutlet weak var yearLabel: UILabel!
    
    // MARK: LIFECYCLE
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
