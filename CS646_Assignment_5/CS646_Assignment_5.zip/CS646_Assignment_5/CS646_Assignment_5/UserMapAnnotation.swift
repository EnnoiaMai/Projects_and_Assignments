//
//  UserMapAnnotation.swift
//  CS646_Assignment_5
//
//  Created by Thuc Nguyen on 11/12/17.
//  Copyright © 2017 cs646. All rights reserved.
//

import Foundation
import MapKit

class UserMapAnnotation: NSObject, MKAnnotation {
    
    // PROPERTIES //
    var title: String?
    var coordinate: CLLocationCoordinate2D

    
    init(nickname: String, coordinate: CLLocationCoordinate2D) {
        self.title = nickname
        self.coordinate = coordinate
    }
}
