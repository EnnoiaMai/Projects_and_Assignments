//
//  ListUsersViewController.swift
//  CS646_Assignment_5
//
//  Created by Thuc Nguyen on 11/9/17.
//  Copyright © 2017 cs646. All rights reserved.
//

import UIKit

class ListUsersViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    // MARK: PROPERTIES
    var currentFilterParameter: FilterParameter = .ALL
    var countryFilter: String = ""
    var yearFilter: String = ""
    
//    var usersData: [UserModel]?
    var usersData: [[String : Any]] = []
    var retrievingData: Bool = false {
        didSet {
            if (retrievingData) {
                listTableView.isHidden = true
                activityIndicator.startAnimating()
            } else {
                listTableView.isHidden = false
                activityIndicator.stopAnimating()
            }
        }
    }
    
    // MARK: OUTLETS AND ACTIONS
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var listTableView: UITableView!
    
    @IBAction func filterButton(_ sender: UIButton) {
        
    }
    @IBAction func addUserButton(_ sender: UIButton) {
    }
    
    @IBAction func refreshList(_ sender: UIButton) {
        retrieveDataFromServer()
    }
    
    
    // MARK: DATASOURCE METHODS
    // Number of sections in the table view
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    // Number of rows in each section
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return usersData.count
    }
    
    // Configuration of each cell
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "userCell") as! UserTableViewCell
        
        guard !(usersData.isEmpty) else {
            cell.nicknameLabel.text = ""
            cell.cityAndStateLabel.text = ""
            cell.countryLabel.text = ""
            cell.yearLabel.text = ""
            return cell
        }
        let userNickname = (usersData[indexPath.row]["nickname"] as? String) ?? ""
        let userCity = (usersData[indexPath.row]["city"] as? String) ?? ""
        let userState = (usersData[indexPath.row]["state"] as? String) ?? ""
        let userCountry = (usersData[indexPath.row]["country"] as? String) ?? ""
        let userYear = (usersData[indexPath.row]["year"] as? Int) ?? 0
        
        cell.nicknameLabel.text = userNickname
        cell.cityAndStateLabel.text = "\(userCity), \(userState)"
        cell.countryLabel.text = userCountry
        cell.yearLabel.text = String(userYear)
        
        return cell
    }
    
    // MARK: DELEGATE METHODS
    // When user selected the row
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
    
    // MARK: NETWORKING METHODS
    func retrieveDataFromServer() {
        retrievingData = true
        
        // Create the url depending on the current filter
        var urlString = ""
        switch currentFilterParameter {
        case .ALL:
            urlString = "https://bismarck.sdsu.edu/hometown/users"
        case .COUNTRY:
            urlString = "https://bismarck.sdsu.edu/hometown/users?country=\(countryFilter)"
        case .YEAR:
            urlString = "https://bismarck.sdsu.edu/hometown/users?year=\(yearFilter)"
        case .COUNTRY_AND_YEAR:
            urlString = "https://bismarck.sdsu.edu/hometown/users?country=\(countryFilter)&year=\(yearFilter)"
        }
        
        let operation = BlockOperation.init(block: {self.getUsersFromServer(urlString: urlString)})
        let queue = OperationQueue.init()
        queue.addOperation(operation)
    }
    func getUsersFromServer(urlString: String) {
        if let url = URL.init(string: urlString) {
            var urlUsersRequest = URLRequest.init(url: url)
            urlUsersRequest.httpMethod = "GET"
            urlUsersRequest.setValue("text/plain", forHTTPHeaderField: "Content-Type")
            let session = URLSession.shared
            let task = session.dataTask(with: urlUsersRequest, completionHandler: getUsersFromServerHandler)
            task.resume()
        }
        else {
            print("Unable to create Users URL")
            let mainQueue = OperationQueue.main
            mainQueue.addOperation {
                self.retrievingData = false
            }
        }
    }
    func getUsersFromServerHandler(data: Data?, response: URLResponse?, error: Error?) -> Void {
        guard (error == nil) else {
            print("getUsersFromServerHandler(): error: \(error!.localizedDescription)")
            let mainQueue = OperationQueue.main
            mainQueue.addOperation {
                self.retrievingData = false
            }
            return
        }
        
        let httpResponse = response as? HTTPURLResponse
        let status: Int = httpResponse!.statusCode
        
        guard (data != nil) && (status == 200) else {
            print("getUsersFromServerHandler(): data is nil or status is not 200")
            let mainQueue = OperationQueue.main
            mainQueue.addOperation {
                self.retrievingData = false
            }
            return
        }
        do {
            let json: Any = try JSONSerialization.jsonObject(with: data!)
            let jsonNSArray = json as! NSArray
            
            let mainQueue = OperationQueue.main
            mainQueue.addOperation({
                self.usersData = jsonNSArray as! Array<Dictionary<String, Any>>
                self.listTableView.reloadData()
                self.retrievingData = false
            })
        }
        catch {
            print("getUsersFromServerHandler(): Error when deserializing json object")
            let mainQueue = OperationQueue.main
            mainQueue.addOperation {
                self.retrievingData = false
            }
        }
    }
    
    // MARK: LIFECYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        print("ListUsersVC: viewDidLoad()")
        
        listTableView.dataSource = self
        listTableView.delegate = self
        
        listTableView.rowHeight = 120
        listTableView.separatorColor = UIColor.black
        
        // Load data from server
        retrieveDataFromServer()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    

    // MARK: NAVIGATION
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "listToFilterSegue") {
            if let destination = segue.destination as? UINavigationController {
                if let destinationRoot = destination.topViewController as? FilterParametersViewController {
                    destinationRoot.currentSource = .LIST_USERS
                    destinationRoot.currentFilterParameter = self.currentFilterParameter
                }
            }
        }
        else if (segue.identifier == "listToUserSegue") {
            if let destination = segue.destination as? UINavigationController {
                if let destinationRoot = destination.topViewController as? AddUserViewController {
                    destinationRoot.currentSource = .LIST_USERS
                }
            }
        }
    }
    @IBAction func unwindToListUsers(unwindSegue: UIStoryboardSegue) {
        if let source = unwindSegue.source as? FilterParametersViewController {
            self.currentFilterParameter = source.currentFilterParameter
            switch source.currentFilterParameter {
            case .COUNTRY_AND_YEAR:
                self.countryFilter = source.selectedCountry
                self.yearFilter = source.selectedYear
            case .COUNTRY:
                self.countryFilter = source.selectedCountry
                self.yearFilter = ""
            case .YEAR:
                self.countryFilter = ""
                self.yearFilter = source.selectedYear
            case .ALL:
                self.countryFilter = ""
                self.yearFilter = ""
            }
            // Then retrieve data from server again
            self.retrieveDataFromServer()
        }
        else if let source = unwindSegue.source as? AddUserViewController {
            if (source.posted) {
                retrieveDataFromServer()
            }
        }
        print(currentFilterParameter)
    }

}
