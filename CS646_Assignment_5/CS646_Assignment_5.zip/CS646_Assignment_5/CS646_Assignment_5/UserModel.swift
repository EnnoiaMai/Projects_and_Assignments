//
//  UserModel.swift
//  CS646_Assignment_5
//
//  Created by Thuc Nguyen on 11/10/17.
//  Copyright © 2017 cs646. All rights reserved.
//

import Foundation

class UserModel {
    
    // PROPERTIES
    var nickname: String
    var password: String
    var country: String
    var state: String
    var city: String
    var year: Int
    var latitude: Double?, longitude: Double?
    
    // METHODS
    
    // INIT
    init(nickname: String, password: String, country: String, state: String, city: String, year: Int) {
        
        // Initialize properties
        self.nickname = nickname
        self.password = password
        self.country = country
        self.state = state
        self.city = city
        self.year = year
    }
}
