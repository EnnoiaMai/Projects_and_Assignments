//
//  DataPickerViewController.swift
//  CS646_Assignment_5
//
//  Created by Thuc Nguyen on 11/10/17.
//  Copyright © 2017 cs646. All rights reserved.
//

import UIKit

class DataPickerViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    
    // MARK: PROPERTIES
    enum SegueSource {
        case COUNTRY, STATE, YEAR, NONE
    }
    var currentSource: SegueSource = .NONE {
        didSet {
            print("didSet currentSource in DataPickerVC")
            switch currentSource {
            case .COUNTRY:
                dataPickerNavigationItem.title = "Select a Country"
            case .STATE:
                dataPickerNavigationItem.title = "Select a State"
            case .YEAR:
                dataPickerNavigationItem.title = "Select a Year"
            default:
                dataPickerNavigationItem.title = ""
            }
        }
    }
    
    // The data to refer to and populate the picker
    var dataList: [String] = []
    let yearDataList: [Int] = Array(1970...2017).reversed()
    
    // The data to return to AddUserVC
    var returnData: String = ""
    
    // Sets activity indicator on or off when retrieving data from server
    var retrievingData: Bool = false {
        didSet {
            if (retrievingData) {
                dataPicker.isHidden = true
                activityIndicator.startAnimating()
            } else {
                dataPicker.isHidden = false
                activityIndicator.stopAnimating()
            }
        }
    }
    
    // Country to use for State query (dependent on countryTextField in AddUserVC)
    var currentCountry: String?
    
    // MARK: OUTLETS AND ACTIONS
    @IBOutlet weak var dataPickerNavigationItem: UINavigationItem!
    @IBAction func doneBarButtonItem(_ sender: UIBarButtonItem) {
        returnData = dataList[dataPicker.selectedRow(inComponent: 0)]
        self.performSegue(withIdentifier: "unwindToAdd", sender: self)
    }
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var dataPicker: UIPickerView!
    
    // MARK: DATASOURCE AND DELEGATE METHODS
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return dataList.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        guard (component == 0) else {
            return ""
        }
        return dataList[row]
    }
    
    // MARK: NETWORKING METHODS
    func retrieveDataFromServer() {
        if (currentSource == .COUNTRY) {
            retrievingData = true
            let operation = BlockOperation.init(block: {self.getCountries()})
            let queue = OperationQueue.init()
            queue.addOperation(operation)
        }
        else if (currentSource == .STATE) {
            retrievingData = true
            let operation = BlockOperation.init(block: {self.getStates()})
            let queue = OperationQueue.init()
            queue.addOperation(operation)
        }
    }
    
    func getCountries() {
        if let url = URL.init(string: "https://bismarck.sdsu.edu/hometown/countries") {
            var urlCountriesRequest = URLRequest.init(url: url)
            urlCountriesRequest.httpMethod = "GET"
            urlCountriesRequest.setValue("text/plain", forHTTPHeaderField: "Content-Type")
            let session = URLSession.shared
            let task = session.dataTask(with: urlCountriesRequest, completionHandler: getCountriesHandler)
            task.resume()
        }
        else {
            print("Unable to create Country URL")
            let mainQueue = OperationQueue.main
            mainQueue.addOperation {
                self.retrievingData = false
            }
        }
    }
    func getCountriesHandler(data: Data?, response: URLResponse?, error: Error?) -> Void {
        guard (error == nil) else {
            print("getCountriesHandler(): error: \(error!.localizedDescription)")
            let mainQueue = OperationQueue.main
            mainQueue.addOperation {
                self.retrievingData = false
            }
            return
        }
        
        let httpResponse = response as? HTTPURLResponse
        let status: Int = httpResponse!.statusCode
        
        guard (data != nil) && (status == 200) else {
            print("getCountriesHandler(): data is nil or status is not 200")
            let mainQueue = OperationQueue.main
            mainQueue.addOperation {
                self.retrievingData = false
            }
            return
        }
        do {
            let json: Any = try JSONSerialization.jsonObject(with: data!)
            let jsonNSArray = json as! NSArray
            
            let mainQueue = OperationQueue.main
            mainQueue.addOperation({
                self.dataList = jsonNSArray as! Array
                self.dataPicker.reloadComponent(0)
                self.retrievingData = false
            })
        }
        catch {
            print("getCountriesHandler(): Error when deserializing json object")
            let mainQueue = OperationQueue.main
            mainQueue.addOperation {
                self.retrievingData = false
            }
        }
    }
    
    func getStates() {
        if let url = URL.init(string: "https://bismarck.sdsu.edu/hometown/states?country=\(currentCountry!)") {
            var urlStatesRequest = URLRequest.init(url: url)
            urlStatesRequest.httpMethod = "GET"
            urlStatesRequest.setValue("text/plain", forHTTPHeaderField: "Content-Type")
            let session = URLSession.shared
            let task = session.dataTask(with: urlStatesRequest, completionHandler: getStatesHandler)
            task.resume()
        }
        else {
            print("Unable to create State URL")
            let mainQueue = OperationQueue.main
            mainQueue.addOperation {
                self.retrievingData = false
            }
        }
    }
    
    func getStatesHandler(data: Data?, response: URLResponse?, error: Error?) -> Void {
        guard (error == nil) else {
            print("getStatesHandler(): error: \(error!.localizedDescription)")
            let mainQueue = OperationQueue.main
            mainQueue.addOperation {
                self.retrievingData = false
            }
            return
        }
        
        let httpResponse = response as? HTTPURLResponse
        let status: Int = httpResponse!.statusCode
        
        guard (data != nil) && (status == 200) else {
            print("getStatesHandler(): data is nil or status is not 200")
            let mainQueue = OperationQueue.main
            mainQueue.addOperation {
                self.retrievingData = false
            }
            return
        }
        do {
            let json: Any = try JSONSerialization.jsonObject(with: data!)
            let jsonNSArray = json as! NSArray
            
            let mainQueue = OperationQueue.main
            mainQueue.addOperation({
                self.dataList = jsonNSArray as! Array
                self.dataPicker.reloadComponent(0)
                self.retrievingData = false
            })
        }
        catch {
            print("getStatesHandler(): Error when deserializing json object")
            let mainQueue = OperationQueue.main
            mainQueue.addOperation {
                self.retrievingData = false
            }
        }
    }
    
    // MARK: LIFECYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        print("DataPickerViewController: viewDidLoad()")
        dataPicker.dataSource = self
        dataPicker.delegate = self
        
        switch currentSource {
        case .COUNTRY:
            print("currentSource is Country, use GET to get list of countries")
            retrieveDataFromServer()
        case .STATE:
            print("currentSource is State, use GET to get list of states")
            guard (currentCountry != nil) else {
                return
            }
            retrieveDataFromServer()
        case .YEAR:
            print("currentSource is Year")
            dataList = yearDataList.map({String($0)})
        default:
            dataList = []
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
