//
//  MapViewController.swift
//  CS646_Assignment_5
//
//  Created by Thuc Nguyen on 11/9/17.
//  Copyright © 2017 cs646. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit

class MapViewController: UIViewController, MKMapViewDelegate {
    
    // MARK: PROPERTIES
    var currentFilterParameter: FilterParameter = .ALL
    var countryFilter: String = ""
    var yearFilter: String = ""
    
    var usersData: [[String : Any]] = []
    var retrievingData: Bool = false {
        didSet {
            if (retrievingData) {
                activityIndicator.startAnimating()
            } else {
                activityIndicator.stopAnimating()
            }
        }
    }
    
    // MARK: OUTLETS AND ACTIONS
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var mapView: MKMapView!
    
    @IBAction func filterButton(_ sender: UIButton) {
    }
    @IBAction func addUserButton(_ sender: UIButton) {
    }
    
    @IBAction func refreshMap(_ sender: UIButton) {
        reloadAnnotations()
    }
    
    // MARK: MAPKIT METHODS
    // Setup for MKAnnotationView
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        guard let annotation = annotation as? UserMapAnnotation else {
            return nil
        }
        
        let reuseId = "annotations"
        var view: MKPinAnnotationView
        
        if let dequeuedView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView {
            dequeuedView.annotation = annotation
            view = dequeuedView
        }
        else {
            view = MKPinAnnotationView.init(annotation: annotation, reuseIdentifier: reuseId)
//            view = MKMarkerAnnotationView.init(annotation: annotation, reuseIdentifier: reuseId)
            view.canShowCallout = true
        }
        return view
    }
    
    func mapViewWillStartLoadingMap(_ mapView: MKMapView) {
        print("MapViewController: mapViewWillStartLoadingMap()")
        retrievingData = true
    }
    
    func mapViewDidFinishLoadingMap(_ mapView: MKMapView) {
        print("MapViewController: mapViewWillFinishLoadingMap()")
        retrievingData = false
        mapView.showAnnotations(mapView.annotations, animated: true)
    }
    
    func reloadAnnotations() {
        retrievingData = true
        mapView.removeAnnotations(mapView.annotations)
        
        // Create master operation after all annotations have been geocoded asynchronously
        let masterOperation = BlockOperation.init(block: {print("Master Operation is done")})
        masterOperation.completionBlock = {
            let mainQueue = OperationQueue.main
            mainQueue.addOperation({
                self.mapView.showAnnotations(self.mapView.annotations, animated: true)
            })
        }
        let queue = OperationQueue.init()

        for user in usersData {
            let nickname: String = (user["nickname"] as? String) ?? ""
            let city: String = (user["city"] as? String) ?? ""
            let state: String = (user["state"] as? String) ?? ""
            let country: String = (user["country"] as? String) ?? ""
            let latitude: Double = (user["latitude"] as? Double) ?? 0
            let longitude: Double = (user["longitude"] as? Double) ?? 0
            
            let addressString = "\(city), \(state) \(country)"
            
            // If latitude and longitude are no provided, geocode the addresses
            if (latitude == 0) && (longitude == 0) {
                let locator = CLGeocoder()
                
                let childOperation = BlockOperation.init(block: {
                    locator.geocodeAddressString(addressString, completionHandler: { (placemarks, errors) in
                        if let place = placemarks?[0] {
                            if let coordinate = place.location?.coordinate {
                                let annotation = UserMapAnnotation.init(nickname: nickname, coordinate: coordinate)
                                self.mapView.addAnnotation(annotation)
                            }
                            else {
                                print("reloadAnnotations: unable to get coordinate from placemark")
                            }
                        }
                        else {
                            print("reloadAnnotations: geocoding error: \(errors!)")
                        }
                    })
                })
                masterOperation.addDependency(childOperation)
                queue.addOperation(childOperation)
            }
            else {
                // Else, give latitude and longitude data to annotation
                let coordinate = CLLocationCoordinate2DMake(CLLocationDegrees.init(latitude), CLLocationDegrees.init(longitude))
                let annotation = UserMapAnnotation.init(nickname: nickname, coordinate: coordinate)
                mapView.addAnnotation(annotation)
            }
        }
        
        queue.addOperation(masterOperation)
    }
    
    // MARK: NETWORKING METHODS
    func retrieveDataFromServer() {
        retrievingData = true
        
        // Create the url depending on the current filter
        var urlString = ""
        switch currentFilterParameter {
        case .ALL:
            urlString = "https://bismarck.sdsu.edu/hometown/users"
        case .COUNTRY:
            urlString = "https://bismarck.sdsu.edu/hometown/users?country=\(countryFilter)"
        case .YEAR:
            urlString = "https://bismarck.sdsu.edu/hometown/users?year=\(yearFilter)"
        case .COUNTRY_AND_YEAR:
            urlString = "https://bismarck.sdsu.edu/hometown/users?country=\(countryFilter)&year=\(yearFilter)"
        }
        
        let operation = BlockOperation.init(block: {self.getUsersFromServer(urlString: urlString)})
        let queue = OperationQueue.init()
        queue.addOperation(operation)
    }
    func getUsersFromServer(urlString: String) {
        if let url = URL.init(string: urlString) {
            var urlUsersRequest = URLRequest.init(url: url)
            urlUsersRequest.httpMethod = "GET"
            urlUsersRequest.setValue("text/plain", forHTTPHeaderField: "Content-Type")
            let session = URLSession.shared
            let task = session.dataTask(with: urlUsersRequest, completionHandler: getUsersFromServerHandler)
            task.resume()
        }
        else {
            print("MapViewVC: Unable to create Users URL")
        }
    }
    func getUsersFromServerHandler(data: Data?, response: URLResponse?, error: Error?) -> Void {
        guard (error == nil) else {
            print("MapViewVC: getUsersFromServerHandler(): error: \(error!.localizedDescription)")
            return
        }
        
        let httpResponse = response as? HTTPURLResponse
        let status: Int = httpResponse!.statusCode
        
        guard (data != nil) && (status == 200) else {
            print("MapViewVC: getUsersFromServerHandler(): data is nil or status is not 200")
            return
        }
        do {
            let json: Any = try JSONSerialization.jsonObject(with: data!)
            let jsonNSArray = json as! NSArray
            
            let mainQueue = OperationQueue.main
            mainQueue.addOperation({
                self.usersData = jsonNSArray as! Array<Dictionary<String, Any>>
                self.reloadAnnotations()
                self.retrievingData = false
            })
        }
        catch {
            print("MapViewVC: getUsersFromServerHandler(): Error when deserializing json object")
        }
    }
    
    // MARK: LIFECYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        mapView.delegate = self
        
        retrieveDataFromServer()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    

    // MARK: NAVIGATION
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "mapToFilterSegue") {
            if let destination = segue.destination as? UINavigationController {
                if let destinationRoot = destination.topViewController as? FilterParametersViewController {
                    destinationRoot.currentSource = .MAP
                    destinationRoot.currentFilterParameter = self.currentFilterParameter
                }
            }
        }
        else if (segue.identifier == "mapToUserSegue") {
            if let destination = segue.destination as? UINavigationController {
                if let destinationRoot = destination.topViewController as? AddUserViewController {
                    destinationRoot.currentSource = .MAP
                }
            }
        }
    }
    @IBAction func unwindToMap(unwindSegue: UIStoryboardSegue) {
        if let source = unwindSegue.source as? FilterParametersViewController {
            self.currentFilterParameter = source.currentFilterParameter
            switch source.currentFilterParameter {
            case .COUNTRY_AND_YEAR:
                self.countryFilter = source.selectedCountry
                self.yearFilter = source.selectedYear
            case .COUNTRY:
                self.countryFilter = source.selectedCountry
                self.yearFilter = ""
            case .YEAR:
                self.countryFilter = ""
                self.yearFilter = source.selectedYear
            case .ALL:
                self.countryFilter = ""
                self.yearFilter = ""
            }
            // Then retrieve data from server again
            self.retrieveDataFromServer()
        }
        else if let source = unwindSegue.source as? AddUserViewController {
            if (source.posted) {
                reloadAnnotations()
            }
        }
        print(currentFilterParameter)
    }

}
