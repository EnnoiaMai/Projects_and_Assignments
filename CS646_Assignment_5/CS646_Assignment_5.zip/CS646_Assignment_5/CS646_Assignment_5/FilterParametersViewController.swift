//
//  FilterParametersViewController.swift
//  CS646_Assignment_5
//
//  Created by Thuc Nguyen on 11/12/17.
//  Copyright © 2017 cs646. All rights reserved.
//

import UIKit

class FilterParametersViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    
    // MARK: PROPERTIES
    var currentSource: SourceController = .NONE
    var currentFilterParameter: FilterParameter = .ALL
    
    // The data to refer to and populate the picker
    var dataList: [String] = []
    let yearDataList: [String] = Array(1970...2017).reversed().map({String($0)})
    var retrievingData: Bool = false {
        didSet {
            if (retrievingData) {
                activityIndicator.startAnimating()
                rootStackView.isHidden = true
            } else {
                activityIndicator.stopAnimating()
                rootStackView.isHidden = false
            }
        }
    }
    var selectedCountry: String = "", selectedYear: String = ""
    
    // MARK: CONSTANTS
    let unwindToMapSegue = "unwindToMapFromFilter", unwindToListUsersSegue = "unwindToListUsersFromFilter"
    
    // MARK: OUTLETS AND ACTIONS
    @IBAction func cancelBarButtonItem(_ sender: UIBarButtonItem) {
        if (currentSource == .MAP) {
            currentSource = .NONE
            self.performSegue(withIdentifier: unwindToMapSegue, sender: self)
        }
        else if (currentSource == .LIST_USERS) {
            currentSource = .NONE
            self.performSegue(withIdentifier: unwindToListUsersSegue, sender: self)
        }
    }
    
    @IBAction func doneBarButtonItem(_ sender: UIBarButtonItem) {
        // Return if retrievingData is true
        
        if (countrySwitch.isOn) && (yearSwitch.isOn) {
            currentFilterParameter = .COUNTRY_AND_YEAR
            selectedCountry = dataList[countryPicker.selectedRow(inComponent: 0)]
            selectedYear = yearDataList[yearPicker.selectedRow(inComponent: 0)]
        }
        else if (countrySwitch.isOn) && (!yearSwitch.isOn) {
            currentFilterParameter = .COUNTRY
            selectedCountry = dataList[countryPicker.selectedRow(inComponent: 0)]
        }
        else if (!countrySwitch.isOn) && (yearSwitch.isOn) {
            currentFilterParameter = .YEAR
            selectedYear = yearDataList[yearPicker.selectedRow(inComponent: 0)]
        }
        else {
            currentFilterParameter = .ALL
        }
        
        if (currentSource == .MAP) {
            currentSource = .NONE
            self.performSegue(withIdentifier: unwindToMapSegue, sender: self)
        }
        else if (currentSource == .LIST_USERS) {
            currentSource = .NONE
            self.performSegue(withIdentifier: unwindToListUsersSegue, sender: self)
        }
    }
    
    @IBOutlet weak var rootStackView: UIStackView!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var countryLabel: UILabel!
    @IBOutlet weak var countrySwitch: UISwitch!
    @IBAction func countrySwitchAction(_ sender: UISwitch) {
        if (countrySwitch.isOn) {
            countryPicker.isUserInteractionEnabled = true
        } else {
            countryPicker.isUserInteractionEnabled = false
        }
    }
    @IBOutlet weak var countryPicker: UIPickerView!
    
    @IBOutlet weak var yearLabel: UILabel!
    @IBOutlet weak var yearSwitch: UISwitch!
    @IBAction func yearSwitchAction(_ sender: UISwitch) {
        if (yearSwitch.isOn) {
            yearPicker.isUserInteractionEnabled = true
        } else {
            yearPicker.isUserInteractionEnabled = false
        }
    }
    @IBOutlet weak var yearPicker: UIPickerView!
    
    
    // MARK: PICKER DATASOURCE AND DELEGATE METHODS
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if (pickerView === countryPicker) {
            return dataList.count
        }
        else if (pickerView === yearPicker) {
            return yearDataList.count
        }
        else {
            return 0
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        guard (component == 0) else {
            return ""
        }
        if (pickerView === countryPicker) {
            return dataList[row]
        }
        else if (pickerView === yearPicker) {
            return yearDataList[row]
        }
        else {
            return nil
        }
    }
    
    // MARK: NETWORKING METHODS
    func retrieveDataFromServer() {
        retrievingData = true
        let operation = BlockOperation.init(block: {self.getCountries()})
        let queue = OperationQueue.init()
        queue.addOperation(operation)
    }
    
    func getCountries() {
        if let url = URL.init(string: "https://bismarck.sdsu.edu/hometown/countries") {
            var urlCountriesRequest = URLRequest.init(url: url)
            urlCountriesRequest.httpMethod = "GET"
            urlCountriesRequest.setValue("text/plain", forHTTPHeaderField: "Content-Type")
            let session = URLSession.shared
            let task = session.dataTask(with: urlCountriesRequest, completionHandler: getCountriesHandler)
            task.resume()
        }
        else {
            print("FilterParametersVC: Unable to create Country URL")
            let maingQueue = OperationQueue.main
            maingQueue.addOperation {
                self.retrievingData = false
            }
        }
    }
    func getCountriesHandler(data: Data?, response: URLResponse?, error: Error?) -> Void {
        guard (error == nil) else {
            print("FilterParametersVC: getCountriesHandler(): error: \(error!.localizedDescription)")
            let maingQueue = OperationQueue.main
            maingQueue.addOperation {
                self.retrievingData = false
            }
            return
        }
        
        let httpResponse = response as? HTTPURLResponse
        let status: Int = httpResponse!.statusCode
        
        guard (data != nil) && (status == 200) else {
            print("FilterParametersVC: getCountriesHandler(): data is nil or status is not 200")
            let maingQueue = OperationQueue.main
            maingQueue.addOperation {
                self.retrievingData = false
            }
            return
        }
        do {
            let json: Any = try JSONSerialization.jsonObject(with: data!)
            let jsonNSArray = json as! NSArray
            
            let mainQueue = OperationQueue.main
            mainQueue.addOperation({
                self.dataList = jsonNSArray as! Array
                self.countryPicker.reloadComponent(0)
                self.retrievingData = false
            })
        }
        catch {
            print("FilterParametersVC: getCountriesHandler(): Error when deserializing json object")
            let maingQueue = OperationQueue.main
            maingQueue.addOperation {
                self.retrievingData = false
            }
        }
    }
    
    // MARK: LIFECYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        
        countryPicker.dataSource = self
        countryPicker.delegate = self
        yearPicker.dataSource = self
        yearPicker.delegate = self
        
        countrySwitch.thumbTintColor = UIColor.orange
        countrySwitch.tintColor = UIColor.gray
        countrySwitch.onTintColor = UIColor.red
        yearSwitch.thumbTintColor = UIColor.orange
        yearSwitch.tintColor = UIColor.gray
        yearSwitch.onTintColor = UIColor.red
        
        switch currentFilterParameter {
        case .ALL:
            countrySwitch.setOn(false, animated: true)
            yearSwitch.setOn(false, animated: true)
            countryPicker.isUserInteractionEnabled = false
            yearPicker.isUserInteractionEnabled = false
        case .COUNTRY:
            countrySwitch.setOn(true, animated: true)
            yearSwitch.setOn(false, animated: true)
            countryPicker.isUserInteractionEnabled = true
            yearPicker.isUserInteractionEnabled = false
        case .YEAR:
            countrySwitch.setOn(false, animated: true)
            yearSwitch.setOn(true, animated: true)
            countryPicker.isUserInteractionEnabled = false
            yearPicker.isUserInteractionEnabled = true
        case .COUNTRY_AND_YEAR:
            countrySwitch.setOn(true, animated: true)
            yearSwitch.setOn(true, animated: true)
            countryPicker.isUserInteractionEnabled = true
            yearPicker.isUserInteractionEnabled = true
        }
        retrieveDataFromServer()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

}
