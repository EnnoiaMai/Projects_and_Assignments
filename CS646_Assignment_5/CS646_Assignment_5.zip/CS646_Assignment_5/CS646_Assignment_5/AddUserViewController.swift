//
//  ViewController.swift
//  CS646_Assignment_5
//
//  Created by Thuc Nguyen on 11/8/17.
//  Copyright © 2017 cs646. All rights reserved.
//

import UIKit
import CoreLocation

class AddUserViewController: UIViewController {

    // MARK: PROPERTIES
    var currentSource: SourceController = .NONE {
        didSet {
            print("didSet currentSource in AddUserVC")
            switch currentSource {
            case .MAP, .LIST_USERS:
                addEditNavigationItem.title = "Add User"
            default:
                addEditNavigationItem.title = ""
            }
        }
    }
    
    var isNetworking: Bool = false {
        didSet {
            if (isNetworking) {
                rootStackView.isHidden = true
                activityIndicator.startAnimating()
            } else {
                rootStackView.isHidden = false
                activityIndicator.stopAnimating()
            }
        }
    }
    // If done was clicked for posting or hometown was clicked
    var posting: Bool = false
    var posted: Bool = false
    
    // MARK: CONSTANTS
    let unwindToMapSegue = "unwindToMapFromAddUser", unwindToListUsersSegue = "unwindToListUsersFromAddUser"
    let countrySegue = "countrySegue", stateSegue = "stateSegue", yearSegue = "yearSegue", hometownSegue = "hometownSegue"
    let selectCountryText = "Select a Country...", selectStateText = "Select a State...", selectYearText = "Select a Year..."
    let validationFailureTitle = "Validation Failed"
    let validationFailureMsg = """
    The information provided did not meet the following criteria:

    - The nickname entered must be unique.
    - The password must be at least 3 characters.
    - A country must be selected.
    - A state must be selected.
    - A valid city must be entered.
    - A year must be selected.
    """
    let countryFailureTitle = "Please select a country"
    let countryFailureMsg = "A country must be selected prior to selecting the state."
    let hometownFailureTitle = "Complete the following fields: nickname, password, and year"
    let hometownFailureMsg = "In order to choose your hometown from a map, the nickname, password, and year fields must be filled out."
    
    let colorInvalid = UIColor.red
    let colorValid = UIColor.gray
    
    // MARK: OUTLETS AND ACTIONS
    @IBOutlet weak var addEditNavigationItem: UINavigationItem!
    
    @IBAction func cancelBarButton(_ sender: UIBarButtonItem) {
        hideKeyboard()
        if (currentSource == .MAP) {
            currentSource = .NONE
            self.performSegue(withIdentifier: unwindToMapSegue, sender: self)
        }
        else if (currentSource == .LIST_USERS) {
            currentSource = .NONE
            self.performSegue(withIdentifier: unwindToListUsersSegue, sender: self)
        }
    }
    @IBAction func doneBarButton(_ sender: UIBarButtonItem) {
        hideKeyboard()
        if (!validateData()) {
            alertOnValidationError()
            return
        }
        
        // Validate nickname prior to posting
        posting = true
        getDataFromServer()
    }
    
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var rootStackView: UIStackView!
    
    @IBOutlet weak var nicknameLabel: UILabel!
    @IBOutlet weak var passwordLabel: UILabel!
    @IBOutlet weak var countryLabel: UILabel!
    @IBOutlet weak var stateLabel: UILabel!
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var yearLabel: UILabel!
    @IBOutlet weak var yearInfoLabel: UILabel!
    
    @IBOutlet weak var nicknameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    @IBOutlet weak var countryButton: UIButton!
    @IBAction func selectCountry(_ sender: UIButton) {
    }
    
    @IBOutlet weak var stateButton: UIButton!
    @IBAction func selectState(_ sender: UIButton) {
        if (countryButton.currentTitle == selectCountryText) {
            alertOnCountryError()
            return
        }
        self.performSegue(withIdentifier: stateSegue, sender: self)
    }
    
    
    @IBOutlet weak var cityTextField: UITextField!
    
    @IBOutlet weak var yearButton: UIButton!
    @IBAction func selectYear(_ sender: UIButton) {
    }
    
    @IBAction func chooseHometownButton(_ sender: UIButton) {
        hideKeyboard()
        // Validate that nickname, password, and year fields are complete before segueing
        chooseHometownValidation()
    }
    
    @IBOutlet weak var chooseHometownLabel: UILabel!
    
    // MARK: METHODS
    func validateData() -> Bool {
        var success = true
        
        guard let nicknameText = nicknameTextField.text, let passwordText = passwordTextField.text, let cityText = cityTextField.text else {
            print("validateData(): error because textfields' text were nil")
            success = false
            return success
        }
        // Nickname can't be empty (GET)
        if (nicknameText.isEmpty) {
            nicknameTextField.layer.borderColor = colorInvalid.cgColor
            success = false
        } else {
            nicknameTextField.layer.borderColor = colorValid.cgColor
        }
        
        // Password can't be empty and must be at least 3 characters long
        if (passwordText.isEmpty || passwordText.count < 3) {
            passwordTextField.layer.borderColor = colorInvalid.cgColor
            success = false
        } else {
            passwordTextField.layer.borderColor = colorValid.cgColor
        }
        
        // Country must be selected (GET, UIPicker)
        if (countryButton.currentTitle == selectCountryText) {
            countryButton.layer.borderColor = colorInvalid.cgColor
            success = false
        } else {
            countryButton.layer.borderColor = colorValid.cgColor
        }
        
        // State must be selected (GET, UIPicker)
        if (stateButton.currentTitle == selectStateText) {
            stateButton.layer.borderColor = colorInvalid.cgColor
            success = false
        } else {
            stateButton.layer.borderColor = colorValid.cgColor
        }
        
        // City can't be empty
        if (cityText.isEmpty) {
            cityTextField.layer.borderColor = colorInvalid.cgColor
            success = false
        } else {
            cityTextField.layer.borderColor = colorValid.cgColor
        }
        
        // Year must be selected (UIPicker)
        if (yearButton.currentTitle == selectYearText) {
            yearButton.layer.borderColor = colorInvalid.cgColor
            success = false
        } else {
            yearButton.layer.borderColor = colorValid.cgColor
        }
        
        return success
    }
    
    func chooseHometownValidation() {
        var success = true
        
        guard let nicknameText = nicknameTextField.text, let passwordText = passwordTextField.text else {
            print("validateData(): error because textfields' text were nil")
            return
        }
        
        // Nickname can't be empty (GET)
        if (nicknameText.isEmpty) {
            nicknameTextField.layer.borderColor = colorInvalid.cgColor
            success = false
        } else {
            nicknameTextField.layer.borderColor = colorValid.cgColor
        }
        
        // Password can't be empty and must be at least 3 characters long
        if (passwordText.isEmpty || passwordText.count < 3) {
            passwordTextField.layer.borderColor = colorInvalid.cgColor
            success = false
        } else {
            passwordTextField.layer.borderColor = colorValid.cgColor
        }
        
        // Year must be selected (UIPicker)
        if (yearButton.currentTitle == selectYearText) {
            yearButton.layer.borderColor = colorInvalid.cgColor
            success = false
        } else {
            yearButton.layer.borderColor = colorValid.cgColor
        }
        
        countryButton.layer.borderColor = colorValid.cgColor
        stateButton.layer.borderColor = colorValid.cgColor
        cityTextField.layer.borderColor = colorValid.cgColor
        
        if (success) {
            getDataFromServer()
        } else {
            alertOnHometownValidationError()
            return
        }
        
    }
    
    func alertOnValidationError() {
        let alertController = UIAlertController.init(title: validationFailureTitle, message: validationFailureMsg, preferredStyle: .alert)
        let okAction = UIAlertAction.init(title: "OK", style: .default, handler: nil)
        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    func alertOnCountryError() {
        let alertController = UIAlertController.init(title: countryFailureTitle, message: countryFailureMsg, preferredStyle: .alert)
        let okAction = UIAlertAction.init(title: "OK", style: .default, handler: nil)
        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    func alertOnHometownValidationError() {
        let alertController = UIAlertController.init(title: hometownFailureTitle, message: hometownFailureMsg, preferredStyle: .alert)
        let okAction = UIAlertAction.init(title: "OK", style: .default, handler: nil)
        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    // MARK: NETWORKING METHODS
    func postDataToServer() {
        guard let nicknameText = nicknameTextField.text, let password = passwordTextField.text, let country = countryButton.currentTitle, let state = stateButton.currentTitle, let city = cityTextField.text, let year = yearButton.currentTitle, let yearInt = Int(year) else {
            print("postDataToServer(): one of the inputs were nil")
            isNetworking = false
            return
        }
        
        let nickname = nicknameText.trimmingCharacters(in: .whitespacesAndNewlines)
        
        let jsonRecordString = "{\"nickname\":\"\(nickname)\",\"password\":\"\(password)\",\"country\":\"\(country)\",\"state\":\"\(state)\",\"city\":\"\(city)\",\"year\":\(yearInt)}"
        print("postDataToServer(): jsonRecord = \(jsonRecordString)")
        let jsonRecord: Data? = jsonRecordString.data(using: .utf8)

        let operation = BlockOperation.init(block: { self.postUser(jsonRecord: jsonRecord) })
        let queue = OperationQueue.init()
        queue.addOperation(operation)
    }
    
    func postUser(jsonRecord: Data?) {
        if let url = URL.init(string: "https://bismarck.sdsu.edu/hometown/adduser") {
            var urlPostUserRequest = URLRequest.init(url: url)
            urlPostUserRequest.httpMethod = "POST"
            urlPostUserRequest.httpBody = jsonRecord
            urlPostUserRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
            
            let session = URLSession.shared
            let task = session.uploadTask(with: urlPostUserRequest, from: jsonRecord, completionHandler: postUserHandler)
            task.resume()
        }
        else {
            print("Unable to create postUser url")
            let mainQueue = OperationQueue.main
            mainQueue.addOperation({
                self.isNetworking = false
            })
        }
    }
    
    func postUserHandler(data: Data?, response: URLResponse?, error: Error?) -> Void {
        guard (error == nil) else {
            print("postUserHandler(): error: \(error!.localizedDescription)")
            let mainQueue = OperationQueue.main
            mainQueue.addOperation({
                self.isNetworking = false
            })
            return
        }
        
        let httpResponse = response as? HTTPURLResponse
        let status: Int = httpResponse!.statusCode
        
        guard (status == 200) else {
            let statusError = String(data: data!, encoding: String.Encoding.utf8)
            print("postUserHandler(): status error: \(statusError ?? "some status error") and statusCode: \(status)")
            let mainQueue = OperationQueue.main
            mainQueue.addOperation({
                self.isNetworking = false
            })
            return
        }
        
        let mainQueue = OperationQueue.main
        mainQueue.addOperation({
            self.isNetworking = false
            if (self.currentSource == .MAP) {
                self.currentSource = .NONE
                self.posted = true
                self.performSegue(withIdentifier: self.unwindToMapSegue, sender: self)
            }
            else if (self.currentSource == .LIST_USERS) {
                self.currentSource = .NONE
                self.posted = true
                self.performSegue(withIdentifier: self.unwindToListUsersSegue, sender: self)
            }
        })
    }
    
    func getDataFromServer() {
        guard let nicknameText = nicknameTextField.text else {
            print("getDataFromServer(): nicknameTextField text is nil")
            posting = false
            return
        }
        
        let nickname = nicknameText.trimmingCharacters(in: .whitespacesAndNewlines)
        
        isNetworking = true
        let operation = BlockOperation.init(block: {self.getNickname(nickname: nickname)})
        let queue = OperationQueue.init()
        queue.addOperation(operation)
    }
    func getNickname(nickname: String) {
        if let url = URL.init(string: "https://bismarck.sdsu.edu/hometown/nicknameexists?name=\(nickname)") {
            var urlNicknameRequest = URLRequest.init(url: url)
            urlNicknameRequest.httpMethod = "GET"
            urlNicknameRequest.setValue("text/plain", forHTTPHeaderField: "Content-Type")
            let session = URLSession.shared
            let task = session.dataTask(with: urlNicknameRequest, completionHandler: getNicknameHandler)
            task.resume()
        }
        else {
            print("Unable to create Nickname URL")
            let mainQueue = OperationQueue.main
            mainQueue.addOperation({
                self.posting = false
                self.isNetworking = false
            })
        }
    }
    func getNicknameHandler(data: Data?, response: URLResponse?, error: Error?) -> Void {
        guard (error == nil) else {
            print("getNicknameHandler(): error: \(error!.localizedDescription)")
            let mainQueue = OperationQueue.main
            mainQueue.addOperation({
                self.posting = false
                self.isNetworking = false
            })
            return
        }
        
        let httpResponse = response as? HTTPURLResponse
        let status: Int = httpResponse!.statusCode
        
        guard (data != nil) && (status == 200) else {
            print("getNicknameHandler(): data is nil or status is not 200")
            let mainQueue = OperationQueue.main
            mainQueue.addOperation({
                self.posting = false
                self.isNetworking = false
            })
            return
        }
        do {
            let json: Any = try JSONSerialization.jsonObject(with: data!, options: .allowFragments)
            let jsonBool = json as! Bool
            
            let mainQueue = OperationQueue.main
            mainQueue.addOperation({
                if (jsonBool) {
                    self.nicknameTextField.layer.borderColor = self.colorInvalid.cgColor
                    self.isNetworking = false
                    self.posting = false
                    self.alertOnValidationError()
                }
                else {
                    self.nicknameTextField.layer.borderColor = self.colorValid.cgColor
                    if (self.posting) {
                        self.posting = false
                        self.checkValidCity()
                    }
                    else {
                        // validation that nickname is unique succeeded
                        self.isNetworking = false
                        self.performSegue(withIdentifier: self.hometownSegue, sender: self)
                    }
                }
            })
        }
        catch {
            print("getNicknameHandler(): Error when deserializing json object")
            let mainQueue = OperationQueue.main
            mainQueue.addOperation({
                self.posting = false
                self.isNetworking = false
            })
        }
    }
    func checkValidCity() {
        guard let country = countryButton.currentTitle, let state = stateButton.currentTitle, let city = cityTextField.text else {
            print("checkValidCity(): one of the inputs were nil")
            self.isNetworking = false
            return
        }
        let addressString = "\(city), \(state) \(country)"
        
        let locator = CLGeocoder()
        locator.geocodeAddressString(addressString) { (placemarks, errors) in
            if let place = placemarks?[0] {
                if (place.locality != nil) {
                    self.cityTextField.layer.borderColor = self.colorValid.cgColor
                    self.postDataToServer()
                } else {
                    self.cityTextField.layer.borderColor = self.colorInvalid.cgColor
                    self.isNetworking = false
                    self.alertOnValidationError()
                }
            }
            else {
                self.cityTextField.layer.borderColor = self.colorInvalid.cgColor
                self.isNetworking = false
                self.alertOnValidationError()
            }
        }
    }
    
    // MARK: LIFECYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        print("AddUserViewController viewDidLoad()")
        nicknameTextField.layer.borderWidth = 1.0
        passwordTextField.layer.borderWidth = 1.0
        cityTextField.layer.borderWidth = 1.0
        countryButton.layer.borderWidth = 1.0
        stateButton.layer.borderWidth = 1.0
        yearButton.layer.borderWidth = 1.0
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    // MARK: NAVIGATION
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == countrySegue) {
            if let destination = segue.destination as? DataPickerViewController {
                destination.currentSource = .COUNTRY
            }
        }
        else if (segue.identifier == stateSegue) {
            if let destination = segue.destination as? DataPickerViewController {
                if (countryButton.currentTitle != selectCountryText) {
                    destination.currentCountry = countryButton.currentTitle
                }
                destination.currentSource = .STATE
            }
        }
        else if (segue.identifier == yearSegue) {
            if let destination = segue.destination as? DataPickerViewController {
                destination.currentSource = .YEAR
            }
        }
        else if (segue.identifier == hometownSegue) {
            if let destination = segue.destination as? ChooseHometownViewController {
                guard let nickname = nicknameTextField.text, let password = passwordTextField.text, let year = yearButton.currentTitle else {
                    return
                }
                destination.userNickname = nickname
                destination.userPassword = password
                destination.userYear = year
            }
        }
    }
    
    @IBAction func unwindToAdd(unwindSegue: UIStoryboardSegue) {
        if let source = unwindSegue.source as? DataPickerViewController {
            switch source.currentSource {
            case .COUNTRY:
                countryButton.setTitle(source.returnData, for: .normal)
                stateButton.setTitle(selectStateText, for: .normal)
            case .STATE:
                stateButton.setTitle(source.returnData, for: .normal)
            case .YEAR:
                yearButton.setTitle(source.returnData, for: .normal)
            default:
                return
            }
        }
        else if let source = unwindSegue.source as? ChooseHometownViewController {
            if (self.currentSource == .MAP) && (source.posted) {
                self.currentSource = .NONE
                self.posted = true
                self.performSegue(withIdentifier: self.unwindToMapSegue, sender: self)
            }
            else if (self.currentSource == .LIST_USERS) && (source.posted) {
                self.currentSource = .NONE
                self.posted = true
                self.performSegue(withIdentifier: self.unwindToListUsersSegue, sender: self)
            }
        }
    }
    
    // MARK: KEYBOARD METHODS
    func hideKeyboard() {
        view.endEditing(true)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        hideKeyboard()
    }
}

