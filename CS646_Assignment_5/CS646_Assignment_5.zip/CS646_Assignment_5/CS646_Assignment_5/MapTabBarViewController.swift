//
//  MapTabBarViewController.swift
//  CS646_Assignment_5
//
//  Created by Thuc Nguyen on 11/9/17.
//  Copyright © 2017 cs646. All rights reserved.
//

import UIKit

class MapTabBarViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
