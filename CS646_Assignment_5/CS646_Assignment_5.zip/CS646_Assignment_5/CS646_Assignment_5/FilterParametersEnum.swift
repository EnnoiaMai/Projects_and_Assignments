//
//  FilterParametersEnum.swift
//  CS646_Assignment_5
//
//  Created by Thuc Nguyen on 11/12/17.
//  Copyright © 2017 cs646. All rights reserved.
//

import Foundation

// Filters either map annotations of list of users
enum FilterParameter: String {
    case ALL, COUNTRY, YEAR, COUNTRY_AND_YEAR
}

// For navigating back and forth from map/list to and from add user
enum SourceController: String {
    case MAP, LIST_USERS, NONE
}



