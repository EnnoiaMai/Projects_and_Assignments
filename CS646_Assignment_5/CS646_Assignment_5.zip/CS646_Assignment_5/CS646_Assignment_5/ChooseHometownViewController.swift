//
//  ChooseHometownViewController.swift
//  CS646_Assignment_5
//
//  Created by Thuc Nguyen on 11/10/17.
//  Copyright © 2017 cs646. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit

class ChooseHometownViewController: UIViewController, MKMapViewDelegate {

    // MARK: PROPERTIES
    var isNetworking: Bool = false {
        didSet {
            if (isNetworking) {
                infoStackView.isHidden = true
                mapStackView.isHidden = true
                activityIndicator.startAnimating()
            } else {
                infoStackView.isHidden = false
                mapStackView.isHidden = false
                activityIndicator.stopAnimating()
            }
        }
    }
    var posted: Bool = false
    
//    var latitude: Double = 0, longitude: Double = 0
    var userCoordinates: CLLocationCoordinate2D?
    var userNickname: String?, userPassword: String?, userYear: String?
    var userCity: String?, userState: String?, userCountry: String?
    
    // MARK: CONSTANTS
    let mapInteractionPlaceholder = "Press and hold on the map to add a marker indicating the hometown associated with the user."
    let unwindToAddSegue = "unwindToAddFromHometown"
    let locationFailureTitle = "Location was not provided"
    let locationFailureMsg = "Provide the location of the hometown before submitting the new user."
    let locationNotSupportedTitle = "The location is not supported."
    let locationNotSupportedMsg = "The server does not support the location marked on the map. Please choose another."
    
    // MARK: OUTLETS AND ACTIONS
    @IBOutlet weak var infoStackView: UIStackView!
    @IBOutlet weak var infoLabel: UILabel!
    @IBOutlet weak var nicknameLabel: UILabel!
    @IBOutlet weak var passwordLabel: UILabel!
    @IBOutlet weak var yearLabel: UILabel!
    @IBOutlet weak var mapInteractionLabel: UILabel!
    
    @IBAction func doneBarButtonItem(_ sender: Any) {
        if (userCoordinates == nil) {
            alertLocationProvidedError()
            return
        }
        isNetworking = true
        reverseGeocodeCoordinates()
    }
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var mapStackView: UIStackView!
    @IBOutlet weak var mapView: MKMapView!
    
    @IBAction func longPressOnMap(recognizer: UIGestureRecognizer) {
        if recognizer.state == .began {
            mapView.removeAnnotations(mapView.annotations)
            let location = recognizer.location(in: mapView)
            userCoordinates = mapView.convert(location, toCoordinateFrom: mapView)
            let annotation = UserMapAnnotation.init(nickname: userNickname!, coordinate: userCoordinates!)
            mapView.addAnnotation(annotation)
        }
    }
    
    // MARK: MAPVIEW DELEGATE METHODS
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        guard let annotation = annotation as? UserMapAnnotation else {
            return nil
        }
        
        let reuseId = "homeTownAnnotations"
        var view: MKPinAnnotationView
        
        if let dequeuedView = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId) as? MKPinAnnotationView {
            dequeuedView.annotation = annotation
            view = dequeuedView
        }
        else {
            view = MKPinAnnotationView.init(annotation: annotation, reuseIdentifier: reuseId)
            view.canShowCallout = true
        }
        return view
    }
    
    func mapView(_ mapView: MKMapView, didAdd views: [MKAnnotationView]) {
        
    }
    
    // MARK: NETWORKING METHODS
    func postDataToServer() {
        guard let coordinates = userCoordinates, let nickname = userNickname, let password = userPassword, let year = userYear, let city = userCity, let state = userState, let country = userCountry else {
            print("postDataToServer(): one of the inputs were nil")
            isNetworking = false
            return
        }
        
        let jsonRecordString = "{\"nickname\":\"\(nickname)\",\"password\":\"\(password)\",\"country\":\"\(country)\",\"state\":\"\(state)\",\"city\":\"\(city)\",\"year\":\(year),\"latitude\":\(Double(coordinates.latitude)),\"longitude\":\(Double(coordinates.longitude))}"
        print("postDataToServer(): jsonRecord = \(jsonRecordString)")
        let jsonRecord: Data? = jsonRecordString.data(using: .utf8)

        let operation = BlockOperation.init(block: { self.postUser(jsonRecord: jsonRecord) })
        let queue = OperationQueue.init()
        queue.addOperation(operation)
    }
    
    func postUser(jsonRecord: Data?) {
        if let url = URL.init(string: "https://bismarck.sdsu.edu/hometown/adduser") {
            var urlPostUserRequest = URLRequest.init(url: url)
            urlPostUserRequest.httpMethod = "POST"
            urlPostUserRequest.httpBody = jsonRecord
            urlPostUserRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
            
            let session = URLSession.shared
            let task = session.uploadTask(with: urlPostUserRequest, from: jsonRecord, completionHandler: postUserHandler)
            task.resume()
        }
        else {
            print("Unable to create postUser url")
            let mainQueue = OperationQueue.main
            mainQueue.addOperation {
                self.isNetworking = false
                self.alertLocationNotSupportedError()
            }
        }
    }
    
    func postUserHandler(data: Data?, response: URLResponse?, error: Error?) -> Void {
        guard (error == nil) else {
            print("postUserHandler(): error: \(error!.localizedDescription)")
            let mainQueue = OperationQueue.main
            mainQueue.addOperation {
                self.isNetworking = false
            }
            return
        }
        
        let httpResponse = response as? HTTPURLResponse
        let status: Int = httpResponse!.statusCode
        
        if (status == 200) {
            let mainQueue = OperationQueue.main
            mainQueue.addOperation({
                self.isNetworking = false
                self.posted = true
                self.performSegue(withIdentifier: self.unwindToAddSegue, sender: self)
            })
        }
        else {
            let statusError = String(data: data!, encoding: String.Encoding.utf8)
            print("postUserHandler(): status error: \(statusError ?? "some status error") and statusCode: \(status)")
            let mainQueue = OperationQueue.main
            mainQueue.addOperation {
                self.isNetworking = false
                self.alertLocationNotSupportedError()
            }
            return
        }
    }
    
    // MARK: METHODS
    func reverseGeocodeCoordinates() {
        guard let coordinates = userCoordinates else {
            isNetworking = false
            return
        }
        let location = CLLocation.init(latitude: coordinates.latitude, longitude: coordinates.longitude)
        let locator = CLGeocoder()
        locator.reverseGeocodeLocation(location) { (placemarks, errors) in
            if let place = placemarks?[0] {
                self.userCity = place.locality
                self.userCountry = place.country

                if (place.country == "United States") {
                    self.userState = UnabbreviatedStateOrProvidence.returnUnabbreviated(country: "United States", administrativeArea: place.administrativeArea)
                    self.userCountry = "USA"
                }
                else if (place.country == "Mexico") {
                    self.userState = UnabbreviatedStateOrProvidence.returnUnabbreviated(country: "Mexico", administrativeArea: place.administrativeArea)
                }
                else {
                    self.userState = place.administrativeArea
                }
                self.postDataToServer()
            }
            else {
                print("reverseGeocodeCoordinates(): \(errors!)")
                self.isNetworking = false
            }
        }
    }
    
    func alertLocationProvidedError() {
        let alertController = UIAlertController.init(title: locationFailureTitle, message: locationFailureMsg, preferredStyle: .alert)
        let alertAction = UIAlertAction.init(title: "OK", style: .default, handler: nil)
        alertController.addAction(alertAction)
        present(alertController, animated: true, completion: nil)
    }
    
    func alertLocationNotSupportedError() {
        let alertController = UIAlertController.init(title: locationNotSupportedTitle, message: locationNotSupportedMsg, preferredStyle: .alert)
        let alertAction = UIAlertAction.init(title: "OK", style: .default, handler: nil)
        alertController.addAction(alertAction)
        present(alertController, animated: true, completion: nil)
    }
    
    // MARK: LIFECYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        mapView.delegate = self
        mapInteractionLabel.text = mapInteractionPlaceholder
        
        guard let nickname = userNickname, let password = userPassword, let year = userYear else {
            return
        }
        nicknameLabel.text = "Nickname: \(nickname)"
        passwordLabel.text = "Password: \(password)"
        yearLabel.text = "Year: \(year)"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

}
